﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Threading;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Drawing.Design;
using System.Data.OleDb;
using SmartQuant;
using SmartQuant.Data;
using SmartQuant.Series;
using SmartQuant.Providers;
using SmartQuant.Instruments;

namespace Drzwz
{
    public class SAS2SQ : IProvider, IHistoryProvider
    {

        public SAS2SQ()
        {
            ProviderManager.Add(this);
        }
        #region 导入数据的方法
        private bool autoImport = true;
        [Category("设置"), Description("true-连接后自动导入；false-连接后不导入，若运行中，则中断导入。"), DefaultValue("")]
        public bool AutoImport
        {
            get { return this.autoImport; }
            set
            {
                this.autoImport = value;
            }
        }
        private string symbolRegex = @"((60\d{4}\.SH)|(0000\d\d\.SH)|(00\d{4}\.SZ)|(399\d{3}\.SZ)|(\w*\.(SQ|DQ|ZQ|CI|CB|NY)))";
        [Category("设置"), Description("要导入数据的代码的正则表达式。")]
        public string SymbolRegex
        {
            get { return this.symbolRegex; }
            set
            {
                this.symbolRegex = value.Trim();
            }
        }
        private string securityType = @"Z";
        [Category("设置"), Description("新增Instrument的SecurityType属性（组名）。"),DefaultValue("Z")]
        public string SecurityType
        {
            get { return this.securityType; }
            set
            {
                this.securityType = value.Trim();
            }
        }
        string sasDataPath = @"D:\FinData\SAS";
        [Category("设置"), Description("SAS数据目录"), DefaultValue(@"D:\FinData\SAS"),
        Editor(typeof(System.Windows.Forms.Design.FolderNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string SASDataPath
        {
            get { return this.sasDataPath; }
            set
            {
                if (File.Exists(this.sasDataPath))
                {
                    this.sasDataPath = value.Trim();
                }
                else
                {
                    Console.WriteLine(this.sasDataPath+@"不存在！");
                }
            }
        }
        OleDbConnection cn;
        List<string> symbolList = new List<string>();
        DateTime dt19600101 = new DateTime(1960, 1, 1);
        private void doWork()
        {
            try
            {
                
                StringBuilder sb = new StringBuilder();
                #region 导证券代码
                Console.WriteLine("{0} 导入代码数据...", DateTime.Now);
                Instrument instrument;

                OleDbCommand cmd = cn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"libname findata '"+this.sasDataPath+"'";
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select dm,jc from findata.dm where prxmatch(prxparse('"+this.symbolRegex+"'),dm)";
                OleDbDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Application.DoEvents();
                    if (!this.autoImport)
                    {
                        Console.WriteLine("{0} 用户中断操作(AutoImport被设为False)。 ", DateTime.Now); break;
                    } 
                    if (reader.IsDBNull(0) == false)
                    {
                        //MessageBox.Show(reader.GetValue(0).ToString(), "错误");
                        string dm = reader.GetValue(0).ToString().Trim();
                        if (Regex.IsMatch(dm, this.symbolRegex))
                        {
                            if(!symbolList.Contains(dm)) symbolList.Add(dm);
                            instrument = InstrumentManager.Instruments[dm];
                            if (instrument == null)
                            {
                                string jc = reader.GetValue(1).ToString();
                                instrument = new Instrument(dm, this.securityType);
                                instrument.SecurityExchange = dm.Substring(dm.LastIndexOf(".") + 1, dm.Length - dm.LastIndexOf(".") - 1); ;
                                instrument.SecurityDesc = jc;
                                instrument.Save();
                                //sb.AppendLine(string.Format("{0} 添加instrument: {1}。", DateTime.Now, dm));
                            }
                        }
                    }
                }
                reader.Close();

                #endregion
                #region 导复权因子
                Console.WriteLine("{0} 导入复权因子数据...", DateTime.Now);
                IDataSeries ds; DateTime dt; PriceFactor pf;
                foreach (string symbol in symbolList)
                {
                    Application.DoEvents();
                    if (!this.autoImport)
                    {
                        Console.WriteLine("{0} 用户中断操作(AutoImport被设为False)。 ", DateTime.Now); break;
                    }
                    if (Regex.IsMatch(symbol, @"(\w*\.(SH|SZ|OF|OC))") == false) continue;//只有深沪证券、基金有复权因子

                    string strDS = symbol + ".PriceFactor";
                    ds = DataManager.Server.GetDataSeries(strDS);
                    if (ds == null)
                    {
                        ds = DataManager.Server.AddDataSeries(strDS);
                    }

                    cmd.CommandText = @"select rq,yz from findata.fq where dm='"+symbol+"' order by rq";
                    reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        if (reader.IsDBNull(0) == false)
                        {
                            //MessageBox.Show(reader.GetValue(0).ToString(), "错误");
                            int irq = int.Parse(reader.GetValue(0).ToString());
                            dt = dt19600101.AddDays(irq);//DateTime.Parse(s[0].Insert(4, "-").Insert(7, "-"));
                            double yz = double.Parse(reader.GetValue(1).ToString());
                            if (ds.Contains(dt) == false)
                            {
                                pf = new PriceFactor(dt,yz);
                                ds.Add(dt, pf);
                                //sb.AppendLine(string.Format("{0} 添加PriceFactor: {1} {2} 。", DateTime.Now, symbol, dt));
                            }
                            
                        }
                    }
                    reader.Close();
                }

                #endregion
                #region 导行情数据
                Console.WriteLine("{0} 导入行情数据...", DateTime.Now);
                foreach (string symbol in symbolList)
                {
                    Application.DoEvents();
                    if (!this.autoImport)
                    {
                        Console.WriteLine("{0} 用户中断操作(AutoImport被设为False)。 ", DateTime.Now); break;
                    }
                    
                    string strDS = symbol + ".Daily";
                    DateTime maxdt = DateTime.MinValue;
                    ds = DataManager.Server.GetDataSeries(strDS);
                    string sql;
                    if (ds == null)
                    {
                        ds = DataManager.Server.AddDataSeries(strDS);
                        sql = @"select rq,kp,zg,zd,sp,sl,cc from findata.hq where dm='" + symbol + "' order by rq";
                    }
                    else
                    {
                        maxdt=ds.LastDateTime;
                        TimeSpan ts = maxdt - dt19600101;
                        sql = @"select rq,kp,zg,zd,sp,sl,cc from findata.hq where dm='" + symbol + "' and rq>"+ts.Days+" order by rq";
                    }

                    cmd.CommandText = sql;
                    reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        if (reader.IsDBNull(0) == false)
                        {
                            //MessageBox.Show(reader.GetValue(0).ToString(), "错误");
                            int irq = int.Parse(reader.GetValue(0).ToString());
                            dt = dt19600101.AddDays(irq);//DateTime.Parse(s[0].Insert(4, "-").Insert(7, "-"));
                            Daily daily = new Daily();
                            daily.DateTime = dt;
                            daily.Open = double.Parse(reader.GetValue(1).ToString());
                            daily.High = double.Parse(reader.GetValue(2).ToString());
                            daily.Low = double.Parse(reader.GetValue(3).ToString());
                            daily.Close = double.Parse(reader.GetValue(4).ToString());
                            daily.Volume = long.Parse(reader.GetValue(5).ToString());
                            daily.OpenInt = long.Parse(reader.GetValue(6).ToString());
                            ds.Add(dt, daily);
                            //sb.AppendLine(string.Format("{0} 添加hq: {1} {2} 。", DateTime.Now, symbol, dt));
                        }
                    }
                    reader.Close();
                }

                #endregion
                Console.WriteLine("{0} 导入完成.", DateTime.Now);
                //Console.WriteLine(sb.ToString());
                this.Disconnect();
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0}  导入数据时出错：{1}",DateTime.Now, ex.Message);
            }

        }
        #endregion

        #region IProvider 成员
        private bool isConnected = false;

        public void Connect(int timeout)
        {
            this.Connect();
            ProviderManager.WaitConnected(this, timeout);
        }
        public void Connect()
        {
            try
            {
                Console.WriteLine("{0} 连接SAS....", DateTime.Now);
                isConnected = true;
                if (cn == null)
                {
                    cn = new OleDbConnection();
                    cn.ConnectionString = "Provider=sas.IOMProvider.1; Data Source=_LOCAL_";
                    cn.Open();
                }
                Console.WriteLine("\n{0} Connected!", DateTime.Now);
                if (Connected != null)
                    Connected(this, new EventArgs());
                this.doWork();
            }
            catch (Exception ex)
            {
                Console.WriteLine("connect时出错：" + ex.Message);
            }
        }
        public event EventHandler Connected;
        public void Disconnect()
        {
            try
            {
                Console.WriteLine("{0} 断开SAS连接....", DateTime.Now);
                if ((cn != null) &&
                     (cn.State != ConnectionState.Closed))
                {
                    cn.Close();
                }
                cn = null;
                Console.WriteLine("{0} Disconnected!\n",DateTime.Now);
                isConnected = false;
                if (Disconnected != null)
                    Disconnected(this, new EventArgs());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Disconnect时出错：" + ex.Message);
            }

        }

        public event EventHandler Disconnected;

        public event ProviderErrorEventHandler Error;
        [Category("信息")]
        public byte Id
        {
            get { return 119; }
        }
        [Category("信息")]
        public bool IsConnected
        {
            get { return isConnected; }
        }
        [Category("信息")]
        public string Name
        {
            get { return "SAS2SQ"; }
        }
        [Category("信息")]
        public string Title
        {
            get { return "SAS2SQ 将SAS数据导入SQ。"; }
        }
        [Category("信息")]
        public string URL
        {
            get { return "http://drzwz.cn"; }
        }
        public void Shutdown()
        {
            
        }
        [Category("信息")]
        public ProviderStatus Status
        {
            get
            {
                if (!IsConnected)
                    return ProviderStatus.Disconnected;
                else
                    return ProviderStatus.Connected;
            }
        }

        public event EventHandler StatusChanged;

        #endregion

        #region IHistoryProvider 成员
        [Category("信息")]
        public bool BarSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool DailySupported
        {
            get { return false; }
        }

        public Bar[] GetBarHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, int barSize)
        {
            throw new NotImplementedException();
        }

        public Daily[] GetDailyHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, bool dividendAndSplitAdjusted)
        {
            throw new NotImplementedException();
        }

        public Quote[] GetQuoteHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }

        public Trade[] GetTradeHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }
        [Category("信息")]
        public bool QuoteSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool TradeSupported
        {
            get { return false; }
        }

        #endregion
    }

}
