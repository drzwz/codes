using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Reflection.Emit;
using System.Reflection;
using System.ComponentModel;
using Microsoft.Win32;
using SmartQuant.FIX;
using SmartQuant.Providers;
using SmartQuant.Instruments;
using SmartQuant.Data;
using System.Timers;

namespace Drzwz
{
    public class TongshiWindow : UserControl
    {
        private const int TSMSG = 55;
        private const ushort SHMKT = 18515;
        private const ushort SZMKT = 23123;
        private const int RCV_WORK_SENDMSG = 4;
        private const int RCV_REPORT = 0x3f001234;
        private const int RCV_FILEDATA = 0x3f001235;
        private const int STKLABEL_LEN = 10;	// �ɺ����ݳ���,�����г��ɺű������Ǯ��
        private const int STKNAME_LEN = 32;	// ��������
        public bool Drvloaded = false;
        private const short fProviderID = 102;

        public event TSQuoteEventHandler OnQuote;
        public delegate void TSConnectEventHandler(TongshiWindow sender,bool isconnected);
        public event TSConnectEventHandler OnConnected;
        public TongshiWindow()
        {
            InitializeComponent();
            //dllpath = @"D:\SkyJet\jet158.dll";

            //			fProviderID=pID;
        }

        // Initialize the control elements.
        public void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // TongshiWindow
            // 
            this.Name = "TongshiWindow";
            this.Size = new System.Drawing.Size(105, 41);
            this.ResumeLayout(false);

        }
        private string symbolRegex = "";
        public string SymbolRegex
        {
            get { return symbolRegex; }
            set
            {
                symbolRegex = value.Trim();
            }
        }
        private string symbolFilter = "";
        public string SymbolFilter
        {
            get { return symbolFilter; }
            set
            {
                symbolFilter = value.Trim();
            }
        }
        private string dllpath=@"D:\SkyJet\jet158.dll";
        public string DllPath
        {
            get { return dllpath; }
            set
            {
                dllpath = value.Trim();
            }
        }
        public void DrvInit()
        {
            DrvOpen();
        }
        public void DrvQuit()
        {
            DrvClose();
        }
        private void DrvOpen()
        {
            if (!Drvloaded && dllpath != string.Empty)
            {
                string EntryPoint = "Stock_Init";
                object[] parameterValues = new object[3];
                parameterValues[0] = this.Handle.ToInt32();
                parameterValues[1] = TSMSG;
                parameterValues[2] = RCV_WORK_SENDMSG;

                object tempobj = Dynamicdll(dllpath, EntryPoint, parameterValues);

                Drvloaded = true;
                Console.WriteLine("{0} YT�����ɹ��򿪡�", DateTime.Now);
                if (OnConnected != null)
                {
                    OnConnected(this, true);
                }
            }
        }

        private void DrvClose()
        {
            if (Drvloaded)
            {
                string EntryPoint = "Stock_Quit";
                object[] parameterValues = new object[1];
                parameterValues[0] = this.Handle.ToInt32();

                object tempobj = Dynamicdll(dllpath, EntryPoint, parameterValues);
                Console.WriteLine("{0} YT�����ɹ��رա�", DateTime.Now);
                Drvloaded = false;
            }
        }
        private string GetRTDllPath()
        {
            string assemblyPath = Assembly.GetExecutingAssembly().Location;
            if (File.Exists(assemblyPath.Replace(".dll", ".ini")))
            {
                FileStream cfgStream = new FileStream(assemblyPath.Replace(".dll", ".ini"), FileMode.Open, FileAccess.Read);
                StreamReader cfgReader = new StreamReader(cfgStream, Encoding.GetEncoding("gb2312"));
                string dllstring = cfgReader.ReadLine();
                cfgReader.Close();
                cfgStream.Close();
                return dllstring;
            }
            else
            {
                RegistryKey rk = Registry.LocalMachine.OpenSubKey("SOFTWARE\\StockDrv", true);
                if (rk != null)
                {
                    String RTDllPath = (String)rk.GetValue("Driver");
                    return RTDllPath;
                }
                return null;
            }
            
        }
        private object Dynamicdll(string DllPath, string EntryPoint, object[] ParameterValues)
        {

            string entryPoint = EntryPoint;
            Type[] parameterTypes = new Type[ParameterValues.Length];
            for (int i = 0; i < ParameterValues.Length; i++)
            {
                parameterTypes[i] = ParameterValues[i].GetType();
            }
            object[] parameterValues = new object[ParameterValues.Length];
            parameterValues = ParameterValues;


            // Create a dynamic assembly and a dynamic module
            AssemblyName asmName = new AssemblyName();
            asmName.Name = "tempDll";
            AssemblyBuilder dynamicAsm =
                AppDomain.CurrentDomain.DefineDynamicAssembly(asmName,
                AssemblyBuilderAccess.Run);
            ModuleBuilder dynamicMod =
                dynamicAsm.DefineDynamicModule("tempModule");

            // Dynamically construct a global PInvoke signature 
            // using the input information
            MethodBuilder dynamicMethod = dynamicMod.DefinePInvokeMethod(
                entryPoint, DllPath, MethodAttributes.Static | MethodAttributes.Public
                | MethodAttributes.PinvokeImpl, CallingConventions.Standard,
                null, parameterTypes, CallingConvention.Winapi, CharSet.Ansi);

            // This global method is now complete
            dynamicMod.CreateGlobalFunctions();

            // Get a MethodInfo for the PInvoke method
            MethodInfo mi = dynamicMod.GetMethod(EntryPoint);
            // Invoke the static method and return whatever it returns
            object retval = mi.Invoke(null, parameterValues);
            // Filled verstr paramter.
            return retval;
        }

        public ushort GetMarketCode(string w_market)
        {
            ushort re_marketcode = BitConverter.ToUInt16(System.Text.Encoding.ASCII.GetBytes(w_market.Trim()), 0);
            return re_marketcode;
        }
        public string GetMarketName(ushort w_market)
        {
            string re_marketname = System.Text.Encoding.ASCII.GetString(BitConverter.GetBytes(w_market));
            return re_marketname.Trim();
        }

        protected override void WndProc(ref Message m)
        {
            RCV_DATA data;
            TSQuoteEventArgs qtarg;

            if (m.Msg == TSMSG && Drvloaded)
            {
                data = (RCV_DATA)m.GetLParam(typeof(RCV_DATA));

                // Listen for operating system messages.
                switch (m.WParam.ToInt32())
                {
                    case RCV_REPORT:

                        if (OnQuote != null)
                        {
                            for (int i = 0; i < data.m_nPacketNum; i++)
                            {
                                RCV_REPORT_STRUCTExV3 report = (RCV_REPORT_STRUCTExV3)Marshal.PtrToStructure
                                    (new IntPtr((int)data.ptr + 158 * i), typeof(RCV_REPORT_STRUCTExV3));
                                string stockcode = report.m_szLabelName.Trim();
                                string mkt = this.GetMarketName(report.m_wMarket);

                                string symbol = stockcode + "." + mkt;
                                //Console.WriteLine(">>{0} {1}",report.m_szLabelName, symbol);

                                //if (System.Text.RegularExpressions.Regex.IsMatch(symbol, this.symbolFilter))
                                //{
                                //    //Console.WriteLine("RCV_REPORT: {0} , {1}", stockcode.Trim(), stockname.Trim());//zzz
                                //    if (System.Text.RegularExpressions.Regex.IsMatch(symbol, this.symbolRegex))
                                //    {
                                //        Instrument inst = InstrumentManager.Instruments[symbol];
                                //        if (inst == null)
                                //        {
                                //            //inst = new Instrument(symbol, "Z");
                                //            //inst.SecurityDesc = stockname;
                                //            //inst.SecurityExchange = mkt;
                                //            //inst.Save();
                                //            Console.WriteLine("������{0} {1}", symbol, stockname);
                                //        }
                                //    }
                                    
                                //    //�����µĹ�Ʊ�����б�
                                //    //lock (StockNameList)   //���� StockName.List
                                //    //{
                                //    //    if (StockNameList.Count == 0)
                                //    //    {
                                //    //        StockNameList.Add(stockcode, stockname);
                                //    //    }
                                //    //    else
                                //    //    {
                                //    //        if (!StockNameList.ContainsKey(stockcode))
                                //    //        {
                                //    //            StockNameList.Add(stockcode, stockname);
                                //    //        }
                                //    //    }
                                //    //}
                                //}
                                ////switch(report .m_wMarket)
                                ////{
                                ////    case SZMKT :
                                    
                                ////    symbol = report.m_szLabelName.Trim ()+".SZ";
                                ////    break;
                                ////    case SHMKT :
                                ////        symbol = report.m_szLabelName.Trim() + ".SH";
                                ////        break;
                                ////    default :
                                ////        symbol = report.m_szLabelName.Trim ();
                                ////        break;

                                ////}
                                qtarg = new TSQuoteEventArgs(symbol, report);
                              
                                OnQuote(this, qtarg);
                                
                            }
                        }
                        break;
                    case RCV_FILEDATA:
                        break;
                }
            }
            base.WndProc(ref m);

        }
    }

    public class TongshiProvider : IProvider, IMarketDataProvider
    {
        private bool isConnected = false;
        private List<string> subscribedSymbols = new List<string>();
        protected TongshiWindow fTSdrv;
        protected Dictionary<string,RCV_REPORT_STRUCTExV3>  QuoteCache =  new Dictionary<string,RCV_REPORT_STRUCTExV3> ();
        private Dictionary<string, RCV_REPORT_STRUCTExV3> QuotesCache = new Dictionary<string, RCV_REPORT_STRUCTExV3>();
        private IBarFactory factory;

        private string symbolRegex = @"(\w*\.(SQ|DQ|ZQ|CI))";
        [Category("����"), Description("Ҫ���ӵ�Instrument���������ʽ�����Ѵ��ڣ������ӡ�"), DefaultValue("")]
        public string SymbolWillAdd
        {
            get { return this.symbolRegex; }
            set
            {
                this.symbolRegex = value.Trim();
            }
        }
        private string symbolFilter = @"(\w*\.(SH|SZ|SQ|DQ|ZQ|CI|HK|CB))";
        [Category("����"), Description("ֻ��ȡ/���������������ʽ�Ĵ��롣"), DefaultValue("")]
        public string SymbolFilter
        {
            get { return this.symbolFilter; }
            set
            {
                this.symbolFilter = value.Trim();
            }
        }
        private string dllpath = @"D:\SkyJet\jet158.dll";
        [Category("����"), Description("TS����DLL�ļ���"), 
        Editor(typeof(System.Windows.Forms.Design.FileNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string DriveDll
        {
            get { return this.dllpath; }
            set
            {
                this.dllpath = value.Trim();
            }
        }
        #region IProvider Members

        public void Connect(int timeout)
        {
            this.Connect();
            ProviderManager.WaitConnected(this, timeout);
        }

        public void Connect()
        {
            if (!fTSdrv.Drvloaded)
            {
                fTSdrv.DllPath = this.dllpath;
                fTSdrv.DrvInit();
                fTSdrv.SymbolRegex = this.symbolRegex;
                fTSdrv.SymbolFilter = this.symbolFilter;
                isConnected = true;
            }

            if (Connected != null)

                Connected(this, new EventArgs());
        }

        public event EventHandler Connected;

        public void Disconnect()
        {
            if (fTSdrv.Drvloaded == true)
            {
                fTSdrv.DrvQuit();
            }

            isConnected = false;

            if (Disconnected != null)

                Disconnected(this, new EventArgs());
        }

        public event EventHandler Disconnected;

        public event ProviderErrorEventHandler Error;

        public byte Id
        {
            get { return 81; }
        }

        public bool IsConnected
        {
            get { return isConnected; }
        }

        public string Name
        {
            get { return "TS"; }
        }

        public ProviderStatus Status
        {
            get
            {

                if (!IsConnected)

                    return ProviderStatus.Disconnected;

                else

                    return ProviderStatus.Connected;

            }
        }

        public event EventHandler StatusChanged;

        public string Title
        {
            get { return "This is a Tongshi provider."; }
        }

        public string URL
        {
            get { return String.Empty; }
        }

        #endregion

        #region IMarketDataProvider Members

        public IBarFactory BarFactory
        {
            get
            {
                return this.factory;
            }
            set
            {
                if (this.factory != null)
                {
                    this.factory.NewBar -= new BarEventHandler(this.OnNewBar);
                    this.factory.NewBarOpen -= new BarEventHandler(this.OnNewBarOpen);
                    this.factory.NewBarSlice -= new BarSliceEventHandler(this.OnNewBarSlice);
                }
                this.factory = value;
                if (this.factory != null)
                {
                    this.factory.NewBar += new BarEventHandler(this.OnNewBar);
                    this.factory.NewBarOpen += new BarEventHandler(this.OnNewBarOpen);
                    this.factory.NewBarSlice += new BarSliceEventHandler(this.OnNewBarSlice);
                }
            }
        }

        public event MarketDataSnapshotEventHandler MarketDataSnapshot;

        public event BarEventHandler NewBar;

        public event BarEventHandler NewBarOpen;

        public event BarSliceEventHandler NewBarSlice;

        public event CorporateActionEventHandler NewCorporateAction;

        public event FundamentalEventHandler NewFundamental;

        public event BarEventHandler NewMarketBar;

        public event MarketDataEventHandler NewMarketData;

        public event MarketDepthEventHandler NewMarketDepth;

        public event QuoteEventHandler NewQuote;

        public event TradeEventHandler NewTrade;

        public void SendMarketDataRequest(SmartQuant.FIX.FIXMarketDataRequest request)
        {
            // check connection

            if (!IsConnected)
            {

                //EmitError(-1, -1, "Not connected.");

                return;

            }
            switch (request.SubscriptionRequestType)
            {

                case DataManager.MARKET_DATA_SUBSCRIBE:

                    for (int i = 0; i < request.NoRelatedSym; i++)
                    {

                        FIXRelatedSymGroup group = request.GetRelatedSymGroup(i);

                        RequestSymbol(group.Symbol);

                    }

                    break;

                case DataManager.MARKET_DATA_UNSUBSCRIBE:

                    for (int i = 0; i < request.NoRelatedSym; i++)
                    {

                        FIXRelatedSymGroup group = request.GetRelatedSymGroup(i);

                        UnsubscribeSymbol(group.Symbol);

                    }

                    break;

                default:

                    throw new ArgumentException("Unknown subscription type: " + request.SubscriptionRequestType.ToString());

            }
        }
        private void RequestSymbol(string symbol)
        {

            if (!subscribedSymbols.Contains(symbol))

            {
                subscribedSymbols.Add(symbol);
               // Console.WriteLine("add " + symbol);
            }

        }

        private void UnsubscribeSymbol(string symbol)
        {

            if (subscribedSymbols.Contains(symbol))

                subscribedSymbols.Remove(symbol);

            //if (subscribedSymbols.Count == 0 )
            //{
            //}

        }

        #endregion
        public TongshiProvider()
        {
            fTSdrv = new TongshiWindow();
            fTSdrv.OnQuote += new TSQuoteEventHandler(fTSdrv_OnQuote);
            ProviderManager.Add(this);
            this.BarFactory = new BarFactory(true );
        }
        private void fTSdrv_OnQuote(object sender, TSQuoteEventArgs e)
        {
            //RCV_REPORT_STRUCTExV3 lastreport;
            bool fristEnterOrderBook;
            RCV_REPORT_STRUCTExV3 report = e.QuoteData;
            string symbol=e.Symbol ;
            if (symbol != null)
            {
                if (QuotesCache.ContainsKey(symbol))
                {
                    QuotesCache[symbol] = report;
                }
                else 
                {
                    QuotesCache.Add(symbol, report);
                }
                if (subscribedSymbols.Contains(symbol))
                {
                    //Console.WriteLine("received " + symbol);
                    

                    SmartQuant.Data.Trade td = new SmartQuant.Data.Trade();
                    td.DateTime = e.TimeStamp;

                    SmartQuant.Data.Quote qt = new SmartQuant.Data.Quote();
                    qt.DateTime = e.TimeStamp;

                    if (!QuoteCache.ContainsKey(symbol))
                    {                        
                        td.Price = (double)report.m_fNewPrice;
                        td.Size = (int)report.m_fVolume;
                        qt.Bid = (double)report.m_fBuyPrice[0];
                        qt.BidSize = (int)report.m_fBuyVolume[0];
                        qt.Ask = (double)report.m_fSellPrice[0];
                        qt.AskSize = (int)report.m_fSellVolume[0];

                        QuoteCache.Add(symbol, report );
                        fristEnterOrderBook = true;
                    }
                    else
                    {
                        RCV_REPORT_STRUCTExV3 lastreport = QuoteCache[symbol];
                        if (lastreport.m_fVolume < report.m_fVolume || (lastreport.m_fVolume == report.m_fVolume && lastreport.m_fNewPrice != report.m_fNewPrice))
                        {
                            td.Price = (double)report.m_fNewPrice;
                            td.Size = (int)(report.m_fVolume - lastreport.m_fVolume);
                        }
                        if (lastreport.m_fBuyPrice[0] != report.m_fBuyPrice[0] || lastreport.m_fBuyVolume[0] != report.m_fBuyVolume[0]
                            || lastreport.m_fSellPrice[0] != report.m_fSellPrice[0] || lastreport.m_fSellVolume[0] != report.m_fSellVolume[0])
                        {
                            qt.Bid = (double)report.m_fBuyPrice[0];
                            qt.BidSize = (int)report.m_fBuyVolume[0];
                            qt.Ask = (double)report.m_fSellPrice[0];
                            qt.AskSize = (int)report.m_fSellVolume[0];
                        }

                        QuoteCache[symbol] = report;
                        fristEnterOrderBook = false;
                    }
                    Instrument instrument = SmartQuant.Instruments.InstrumentManager.Instruments[symbol];
                    MDOperation operation;

                    if (fristEnterOrderBook)
                    {
                        //instrument.OrderBook.Clear();
                        operation = MDOperation.Insert;

                    }
                    else
                    {
                        operation = MDOperation.Update;
                    }



                    for (int i = 0; i <3; i++)
                    {
                        MarketDepth depth1 = new MarketDepth(e.TimeStamp, "", i, operation, MDSide.Ask, (double)report.m_fSellPrice[i], (int)report.m_fSellVolume[i]);
                        MarketDepth depth2 = new MarketDepth(e.TimeStamp, "", i, operation, MDSide.Bid, (double)report.m_fBuyPrice[i], (int)report.m_fBuyVolume[i]);

                        //instrument.OrderBook.Add(depth1);
                        if (this.NewMarketDepth != null)
                        {
                            try
                            {
                                this.NewMarketDepth(this, new MarketDepthEventArgs(depth1, instrument, this));
                                this.NewMarketDepth(this, new MarketDepthEventArgs(depth2, instrument, this));

                            }
                            catch (Exception exception1)
                            {
                                Console .WriteLine ("marketdepth eror " + exception1.Message);
                            }
                        }


                        if (NewTrade != null && td.Price > 0)
                        {
                            TradeEventArgs tdarg = new TradeEventArgs(td, instrument, this);
                            NewTrade(this, tdarg);
                            if (this.factory != null)
                            {
                                this.factory.OnNewTrade(instrument, td);
                            }

                        }
                        if (NewQuote != null && instrument.SecurityType != "IDX")
                        {
                            QuoteEventArgs qtarg = new QuoteEventArgs(qt, instrument, this);
                            NewQuote(this, qtarg);
                        }
                       
                    }         
                }
            }

        }

        private void EmitError(int id, int code, string message)
        {

            if (Error != null)

                Error(new ProviderErrorEventArgs(new ProviderError(DateTime.Now, this, id, code, message)));

        }
        private void OnNewBar(object sender, BarEventArgs args)
        {
            if (this.NewBar != null)
            {
                this.NewBar(this, new BarEventArgs(args.Bar, args.Instrument, this));
            }
        }
        private void OnNewBarOpen(object sender, BarEventArgs args)
        {
            if (this.NewBarOpen != null)
            {
                this.NewBarOpen(this, new BarEventArgs(args.Bar, args.Instrument, this));
            }
        }
        private void OnNewBarSlice(object sender, BarSliceEventArgs args)
        {
            if (this.NewBarSlice != null)
            {
                this.NewBarSlice(this, new BarSliceEventArgs(args.BarSize, this));
            }
        }

        #region IMarketDataProvider ��Ա


        public event MarketDataRequestRejectEventHandler MarketDataRequestReject;

        #endregion

        #region IProvider ��Ա


        public void Shutdown()
        {
            if (isConnected) Disconnect();
        }

        #endregion

        #region ��������
        public Dictionary<string, RCV_REPORT_STRUCTExV3> AllMaketData 
        {
            get 
            {
                Dictionary<string,RCV_REPORT_STRUCTExV3> templst=new Dictionary<string,RCV_REPORT_STRUCTExV3> ();
                lock (QuotesCache )
                {
                   templst =QuotesCache ;
                   //Console.WriteLine("Quote count {0} \t templst count {1}", QuotesCache.Count, templst.Count);
                }
                return templst;
            }
        }
        public double getsymbollast(string symbol) 
        {
            double last = 0;
            lock (QuotesCache) 
            {
                if (QuotesCache.ContainsKey(symbol)) 
                {
                    RCV_REPORT_STRUCTExV3 report = QuotesCache[symbol];
                    last = (double)report.m_fLastClose;
                }
            }
            return last;

        }
        #endregion
    }
    public class TSQuoteEventArgs : EventArgs
    {
        public string Symbol;
        public DateTime TimeStamp;
        public RCV_REPORT_STRUCTExV3 QuoteData;

        public TSQuoteEventArgs(string symbol, RCV_REPORT_STRUCTExV3 qt)
        {
            Symbol = symbol;
            QuoteData = qt;
            TimeStamp = new DateTime(1970, 1, 1).AddSeconds(QuoteData.m_time).ToLocalTime();
        }

    }

    public delegate void TSQuoteEventHandler(object sender, TSQuoteEventArgs e);
   
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct RCV_REPORT_STRUCTExV3
    {
        public System.UInt16 m_cbSize;							// �ṹ��С
        public System.UInt32 m_time;										// �ɽ�ʱ��
        public System.UInt16 m_wMarket;							// ��Ʊ�г�����

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 42)]
        public string m_szLabelName;					// ��Ʊ����,��'\0'��β
       
        public System.Single m_fLastClose;								// ����
        public System.Single m_fOpen;									// ��
        public System.Single m_fHigh;									// ���
        public System.Single m_fLow;										// ���
        public System.Single m_fNewPrice;								// ����
        public System.Single m_fVolume;									// �ɽ���
        public System.Single m_fAmount;									// �ɽ���
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public System.Single [] m_fBuyPrice;	        // �����1-3
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public System.Single[] m_fBuyVolume;							// ������1-3
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public System.Single[] m_fSellPrice;							// ������1-3
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public System.Single[] m_fSellVolume;							// ������1-3
                
        public System.Single m_fBuyPrice4;								// �����4
        public System.Single m_fBuyVolume4;								// ������4
        public System.Single m_fSellPrice4;								// ������4
        public System.Single m_fSellVolume4;								// ������4
        public System.Single m_fBuyPrice5;								// �����5
        public System.Single m_fBuyVolume5;								// ������5
        public System.Single m_fSellPrice5;								// ������5
        public System.Single m_fSellVolume5;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct RCV_DATA
    {
        public System.Int32 m_wDataType;			// �ļ�����
        public System.Int32 m_nPacketNum;			// ��¼��,�μ�עһ
        public RCV_FILE_HEADEx m_File;					// �ļ��ӿ�
        public System.Int32 m_bDISK;
        //			[ MarshalAs( UnmanagedType.LPArray)]
        //			public RCV_REPORT_STRUCTExV3[] rpt;
        //			[ MarshalAs( UnmanagedType.AsAny)]
        public IntPtr ptr;
        //			public rcvdata data;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct RCV_FILE_HEADEx
    {
        public System.UInt32 m_dwAttrib;							// �ļ�������
        public System.UInt32 m_dwLen;							// �ļ�����
        public System.UInt32 m_dwSerialNo;						// ���к�
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
        public string m_szFileName;				// �ļ��� or URL
    }
}