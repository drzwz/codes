﻿namespace Drzwz
{
    using System;

    public enum SymFormat
    {
        SymName,
        SymName_Exp_x_Ex
    }
}

