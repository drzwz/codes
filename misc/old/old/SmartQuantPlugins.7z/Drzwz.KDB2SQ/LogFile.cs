﻿namespace Drzwz
{
    using System;
    using System.IO;
    using System.Reflection;
    using System.Text;

    internal class LogFile
    {
        private const string FILE_NAME = "KDB2SQ_Log.txt";
        public static StringBuilder msg = new StringBuilder();
        private static StreamWriter writer;

        static LogFile()
        {
            try
            {
                string location = Assembly.GetAssembly(typeof(KDB2SQ)).Location;
                if (location.Length > 0)
                {
                    location = location.ToLower().Replace(".dll", "LOG.TXT");
                }
                writer = new StreamWriter(location, true);
                writer.AutoFlush = true;
                writer.WriteLine();
            }
            catch
            {
                writer = null;
            }
        }

        public static string GetMsg()
        {
            return msg.ToString();
        }

        public static void WriteLine(string message)
        {
            try
            {
                if (writer != null)
                {
                    writer.Write(DateTime.Now.ToString() + ": ");
                    writer.WriteLine(message);
                }
            }
            catch
            {
            }
        }
    }
}

