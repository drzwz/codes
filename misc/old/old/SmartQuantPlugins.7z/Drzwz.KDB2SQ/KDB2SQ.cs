﻿namespace Drzwz
{

    using SmartQuant.Data;
    using SmartQuant.FIX;
    using SmartQuant.Instruments;
    using SmartQuant.Providers;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.IO;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Windows.Forms;

    public class KDB2SQ : IProvider, IHistoryProvider
    {
        private bool autoImport = true;
        private int freqType = 86400;
        private bool isConnected = false;
        private string qargs = "d:/fe/fdb -p 5001  -U d:/fe/q/qusers";
        private c qcn = null;
        //private string qdsversion = "";
        private bool qhidden = false;
        private string qhost = "localhost";
        private string qpassword = "qpwd";
        private string qpath = @"d:\fe\q\w32\q.exe";
        private int qport = 0x1389;
        private Process qProcess = null;
        private string quser = "qusr";
        private string secType = "gp";
        private string securityType = "CS";
        private List<string> symbolList = new List<string>();
        private string symbolRegex = "";

        public event EventHandler Connected;

        public event EventHandler Disconnected;

        public event ProviderErrorEventHandler Error;

        public event EventHandler StatusChanged;

        public KDB2SQ()
        {
            ProviderManager.Add(this);
        }

        public void Connect()
        {
            try
            {
                Console.WriteLine("{0} 连接KDB+....", DateTime.Now);
                this.isConnected = true;
                if (this.qcn == null)
                {
                    this.setupConnection();
                }
                Console.WriteLine("\n{0} Connected!", DateTime.Now);
                if (this.Connected != null)
                {
                    this.Connected(this, new EventArgs());
                }
                this.doWork();
            }
            catch (Exception exception)
            {
                Console.WriteLine("connect时出错：" + exception.Message);
            }
        }

        public void Connect(int timeout)
        {
            this.Connect();
            ProviderManager.WaitConnected(this, timeout);
        }

        public void Disconnect()
        {
            try
            {
                Console.WriteLine("{0} 断开KDB+连接....", DateTime.Now);
                if (this.qcn != null)
                {
                    this.qcn = null;
                }
                Console.WriteLine("{0} Disconnected!\n", DateTime.Now);
                this.isConnected = false;
                if (this.Disconnected != null)
                {
                    this.Disconnected(this, new EventArgs());
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine("Disconnect时出错：" + exception.Message);
            }
        }

        private void doWork()
        {
            try
            {
                DateTime dt1 = new DateTime(1700, 1, 1, 0, 0, 0);
                DateTime dt2 = new DateTime(2100, 1, 1, 0, 0, 0);
                string tableName = this.secType + "hq";
                if (this.freqType < 86400)
                {
                    tableName = tableName + (this.freqType/60).ToString();
                }
                StringBuilder sb = new StringBuilder();
                Console.WriteLine("{0} 导入代码数据...", DateTime.Now);
                string[] strSymbols = (string[]) c.td(this.qcn.k("select distinct sym from " + tableName)).y[0];
                string input = "";
                int index = 0;
                while (index < strSymbols.Length)
                {
                    Application.DoEvents();
                    if (!this.autoImport)
                    {
                        Console.WriteLine("{0} 用户中断操作(AutoImport被设为False)。 ", DateTime.Now);
                        break;
                    }
                    input = strSymbols[index];
                    if (Regex.IsMatch(input, this.symbolRegex))
                    {
                        if (!this.symbolList.Contains(input))
                        {
                            this.symbolList.Add(input);
                        }
                        if (InstrumentManager.Instruments[input] == null)
                        {
                            new Instrument(input, this.securityType).Save();
                        }
                    }
                    index++;
                }
                Console.WriteLine("{0} 导入行情数据...", DateTime.Now);
                DateTime time3 = new DateTime(0x7d0, 1, 1);
                foreach (string sym in this.symbolList)
                {
                    string q;
                    Application.DoEvents();
                    if (!this.autoImport)
                    {
                        Console.WriteLine("{0} 用户中断操作(AutoImport被设为False)。 ", DateTime.Now);
                        break;
                    }
                    Instrument inst = InstrumentManager.Instruments[sym];
                    string suffix = (this.freqType >= 86400) ? "Daily" : ("Bar.Time." + ((this.freqType)).ToString().Trim());
                    string seriesName = sym + "." + suffix;
                    string strDT = "1800.01.01T00:00:00.000";
                    IDataSeries dataSeries = null;
                    dataSeries = DataManager.GetDataSeries(inst,suffix);
                    if (dataSeries == null)
                    {
                        dataSeries = DataManager.AddDataSeries(inst,suffix);
                    }
                    if (dataSeries.Count > 0) //已存在数据，需要判断是否删除旧数据等
                    {
                        if (this.freqType >= 86400)//daily
                            strDT = dataSeries.LastDateTime.ToString("yyyy.MM.ddTHH:mm:ss.fff");
                        else
                            strDT = dataSeries.LastDateTime.AddSeconds(this.freqType).ToString("yyyy.MM.ddTHH:mm:ss.fff");//数据库的时间为结束时间，这里的时间为起始时间
                        //股票，考虑复权
                        if (this.secType == "gp")
                        {
                            if(this.freqType>=86400)//daily
                                q = ".kdb2sq.hq:select dt:`datetime$date,`float$open,`float$high,`float$low,`float$close,`long$volume,`long$openint from " + tableName + " where sym=`$\"" + sym + "\" ,(`datetime$date)>" + strDT + ",not open=0n,not high=0n,not low=0n,not close=0n; count .kdb2sq.hq";
                            else //bar
                                q = ".kdb2sq.hq:select dt:date+time,`float$open,`float$high,`float$low,`float$close,`long$volume,`long$openint from " + tableName + " where sym=`$\"" + sym + "\" ,(date+time)>" + strDT + ",not open=0n,not high=0n,not low=0n,not close=0n; count .kdb2sq.hq";
                            int n = (int)this.qcn.k(q);
                            if (n > 0)//有新数据需要添加
                            {
                                n = (int)this.qcn.k(".kdb2sq.fq:select dt:(1800.01.01T00:00:00.000,`datetime$date),af:(1f,`float$af) from gpfq where sym=`$\"" + sym + "\";count select distinct dt from .kdb2sq.fq where dt>" + strDT);
                                if (n > 0) //有新的复权数据，清空序列后重新添加数据
                                {
                                    DataManager.ClearDataSeries(seriesName);
                                    Console.WriteLine("{0} {1}序列被清空后重新导入数据...", DateTime.Now, seriesName);
                                    //q = "asc select dt,(open*af%max af),(high*af%max af),(low*af%max af),(close*af%max af),0^volume,0^openint from aj[`dt;.kdb2sq.hq;.kdb2sq.fq]";
                                    if (this.freqType >= 86400)//daily
                                        q = ".kdb2sq.hq:select dt:`datetime$date,`float$open,`float$high,`float$low,`float$close,`long$volume,`long$openint from " + tableName + " where sym=`$\"" + sym + "\" ,not open=0n,not high=0n,not low=0n,not close=0n;";
                                    else //bar
                                        q = ".kdb2sq.hq:select dt:date+time,`float$open,`float$high,`float$low,`float$close,`long$volume,`long$openint from " + tableName + " where sym=`$\"" + sym + "\" ,not open=0n,not high=0n,not low=0n,not close=0n;";
                                    q += ".kdb2sq.fq:select dt:(1800.01.01T00:00:00.000,`datetime$date),af:(1f,`float$af) from gpfq where sym=`$\"" + sym + "\";";
                                    q += "asc select dt,(open*af%max af),(high*af%max af),(low*af%max af),(close*af%max af),0j^volume,0j^openint from aj[`dt;.kdb2sq.hq;.kdb2sq.fq]";

                                }
                                else  //没有新的复权数据，直接添加
                                {
                                    q = "asc select dt,open,high,low,close,0j^volume,0j^openint from .kdb2sq.hq";
                                }
                            }
                            else
                            {
                                continue;//goto next symbol
                            }
                        }
                        else  //期货等
                        {
                            if (this.freqType >= 86400)//daily
                                q = "asc select dt:`datetime$date,`float$open,`float$high,`float$low,`float$close,0j^`long$volume,0j^`long$openint from " + tableName + " where sym=`$\"" + sym + "\" ,(`datetime$date)>" + strDT + ",not open=0n,not high=0n,not low=0n,not close=0n ";
                            else //bar
                                q = "asc select dt:date+time,`float$open,`float$high,`float$low,`float$close,0j^`long$volume,0j^`long$openint from " + tableName + " where sym=`$\"" + sym + "\" ,(date+time)>" + strDT + ",not open=0n,not high=0n,not low=0n,not close=0n";
                            
                        }
                    }
                    else //数据不存在
                    {
                        if (this.secType == "gp")
                        {
                            if (this.freqType >= 86400)//daily
                                q = ".kdb2sq.hq:select dt:`datetime$date,`float$open,`float$high,`float$low,`float$close,0j^`long$volume,0j^`long$openint from " + tableName + " where sym=`$\"" + sym + "\" ,(`datetime$date)>" + strDT + ",not open=0n,not high=0n,not low=0n,not close=0n;";
                            else //bar
                                q = ".kdb2sq.hq:select dt:date+time,`float$open,`float$high,`float$low,`float$close,`long$volume,`long$openint from " + tableName + " where sym=`$\"" + sym + "\" ,(date+time)>" + strDT + ",not open=0n,not high=0n,not low=0n,not close=0n;";
                            q += ".kdb2sq.fq:select dt:(1800.01.01T00:00:00.000,`datetime$date),af:(1f,`float$af) from gpfq where sym=`$\"" + sym + "\";";
                            q += "asc select dt,(open*af%max af),(high*af%max af),(low*af%max af),(close*af%max af),0j^volume,0j^openint from aj[`dt;.kdb2sq.hq;.kdb2sq.fq]";
                        }
                        else
                        {
                            if (this.freqType >= 86400)//daily
                                q = "asc select dt:`datetime$date,`float$open,`float$high,`float$low,`float$close,0j^`long$volume,0j^`long$openint from " + tableName + " where sym=`$\"" + sym + "\" ,(`datetime$date)>" + strDT + ",not open=0n,not high=0n,not low=0n,not close=0n";
                            else //bar
                                q = "asc select dt:date+time,`float$open,`float$high,`float$low,`float$close,0j^`long$volume,0j^`long$openint from " + tableName + " where sym=`$\"" + sym + "\" ,(date+time)>" + strDT + ",not open=0n,not high=0n,not low=0n,not close=0n";
            
                        }
                    }
                    //Console.WriteLine(q);
                    c.Flip flip = c.td(this.qcn.k(q));
                    DateTime[] dt = (DateTime[]) flip.y[0];
                    double[] open = (double[])flip.y[1];
                    double[] high = (double[])flip.y[2];
                    double[] low = (double[])flip.y[3];
                    double[] close = (double[])flip.y[4];
                    long[] volume = (long[])flip.y[5];
                    long[] openint = (long[])flip.y[6];
                    
                    if (dt.Length > 0)
                    {
                        if (this.freqType >= 86400)
                        {
                            index = 0;
                            while (index < dt.Length)
                            {
                                //Console.WriteLine("{0} {1} {2} {3} {4} {5} {6}", dt[index], open[index], high[index], low[index], close[index], volume[index], openint[index]);
                                Daily daily = new Daily(dt[index], open[index], high[index], low[index], close[index], volume[index], openint[index]);
                                dataSeries.Add(dt[index], daily);
                                index++;
                        
                            }
                        }
                        else
                        {
                            for (index = 0; index < dt.Length; index++)
                            {
                                Bar bar = new Bar();
                                bar.BarType=BarType.Time;
                                bar.Size = this.freqType;
                                bar.DateTime=(dt[index].AddSeconds((double) (-1 * this.freqType)));
                                bar.EndTime = (dt[index]);
                                bar.Open=(open[index]);
                                bar.High=(high[index]);
                                bar.Low=(low[index]);
                                bar.Close=(close[index]);
                                bar.Volume=(volume[index]);
                                bar.OpenInt=(openint[index]);
                                dataSeries.Add(dt[index], bar);
                            }
                        }
                    }
                }
                Console.WriteLine("{0} 导入完成.", DateTime.Now);
                this.Disconnect();
            }
            catch (Exception exception)
            {
                Console.WriteLine("{0}  导入数据时出错：{1}", DateTime.Now, exception.Message);
            }
        }

        public Bar[] GetBarHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, int barSize)
        {
            throw new NotImplementedException();
        }

        public Daily[] GetDailyHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, bool dividendAndSplitAdjusted)
        {
            throw new NotImplementedException();
        }

        public MarketDepth[] GetMarketDepthHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }

        public Quote[] GetQuoteHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }

        public Trade[] GetTradeHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }

        private string getVersion()
        {
            try
            {
                Assembly assembly = Assembly.GetAssembly(typeof(KDB2SQ));
                if (assembly == null)
                {
                    return "(无法获取)";
                }
                AssemblyName name = assembly.GetName();
                if ((name == null) || (name.Version == null))
                {
                    return "(无法获取)";
                }
                return name.Version.ToString();
            }
            catch
            {
                return "(无法获取)";
            }
        }

        private void setupConnection()
        {
            bool flag = true;
            if (this.qcn != null)
            {
                try
                {
                    int num = (int) this.qcn.k("1");
                    flag = false;
                    return;
                }
                catch
                {
                    flag = true;
                }
            }
            try
            {
                LogFile.WriteLine("尝试连接q...");
                this.qcn = new c(this.qhost, this.qport, this.quser + ":" + this.qpassword);
                LogFile.WriteLine("连接q OK.");
                flag = false;
            }
            catch
            {
                flag = true;
                LogFile.WriteLine("连接q失败.尝试自动启动q...");
            }
            if (flag)
            {
                try
                {
                    LogFile.WriteLine("启动q...");
                    if (this.qpath.Length < 1)
                    {
                        LogFile.WriteLine("q命令为空，无法启动q。");
                    }
                    else if (!File.Exists(this.qpath))
                    {
                        LogFile.WriteLine(this.qpath + "文件不存在！");
                    }
                    else
                    {
                        this.qProcess = new Process();
                        this.qProcess.StartInfo.FileName = this.qpath;
                        this.qProcess.StartInfo.Arguments = this.qargs;
                        this.qProcess.StartInfo.UseShellExecute = false;
                        this.qProcess.StartInfo.CreateNoWindow = this.qhidden;
                        this.qProcess.Start();
                        LogFile.WriteLine("连接q...");
                        this.qcn = new c(this.qhost, this.qport, this.quser + ":" + this.qpassword);
                        LogFile.WriteLine(string.Concat(new object[] { "连接q OK:", this.qhost, ":", this.qport, "。" }));
                    }
                }
                catch (Exception exception)
                {
                    LogFile.WriteLine("连接q时出错：" + exception.Message);
                }
            }
        }

        public void Shutdown()
        {
        }

        [DisplayName("0.连接后自动导入"), Description("true-连接后自动导入；false-连接后不导入，若运行中，则中断导入。"), DefaultValue(""), Category("设置")]
        public bool AutoImport
        {
            get
            {
                return this.autoImport;
            }
            set
            {
                this.autoImport = value;
            }
        }

        [Category("信息")]
        public bool BarSupported
        {
            get
            {
                return false;
            }
        }

        [Category("信息")]
        public bool DailySupported
        {
            get
            {
                return false;
            }
        }

        [Category("设置"), Description("86400—daily，300—5分钟，...。"), DisplayName("7.周期（秒）")]
        public int FreqType
        {
            get
            {
                return this.freqType;
            }
            set
            {
                this.freqType = value;
            }
        }

        [Category("信息")]
        public byte Id
        {
            get
            {
                return 0x58;
            }
        }

        [Category("信息")]
        public bool IsConnected
        {
            get
            {
                return this.isConnected;
            }
        }

        [Category("信息")]
        public bool MarketDepthSupported
        {
            get
            {
                return false;
            }
        }

        [Category("信息")]
        public string Name
        {
            get
            {
                return "KDB2SQ";
            }
        }

        [DisplayName("1b.q启动参数"), Category("设置"), Description("自动启动q时的参数。")]
        public string qArgs
        {
            get
            {
                return this.qargs;
            }
            set
            {
                this.qargs = value;
            }
        }

        [DisplayName("1a.q启动命令"), Category("设置"), Description("当用上述地址、端口连接q失败时，自动以本命令启动q。若为空，不启动。")]
        public string qCommand
        {
            get
            {
                return this.qpath;
            }
            set
            {
                this.qpath = value;
            }
        }

        [Category("信息"), DisplayName("版本")]
        public string qdsVersion
        {
            get
            {
                return this.getVersion();
            }
        }

        [Category("设置"), Description("当自动启动q时，是否隐藏q窗口。"), DisplayName("1c.q窗口隐藏")]
        public bool qHidden
        {
            get
            {
                return this.qhidden;
            }
            set
            {
                this.qhidden = value;
            }
        }

        [Category("设置"), DisplayName("2.kdb+/q地址"), Description("kdb+ host。本机：localhost或127.0.0.1；非本机：相应的机器名/域名/IP地址。")]
        public string qHost
        {
            get
            {
                return this.qhost;
            }
            set
            {
                this.qhost = value;
            }
        }

        [Description("kdb+密码，如：qpwd。若无，则为空。要启用用户验证功能，启动q应带参数-U <用户密码文件>  (U为大写)。"), Category("设置"), PasswordPropertyText(true), DisplayName("5.kdb+/q密码")]
        public string qPassword
        {
            get
            {
                return this.qpassword;
            }
            set
            {
                this.qpassword = value;
            }
        }

        [Description(@"kdb+ port，如：5001。启动q时带参数 -p 5001或者启动后执行 \p 5001 "), Category("设置"), DisplayName("3.kdb+/q端口")]
        public int qPort
        {
            get
            {
                return this.qport;
            }
            set
            {
                this.qport = value;
            }
        }

        [Category("信息")]
        public bool QuoteSupported
        {
            get
            {
                return false;
            }
        }

        [Description("kdb+用户名，如：qusr。若无，则为空或者\"qusr:\"。要启用用户验证功能，启动q应带参数-U <用户密码文件>  (U为大写)。"), DisplayName("4.kdb+/q用户"), Category("设置")]
        public string qUser
        {
            get
            {
                return this.quser;
            }
            set
            {
                this.quser = value;
            }
        }

        [Description("gp/qh。"), DisplayName("6.证券类别"), Category("设置")]
        public string SecType
        {
            get
            {
                return this.secType;
            }
            set
            {
                this.secType = value.Trim().ToLower();
            }
        }

        [DefaultValue("Z"), DisplayName("8.Instrument组名"), Description("新增Instrument的SecurityType属性（组名）。"), Category("设置")]
        public string SecurityType
        {
            get
            {
                return this.securityType;
            }
            set
            {
                this.securityType = value.Trim();
            }
        }

        [Category("信息")]
        public ProviderStatus Status
        {
            get
            {
                if (!this.IsConnected)
                {
                    return ProviderStatus.Disconnected;
                }
                return ProviderStatus.Connected;
            }
        }

        [Category("设置"), DisplayName("9.代码正则表达式"), Description("要导入数据的代码的正则表达式。")]
        public string SymbolRegex
        {
            get
            {
                return this.symbolRegex;
            }
            set
            {
                this.symbolRegex = value.Trim();
            }
        }

        [Category("信息")]
        public string Title
        {
            get
            {
                return "KDB2SQ 将KDB+数据（代码、复权后行情数据）导入SQ。";
            }
        }

        [Category("信息")]
        public bool TradeSupported
        {
            get
            {
                return false;
            }
        }

        [Category("信息")]
        public string URL
        {
            get
            {
                return "";
            }
        }


    }
}

