using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Win32;
using System.Data;


namespace Drzwz.TS
{
	/// <summary>
	/// IDataCollection ��ժҪ˵����
	/// ����������ʷ���ݼ�ʵʱ���ݣ�Ȼ���������ݺϲ���Ϊһ��sortedlist
	/// ����Ϊ
	/// </summary>
	public class IDataCollection
	{
		
        

		#region ��������
		public SortedList<DateTime ,WLDTBar_STRUCT > requestBar(string Symbol, int NumBars, BarIntervalEnum RequestType, int BarInterval, bool FilterMarketHours,DateTime MarketOpen,DateTime MarketClose)
		{
            
			//�����ʷ����
            IHisDataCollection HisData = new IHisDataCollection();
            //SortedList<DateTime, WLDTBar_STRUCT> Tbars = HisData .requestBar(  Symbol,  RequestType,  BarInterval);//zzz
            SortedList<DateTime, WLDTBar_STRUCT> Tbars = new SortedList<DateTime, WLDTBar_STRUCT>();          
			//���ʵʱ����
            SortedList<DateTime, WLDTBar_STRUCT> rtticks = (GetRtTicks(Symbol));
			
             
			switch (RequestType)
			{
				case BarIntervalEnum.biTicks:
				 		 
					
					rtticks=StMyFunction.vol_to_netvol(rtticks);
					foreach(DateTime  key in rtticks.Keys)
					{
                        if (!Tbars.ContainsKey(key))
                        {
                            Tbars.Add(key, rtticks[key]);
                        }
					}
					break;


                case BarIntervalEnum.biMinutes:

                    rtticks = StMyFunction.vol_to_netvol(StMyFunction.tick2min(rtticks, BarInterval, false));
					
							foreach(DateTime  key in rtticks.Keys)
							{
								if (!Tbars.ContainsKey (key))
                                {
									Tbars.Add(key,rtticks[key]);
								}
								
							}
						 
					break;
                			            
				default:
					break;
					
			}
            if (Tbars.Count > NumBars)
            {
                int startbarnum = Tbars.Count - NumBars;
                SortedList<DateTime, WLDTBar_STRUCT> templist = new SortedList<DateTime, WLDTBar_STRUCT>();
                for (int i = startbarnum ; i < Tbars.Count; i++)
                {
                    templist.Add(Tbars.Keys[i], Tbars.Values[i]);
                }
                Tbars = templist;

            }
           

			return Tbars;
		}
		#endregion

		
		#region ��ʵʱ����

		//���ʵʱtick���� ע��:�ɽ���Ϊ�ۼƳɽ���,�粻��ת��������ʱ���������vol_to_netvol������ʵ�ɽ���
       public  SortedList<DateTime, WLDTBar_STRUCT> GetRtTicks(string Symbol)
        {
            SortedList<DateTime, WLDTBar_STRUCT> Tbars = new SortedList<DateTime, WLDTBar_STRUCT>();
            try
            {
                SortedList<DateTime, RCV_REPORT_STRUCTExV3_DETAIL> testlist = Singleton.RTdrv.GetRTData(Symbol.TrimEnd());
			
				for (int i=0;i<testlist.Count;i++ )
				{   
					RCV_REPORT_STRUCTExV3_DETAIL tempdata=(RCV_REPORT_STRUCTExV3_DETAIL)testlist.Values[i];
					//DateTime bargain_time=new System.DateTime(1970,1,1).AddSeconds((double)((int)testlist.GetKey(i))).ToLocalTime();
									
					WLDTBar_STRUCT tempbars;
										
					tempbars.fOpen=tempdata.m_fNewPrice;
					tempbars.fHigh=tempdata.m_fNewPrice;
					tempbars.fLow=tempdata.m_fNewPrice;
					tempbars.fClose=tempdata.m_fNewPrice;
					tempbars.fVolume=(int)tempdata.m_fVolume;
					tempbars.fBid=tempdata.m_fBuyPrice1;
					tempbars.fAsk=tempdata.m_fSellPrice1;

                    Tbars.Add(testlist.Keys[i], tempbars);
					
				}
			}catch (Exception ex)
            {
               StMyFunction.textwrite (string.Format ("{0}\t Symbol: {1}\t�������ƣ�GetRtTicks ������Ϣ��{2}",
                                            DateTime.Now ,Symbol,ex.Message ));
            }
            return Tbars;
		}
		 
		
		
		#endregion
       
        //
       
	}
}
