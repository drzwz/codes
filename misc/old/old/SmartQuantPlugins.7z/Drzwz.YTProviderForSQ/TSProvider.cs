﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.Threading;
using System.Reflection.Emit;
using System.Reflection;
using System.Windows.Forms;
using System.Drawing;
using System.IO;
using SmartQuant.FIX;
using SmartQuant.Providers;
using SmartQuant.Instruments;
using SmartQuant.Data;
using SmartQuant.File;

namespace Drzwz.TS
{
    public class TSProvider : IProvider, IMarketDataProvider
    {
        private bool isConnected = false;
        private IBarFactory factory;
        private List<string> subscribedSymbols = new List<string>();
        TimerCallback UPDATEQT;
        System.Threading.Timer UPDTIMER;

        public TSProvider()
        {
            BarFactory = new BarFactory(false);
            ProviderManager.Add(this);
        }
        private string symbolRegex = @"(\w*\.(SQ|DQ|ZQ|CI))";
        [Category("设置"), Description("要增加的Instrument的正则表达式，若已存在，则不添加。"), DefaultValue("")]
        public string SymbolWillAdd
        {
            get { return this.symbolRegex; }
            set
            {
                this.symbolRegex = value.Trim();
            }
        }
        private string symbolFilter = @"(\w*\.(SH|SZ|SQ|DQ|ZQ|CI|HK|CB))";
        [Category("设置"), Description("只读取/处理符合正则表达式的代码。"), DefaultValue("")]
        public string SymbolFilter
        {
            get { return this.symbolFilter; }
            set
            {
                this.symbolFilter = value.Trim();
            }
        }

        #region IProvider 成员

        public void Connect(int timeout)
        {
            this.Connect();
            ProviderManager.WaitConnected(this, timeout);
        }

        public void Connect()
        {
            Singleton.RTdrv.DrvOpen();
            Singleton.RTdrv.SymbolRegex = this.symbolRegex;
            Singleton.RTdrv.SymbolFilter = this.symbolFilter;
            //foreach (string symbol in Singleton.RTdrv.StockNameList.Keys)
            //{
            //    Console.WriteLine("{0} {1}", symbol, Singleton.RTdrv.StockNameList[symbol]);
            //}

            UPDATEQT = new TimerCallback(updater);
            UPDTIMER = new System.Threading.Timer(UPDATEQT, null, 5000, 3000);

            this.isConnected = true;
            if (Connected != null) Connected(this, new EventArgs());
        }

        public event EventHandler Connected;

        public void Disconnect()
        {
            if (this.isConnected)
            {
                UPDTIMER.Dispose();
                Singleton.RTdrv.DrvClose();
                isConnected = false;
                if (Disconnected != null) Disconnected(this, new EventArgs());
            }
        }

        public event EventHandler Disconnected;

        public event ProviderErrorEventHandler Error;
        [Category("Info")]
        public byte Id
        {
            get { return 148; }
        }
        [Category("Info")]
        public bool IsConnected
        {
            get { return isConnected; }
        }
        [Category("Info")]
        public string Name
        {
            get { return "YT"; }
        }

        public void Shutdown()
        {
            try
            {
                Singleton.RTdrv.DrvClose();
            }
            catch
            {
            }
        }
        [Category("Info")]
        public ProviderStatus Status
        {
            get
            {

                if (!IsConnected)

                    return ProviderStatus.Disconnected;

                else

                    return ProviderStatus.Connected;

            }
        }

        public event EventHandler StatusChanged;
        [Category("Info")]
        public string Title
        {
            get { return "TS(YT) Provider"; }
        }
        [Category("Info")]
        public string URL
        {
            get { return string.Empty; }
        }

        #endregion

        #region IMarketDataProvider 成员
        [Category("Behavior")]
        public IBarFactory BarFactory
        {
            get
            {
                return this.factory;
            }
            set
            {
                if (this.factory != null)
                {
                    this.factory.NewBar -= new BarEventHandler(this.OnNewBar);
                    this.factory.NewBarOpen -= new BarEventHandler(this.OnNewBarOpen);
                    this.factory.NewBarSlice -= new BarSliceEventHandler(this.OnNewBarSlice);
                }
                this.factory = value;
                if (this.factory != null)
                {
                    this.factory.NewBar += new BarEventHandler(this.OnNewBar);
                    this.factory.NewBarOpen += new BarEventHandler(this.OnNewBarOpen);
                    this.factory.NewBarSlice += new BarSliceEventHandler(this.OnNewBarSlice);
                }
            }
        }

        public event MarketDataRequestRejectEventHandler MarketDataRequestReject;

        public event MarketDataSnapshotEventHandler MarketDataSnapshot;

        public event BarEventHandler NewBar;

        public event BarEventHandler NewBarOpen;

        public event BarSliceEventHandler NewBarSlice;

        public event CorporateActionEventHandler NewCorporateAction;

        public event FundamentalEventHandler NewFundamental;

        public event BarEventHandler NewMarketBar;

        public event MarketDataEventHandler NewMarketData;

        public event MarketDepthEventHandler NewMarketDepth;

        public event QuoteEventHandler NewQuote;

        public event TradeEventHandler NewTrade;

        public void SendMarketDataRequest(FIXMarketDataRequest request)
        {
            if (!IsConnected)
            {
                this.Connect();
            }
            switch (request.SubscriptionRequestType)
            {

                case DataManager.MARKET_DATA_SUBSCRIBE:

                    for (int i = 0; i < request.NoRelatedSym; i++)
                    {

                        FIXRelatedSymGroup group = request.GetRelatedSymGroup(i);

                        RequestSymbol(group.Symbol);
                        //Console.WriteLine(group.Symbol);
                    }

                    break;

                case DataManager.MARKET_DATA_UNSUBSCRIBE:

                    for (int i = 0; i < request.NoRelatedSym; i++)
                    {

                        FIXRelatedSymGroup group = request.GetRelatedSymGroup(i);

                        UnsubscribeSymbol(group.Symbol);

                    }

                    break;

                default:

                    throw new ArgumentException("Unknown subscription type: " + request.SubscriptionRequestType.ToString());

            }
        }

        /////////////////////
        private void RequestSymbol(string symbol)
        {

            if (!subscribedSymbols.Contains(symbol))
                subscribedSymbols.Add(symbol);

        }
        private void UnsubscribeSymbol(string symbol)
        {

            if (subscribedSymbols.Contains(symbol))
                subscribedSymbols.Remove(symbol);

            //if (subscribedSymbols.Count == 0 )
            //{
            //}

        }

        private void updater(object state)
        {

            ProcessQuotes(); //计时器处理
        }
        private void ProcessQuotes()
        {
            
            try
            {
                string symbol;
                float LastClose;
                for (int j = subscribedSymbols.Count - 1; j > -1; j--)
                {
                    bool isNewTrade = true;
                    bool isNewQuote = true;
                    Trade td = new Trade();
                    Quote qt = new Quote();
                    symbol = subscribedSymbols[j];
                    //Console.WriteLine("ProcessQuotes:{0} 需要修改。。。。",symbol);
                    Instrument instrument = InstrumentManager.Instruments[symbol];
                    LastClose = Singleton.RTdrv.symbo_lastclose(symbol);
                    SortedList<DateTime, RCV_REPORT_STRUCTExV3_DETAIL> detailList = Singleton.RTdrv.GetRTData(symbol);
                    if (detailList.Count > 0)
                    {
                        DateTime dt = detailList.Keys[detailList.Count-1];
                        td.DateTime = dt;
                        qt.DateTime = dt;  
                        td.Price = detailList.Values[detailList.Count - 1].m_fNewPrice;
                        td.Size = (int)detailList.Values[detailList.Count - 1].m_fVolume;
                        qt.Bid = detailList.Values[detailList.Count - 1].m_fBuyPrice1;
                        qt.BidSize = (int) detailList.Values[detailList.Count - 1].m_fBuyVolume1;
                        qt.Ask = detailList.Values[detailList.Count - 1].m_fSellPrice1;
                        qt.AskSize = (int) detailList.Values[detailList.Count - 1].m_fSellVolume1;
                        if (td.Size > 0) //需要进一步修改
                        {
                            isNewTrade = true;
                            isNewQuote = true;
                        }
                        
                    }
                    if (NewTrade != null && isNewTrade )
                    {
                        TradeEventArgs tdarg = new TradeEventArgs(td, instrument, this);
                        NewTrade(this, tdarg);
                        //BarHandler bhdlr = new BarHandler(MakeBar);
                        //bhdlr.BeginInvoke(instrument, td, null, null);

                        //if (this.factory != null)
                        //{
                        //    //ThreadPool .QueueUserWorkItem(new WaitCallback (this.factory.OnNewTrade),
                        //    this.factory.OnNewTrade(instrument, td);
                        //}
                    }
                    if (NewQuote != null && isNewQuote)
                    {
                        QuoteEventArgs qtarg = new QuoteEventArgs(qt, instrument, this);
                        NewQuote(this, qtarg);
                    }

                }
            }
            catch (Exception ex)
            {
                StMyFunction.textwrite(string.Format("{0}\t ProcessQuotes() ErrorMsg:{1}"
                                              , DateTime.Now, ex.Message));
            }
        }


        private void EmitError(int id, int code, string message)
        {
            if (this.Error != null)
            {
                this.Error(new ProviderErrorEventArgs(this, id, code, message));
            }

            //if (Error != null)

            //    Error(new ProviderErrorEventArgs(new ProviderError(DateTime.Now, this, id, code, message)));

        }
        private void OnNewBar(object sender, BarEventArgs args)
        {
            if (this.NewBar != null)
            {
                this.NewBar(this, new BarEventArgs(args.Bar, args.Instrument, this));
            }
        }
        private void OnNewBarSlice(object sender, BarSliceEventArgs args)
        {
            if (this.NewBarSlice != null)
            {
                this.NewBarSlice.Invoke(this, new BarSliceEventArgs(args.BarSize, this));
            }
        }
        private void OnNewBarOpen(object sender, BarEventArgs args)
        {
            if (this.NewBarOpen != null)
            {
                this.NewBarOpen(this, new BarEventArgs(args.Bar, args.Instrument, this));
            }
        }
        #endregion
    }
}
