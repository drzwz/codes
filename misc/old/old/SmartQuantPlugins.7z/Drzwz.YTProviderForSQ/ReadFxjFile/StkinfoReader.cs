using System;
using System.IO;
using System.Text;
using System.Collections.Generic;

namespace Drzwz.TS
{
	/// <summary>
	/// 
	/// </summary>
	public class StkinfoReader
	{
		private BinaryReader _br; 
		protected string _sFileName;
		private int _stockcount;//֤ȯ��¼����
		string _symbol;
		string _symbolname;
		protected bool _bOpen = false;
		private long  _lPosition =1; //��ǰ��λ��
		private long  _startaddress;  //�������ݿ�ʼ��ַ 0x001DD968
		private FinanceStruct  _data;
		private int _FileVer;
		private long quoterecsize;//�����¼��С
		private long financerecsize;//�����¼��С��
		private int financereccount;
		
		bool _findit=false; 
		private long _findsymbolposition;

        #region ˽������
        private  void Close()
		{
			_bOpen = false;
			_br.Close();
			_br = null;
		}



        private  void Open(int filever, string mainpath)
		{
            _FileVer = filever;
            switch (_FileVer)
            {   //stkinfo5 1�����¼=248Byte stkinfo=176byte,
                case 1://ver is 5.0
                    _startaddress = 0x001DD968;
                    quoterecsize = 208;
                    financerecsize = 0x1DC;//476byte
                    financereccount = 16;
                    _sFileName = "stkinfo5.dat";
                    break;
                case 2://ver is 2005(5.1) 2006
                    _startaddress = 0x00845898;
                    quoterecsize = 248;
                    financerecsize = 0x844;
                    financereccount = 96;
                    _sFileName = "stkinfo51.dat";
                    break;
                case 3://ver is 4.X
                    _startaddress = 0x001DD968;
                    quoterecsize = 176;
                    financerecsize = 0x140;
                    financereccount = 16;
                    _sFileName = "stkinfo.dat";
                    break;
                default:
                    break;
            }
            _sFileName = mainpath + _sFileName;
            //StMyFunction.textwrite(_sFileName);
            if (File.Exists(_sFileName))
            { 
			FileStream fs = new FileStream(_sFileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			_br = new BinaryReader(fs);
			this.stockcountread(); //��ȡ֤ȯ����
			_br.BaseStream.Seek(_startaddress,SeekOrigin.Begin);
			_lPosition = 1;
			_bOpen = true;
            }
		}

		private  bool read()   //�������¼���ж�֤ȯ���뼰����
		{
		    

			if(_bOpen && (_lPosition<(long)_stockcount) )
			{
				_symbol=System.Text.Encoding.ASCII .GetString (_br.ReadBytes(10)); //֤ȯ����
				_symbolname=System.Text.Encoding.GetEncoding("GB2312").GetString(_br.ReadBytes(32));//֤ȯ����
				_lPosition =_lPosition+1; //
				_br.BaseStream.Seek(_startaddress+(_lPosition-1)*quoterecsize,SeekOrigin.Begin);
				return true;
			}
			else
			{
				return false;
			}
		}

		private  void stockcountread()
		{
			_br.BaseStream.Seek(0x8,SeekOrigin.Begin);
			_stockcount=_br.ReadInt32();
		}

		

		private  bool seeksymbol(string symbol)
		{
			long tempcurrpostion=_br.BaseStream.Position;
			_br.BaseStream.Seek(_startaddress,SeekOrigin.Begin);
			_lPosition = 1;
			_findit=false;
            if (_bOpen)
            {
                while (this.read())
                {
                    if (string.Compare(_symbol.TrimEnd(), symbol.TrimEnd()) == 0)
                    {
                        _findit = true;
                        break;
                    }
                    else
                    {
                        _findit = false;
                    }
                }
                _br.BaseStream.Seek(tempcurrpostion, SeekOrigin.Begin);
                _findsymbolposition = _lPosition;
                //StMyFunction .textwrite(string.Format ("seeksymbol 's _lPosition is {0}", _lPosition ));
            }
			return _findit;
		}

		private  List<FinanceStruct> financeread()
		{
            List<FinanceStruct> templist = new List<FinanceStruct>();
            if (_bOpen)
            {
               
                long tempcurrpostion = _br.BaseStream.Position;
                long temp1_lPosition = _findsymbolposition;
                ushort temprecount;
                ushort unpack;
                DateTime unpacknum;

                int finace_reccount; //��Ȩ�ĸ���
                if (_findit)  //����ҵ������֤ȯ����  ��Դ seeksymbol()
                {
                   
                    _br.BaseStream.Seek(0xc + (temp1_lPosition - 2) * financerecsize, SeekOrigin.Begin);
                    temprecount = _br.ReadUInt16();
                    finace_reccount = (int)temprecount;
                    //StMyFunction.textwrite(string.Format("position: {1} temprecount: {0}  Size :{2} ", temprecount, temp1_lPosition,  financerecsize));
                  


                    if (finace_reccount > 0 && finace_reccount <= financereccount)  //
                    {
                        unpack = _br.ReadUInt16();  //��2���ַ�

                        if (_FileVer == 2) //�����fxj2005
                        {
                            unpacknum = new DateTime(1970, 1, 1).AddSeconds((double)(_br.ReadInt32()));
                        }
                        for (int i = 0; i < finace_reccount; i++)
                        {
                            _data = FinanceStruct.read(_br);
                            templist.Add(_data);
                        }
                    }

                }

                _br.BaseStream.Seek(tempcurrpostion, SeekOrigin.Begin);
            }
			return templist; //����
        }
#endregion
        #region ��������
        public List<string> GetSymbolList(int FileVer,string FxjPath) 
        {
            List<string> symbollists = new List<string>();
            try
            {
                //�����ڴ��롡
                this.Open(FileVer, FxjPath + "\\data\\SZ\\");
                while (this.read())
                {
                    symbollists.Add(_symbol.Remove(6, 4) + ".SZ");
                }
                this.Close();

                //���Ϻ�����

                this.Open(FileVer, FxjPath + "\\data\\SH\\");
                while (this.read())
                {
                    symbollists.Add(_symbol.Remove(6, 4) + ".SH");
                }
                this.Close();
            }
            catch (Exception ex) 
            { 
             StMyFunction.textwrite(string.Format("ʱ�䣺{0}\t��GetSymbollists ��������\t ������Ϣ��{1}",DateTime.Now ,ex.Message));
            }
            return symbollists;
        }

        public string GetSymbolName(int FileVer,string FxjPath, string Symbol) 
        {
            string SymbolName = string.Empty;
            try
            {
                if (Symbol.EndsWith(".SZ"))
                {
                    this.Open(FileVer, FxjPath + "\\data\\SZ\\");
                }
                else
                {
                    this.Open(FileVer, FxjPath + "\\data\\SH\\");
                }

                if (this.seeksymbol(Symbol.Remove(6, 3)))
                {
                    SymbolName = this._symbolname;
                }
                this.Close();
            }
            catch (Exception ex) 
            {
                StMyFunction.textwrite(string.Format("{0}\t Symbol:{1} ���� getsymbolname :{2}", DateTime.Now, Symbol,ex.Message )); 
            }
            return SymbolName;
        }

        public List<FinanceStruct> GetFinanceData(int FileVer, string FxjPath, string Symbol) 
        { 
          List<FinanceStruct>  finacedatalist=new  List<FinanceStruct> ();
          if (Symbol.EndsWith(".SZ"))
          {
              this.Open(FileVer, FxjPath + "\\data\\SZ\\");
          }
          else
          {
              this.Open(FileVer, FxjPath + "\\data\\SH\\");
          }
          
          
          if (this.seeksymbol(Symbol.Remove(6, 3)))
          {
              finacedatalist = this.financeread();	
              //StMyFunction .textwrite (string .Format ("{0} ����Ϊ{1}",Symbol  ,finacedatalist .Count ));
          }
          this.Close();

          return finacedatalist;

        }
        #endregion
    }
}
