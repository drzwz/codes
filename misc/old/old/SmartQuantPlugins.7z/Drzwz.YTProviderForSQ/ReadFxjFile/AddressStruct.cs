using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text ;
namespace Drzwz.TS
{
	/// <summary>
	/// DataAddress ��ժҪ˵����
	/// ���������ṹ
	/// 
	/// </summary>
	public struct AddressStruct
	{
		
		public string  stockcode; //֤ȯ����
		public int daycount;   //��������
		[MarshalAs(UnmanagedType.ByValArray,SizeConst=25)]
		public  ushort []  words; //���ߴ���λ�ã���ţ�=0x41000+��¼���*8*1024k 


		public static AddressStruct ReadAddressStruct(BinaryReader br)
		{
          
          ushort [] tempwords=new ushort[25];
		  
		  AddressStruct s =new AddressStruct();
	      s.stockcode  =System.Text.Encoding.ASCII .GetString (br.ReadBytes(10));
		  s.daycount=br.ReadInt32();
		
		   	for (int j=0;j<25;j++)
				{
				tempwords[j]=br.ReadUInt16();
				}
			
			
			s.words=tempwords;

		  return s;

		}
	}
}
