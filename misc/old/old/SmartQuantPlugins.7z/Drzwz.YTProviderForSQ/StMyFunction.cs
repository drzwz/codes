using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Win32;
using System.IO;
using System.Xml;
using System.Xml.XPath;


namespace Drzwz.TS
{
   public static class StMyFunction
    {
       
       public static  SortedList<DateTime, WLDTBar_STRUCT> tick2min(SortedList<DateTime, WLDTBar_STRUCT> tickbars, int interval, bool isnetvol)
		{
            SortedList<DateTime, WLDTBar_STRUCT> Tbars = new  SortedList<DateTime,WLDTBar_STRUCT> ();
            List<WLDTBar_STRUCT> templist = new List<WLDTBar_STRUCT>();
			DateTime comparetime;
			
			if (tickbars.Count>0)
			{
			    
				DateTime temptime=tickbars.Keys [0];
				comparetime=comparetime_for_min(temptime,interval);
				
				//��ǰʱ����Ƚ�ֵ֮���Ƿ���interval ��
				for(int i=0;i<tickbars.Count;i++)
				{
				   DateTime bargain_time=(DateTime)tickbars.Keys [i];
				   TimeSpan compareinterval=bargain_time-comparetime;
					
					if ((compareinterval.TotalMinutes)<interval)
					{
						templist.Add(tickbars.Values [i]);
						if (i==tickbars.Count-1)   
						{								
							DateTime  Tbars_time=new DateTime(comparetime.Year ,comparetime.Month,comparetime.Day,comparetime.Hour ,comparetime.Minute ,0);
							
                            if (Tbars.ContainsKey(Tbars_time))
							{   //����Ѵ���ʱ������ݣ��͸���
								Tbars[Tbars_time]=change_tick_to_minute(templist,isnetvol);
							}
							else
							{
								Tbars.Add(Tbars_time,change_tick_to_minute(templist,isnetvol));
							}
							templist.Clear();
						}
					}
					else
					{
						DateTime  Tbars_time=new DateTime(comparetime.Year ,comparetime.Month,comparetime.Day,comparetime.Hour ,comparetime.Minute ,0);
						if (Tbars.ContainsKey(Tbars_time))
						{
							Tbars[Tbars_time]=change_tick_to_minute(templist,isnetvol);
						}
						else
						{
							Tbars.Add(Tbars_time,change_tick_to_minute(templist,isnetvol));
						}
						//ȷ����һ���Ƚ�ֵ
						comparetime=comparetime_for_min(bargain_time,interval);
						templist.Clear();
						templist.Add(tickbars.Values[i]);

					}
				}

			} 
			return Tbars;
		}
		
		//�ҳ���ǰĳʱ����ڿ��̼ۡ���߼ۡ���ͼۡ����̼ۡ��ۼƳɽ���
       public static  WLDTBar_STRUCT change_tick_to_minute(List<WLDTBar_STRUCT> data, bool isnetvol) 
		{
            List<WLDTBar_STRUCT> templist = data;
			WLDTBar_STRUCT  data_min=new WLDTBar_STRUCT() ;
			if (templist.Count>0)
			{
				float Xhigh=0;
				float Xlow=0;
				int amountvol=0;
				for (int i=0;i<templist.Count;i++)
				{  
					WLDTBar_STRUCT tempdata=templist[i];
					if (i==0)
					{
						data_min.fOpen=tempdata.fOpen;
						Xhigh=tempdata.fClose;
						Xlow=tempdata.fClose;
					}
					else 
					{
						if (tempdata.fClose>Xhigh)
						{
							Xhigh=tempdata.fClose;
						}
						if (tempdata.fClose<Xlow)
						{
							Xlow=tempdata.fClose;
						}

					}
					//�ۼƳɽ���
					amountvol+=(int)tempdata.fVolume;
					if (i==(templist.Count-1))
					{
						data_min.fClose=tempdata.fClose;
						data_min.fBid=tempdata.fBid;
						data_min.fAsk=tempdata.fBid;
						if (isnetvol)
						{
							data_min.fVolume=amountvol;
						}
						else
						{
							data_min.fVolume=(int)tempdata.fVolume;
						}
					}
				} 
				data_min.fHigh=Xhigh;
				data_min.fLow=Xlow;
				 
				 

			}
			return data_min;
		}

		////ʵʱ�����ۼƳɽ���ת��ʵ�ɽ���
        public static SortedList<DateTime, WLDTBar_STRUCT> vol_to_netvol(SortedList<DateTime, WLDTBar_STRUCT> data)
		{
			int prevol=0;
            DateTime predt = new DateTime(1970, 1, 1); ;
            SortedList<DateTime, WLDTBar_STRUCT> templist = data;
			if (templist!=null)
			{
                
				for (int i=0;i<templist.Count;i++)
				{
					WLDTBar_STRUCT oldbars=templist.Values[i];
					WLDTBar_STRUCT newbars=new WLDTBar_STRUCT ();
                     
					newbars.fOpen=oldbars.fOpen;
					newbars.fHigh=oldbars.fHigh;
					newbars.fLow=oldbars.fLow;
					newbars.fClose=oldbars.fClose;
					newbars.fBid=0;
					newbars.fAsk=0;
                    //�ж��Ƿ�Ϊͬһ������
                    if (templist.Keys[i].Date  > predt.Date )
                    {
                        newbars.fVolume = oldbars.fVolume;
                    }
                    else
                    { 
                        newbars.fVolume = oldbars.fVolume - prevol; 
                    }

                    prevol=oldbars.fVolume;
                    predt = templist.Keys[i]; 
					templist[templist.Keys[i]]=newbars; 

				}

			}

			return templist;
		}

		public static DateTime comparetime_for_min(DateTime inputtime,int interval)
		{
			DateTime comparetime;
			DateTime temptime=inputtime;
			//ȷ���Ƚ�ֵ
			if (((temptime.Minute) % interval)==0)
			{
				comparetime=new DateTime(temptime.Year ,temptime.Month,temptime.Day,temptime.Hour ,temptime.Minute ,0);
			}
			else
			{//�ж��Ƿ�����0-interval 
				if (temptime.Minute <interval)
				{   //���ǱȽ�ֵΪyy:MM:HH:0:0
					comparetime=new DateTime(temptime.Year,temptime.Month,temptime.Day,temptime.Hour,0,0);
				}
				else
				{
					int tempint=(temptime.Minute) % interval;
					comparetime=new DateTime(temptime.Year,temptime.Month,temptime.Day,temptime.Hour,temptime.Minute-tempint,0);
				}
			}
			return comparetime;
		}

       public static string [] GetFxjPath()
       {
           string [] fxjdata=new string [2];
        //��ע�������ȡfxj6.0��·��
            RegistryKey rk = Registry.LocalMachine.OpenSubKey("SOFTWARE\\fxj\\SUPERSTK", true);
            if (rk != null)
            {
                fxjdata[0] = (String)rk.GetValue("InstPath");
                fxjdata[1] = "2";//fxj2005,fxj2006
               
            }
            else
            {
                rk = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Huitianqi\\SUPERSTK", true);
                if (rk != null)
                {
                    fxjdata [0] = (String)rk.GetValue("InstPath");
                    fxjdata [1] = "1"; //fxj 5.0
                }
            }
            return fxjdata;
       }

       public static void textwrite(string ErrText)
       {

           string FileName = Directory.GetCurrentDirectory() + "//TSProviderLog.txt";

           Stream fstream = new FileStream(FileName, FileMode.OpenOrCreate);
           StreamWriter sw = new StreamWriter(fstream, Encoding.GetEncoding("GB2312"));

           sw.BaseStream.Seek(1, SeekOrigin.End);
           sw.WriteLine(ErrText);
           sw.Close();
           fstream.Close();
       }
       public static string GetStockFileName()
       {
           string DLLPATH = string.Empty;
           RegistryKey rk = Registry.LocalMachine.OpenSubKey("SOFTWARE\\SkyJet", true);
           if (rk != null)
           {
               DLLPATH = (String)rk.GetValue("Driver");
           }
           return DLLPATH;
           //string FileName = string.Empty;
           //try
           //{
           //    XmlDocument myDoc = new XmlDocument();
           //    myDoc.Load("HyltConfig.xml");

           //    XPathNavigator nav = myDoc.CreateNavigator();


           //    XPathNodeIterator nodeIterator = nav.Select("//RtConfig/*");

           //    while (nodeIterator.MoveNext())
           //    {
           //        if (nodeIterator.Current.Name.Trim() == "RtPath")
           //        {
           //            FileName = nodeIterator.Current.Value;
           //            break;
           //        }
           //    }
           //}
           //catch (Exception ex) 
           //{
           //    textwrite("Open HyltConfig.xml error \t" + ex.Message);
           //}
           //return FileName;
       }
    }
}
