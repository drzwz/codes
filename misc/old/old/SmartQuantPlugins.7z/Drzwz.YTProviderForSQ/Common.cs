using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;


namespace Drzwz.TS
{

    #region ����������
    public class Consts
    {
        public const int biMinutes = 0;
        public const int biDaily = 1;
        public const int biTicks = 2;
        public const int biSeconds = 3;
        public const int biWeekly = 4;
        public const int biMonthly = 5;
        public const int biYearly = 6;
        public const int bi5Mins = 7;//for cache use only

        
        
        public const int securityStock = 0;
        public const int secutiryFuture = 1;

        public const int posLong = 0;
        public const int posShort = 1;

        
    }

    public enum BrokerInfoType 
    { 
        brokerTradeSuccess ,brokerTradeFailure ,brokerTradeFill ,
        brokerCancelSuccess , brokerCancelFailure ,brokerTradeFillAll , brokerConnectionLost ,brokerAccountInfo
    }
    public enum OrderTypeEnum { orderMarket , orderLimit ,orderStop }
    public enum AlertTypeEnum {alertBuy , alertSell ,alertShort ,alertCover }
    public enum BarIntervalEnum  {biMinutes,biDaily ,biTicks ,biSeconds,biWeekly ,biMonthly}
}
#endregion
    # region ʵʱ�����ռ���
    public class RTCollector
    {
        private Dictionary<string, Dictionary<DateTime, RCV_REPORT_STRUCTExV3_DETAIL>> STOCKDATA = new Dictionary<string, Dictionary<DateTime, RCV_REPORT_STRUCTExV3_DETAIL>>();

        public RTCollector()
        {
            //
            // TODO: �ڴ˴����ӹ��캯���߼�
            //
            
        }

        public void addData(string StockCode, DateTime M_time, RCV_REPORT_STRUCTExV3_DETAIL Stock_Rt_Data)
        {
            lock (STOCKDATA)
            {
                if (StockCode != "" )  
                {
                    if (!STOCKDATA.ContainsKey(StockCode))
                    {
                        STOCKDATA.Add(StockCode, new Dictionary<DateTime, RCV_REPORT_STRUCTExV3_DETAIL>());
                    }


                    Dictionary<DateTime, RCV_REPORT_STRUCTExV3_DETAIL> stockdata = STOCKDATA[StockCode];



                    if (stockdata.ContainsKey(M_time))
                    {
                        if (stockdata[M_time].m_fVolume > Stock_Rt_Data.m_fVolume)//����ۼƳɽ������ڴ���ֵ����ǰʱ��+1 tick����������ֵ
                        {
                            RCV_REPORT_STRUCTExV3_DETAIL tempdata = stockdata[M_time];
                            stockdata[M_time] = Stock_Rt_Data;
                            stockdata.Add(M_time.AddTicks(1),tempdata );
                        }
                        else
                        { 
                            if (stockdata[M_time].m_fVolume < Stock_Rt_Data.m_fVolume) { stockdata.Add(M_time.AddTicks(1), Stock_Rt_Data); }
                            //����ֵʱ�䣫1 tick
                        }
                    }
                    else
                    {
                        stockdata.Add(M_time, Stock_Rt_Data);  //���������M_time,����������
                    }

                }
            }
        }




        public SortedList<DateTime, RCV_REPORT_STRUCTExV3_DETAIL> GetRtTick(string StockCode)
        {
            SortedList<DateTime, RCV_REPORT_STRUCTExV3_DETAIL> tempsl = new  SortedList<DateTime,RCV_REPORT_STRUCTExV3_DETAIL>();
            if (StockCode != "")
            {
                lock (STOCKDATA)
                {
                    if (STOCKDATA.ContainsKey(StockCode))
                    {
                        tempsl.Capacity = STOCKDATA[StockCode].Count;

                        foreach (DateTime temptime in STOCKDATA[StockCode].Keys )
                        {
                            tempsl.Add(temptime, STOCKDATA[StockCode][temptime]);
                        }

                    }
                    
                }
            }
            return tempsl;
        }
    }
    # endregion ʵʱ�����ռ���
    #region ί�ж��� �������֪ͨ
    public class NewBarEventArgs : EventArgs
    {
        public string Symbol;
        public DateTime TimeStamp;
        public WLDTBar_STRUCT BarData;
        public int Amountvol;//�ۼƳɽ���
        public Drzwz.TS.BarIntervalEnum BarScale;
        public int BarInterval;
        public bool IsCompletedBar;

        public NewBarEventArgs(string symbol, WLDTBar_STRUCT bar, int amountvol, DateTime dt, Drzwz.TS.BarIntervalEnum tf, int interval, bool iscomleted)
        {
            Symbol = symbol;
            BarData = bar;
            Amountvol = amountvol;
            TimeStamp = dt;
            BarScale = tf;
            BarInterval = interval;
            IsCompletedBar = iscomleted;
        }
    }

    public delegate void NewBarEventHandler(object  sender, NewBarEventArgs e);


    #endregion
    #region ͨ������ṹ
    //��������ṹ��ϸ (������Ʊ���룬���ƣ�ʱ�䣩  
    //��ͨ������ṹ��Ϊ�ļ�ͷ����ϸ����������
    [StructLayout(LayoutKind.Explicit)]
    public struct RCV_REPORT_STRUCTExV3_HEAD
    {
        [FieldOffset(0)]
        public System.UInt16 m_cbSize;							// �ṹ��С
        [FieldOffset(2)]
        public System.UInt32 m_time;										// �ɽ�ʱ��
        [FieldOffset(6)]
        public System.UInt16 m_wMarket;							// ��Ʊ�г�����

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 42)]
        [FieldOffset(8)]
        public char[] m_szLabelName;					// ��Ʊ����,��'\0'��β
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct RCV_REPORT_STRUCTExV3_DETAIL
    {
        public System.Single m_fLastClose;								// ����
        public System.Single m_fOpen;									// ��
        public System.Single m_fHigh;									// ���
        public System.Single m_fLow;										// ���
        public System.Single m_fNewPrice;								// ����
        public System.Single m_fVolume;									// �ɽ���
        public System.Single m_fAmount;									// �ɽ���


        public System.Single m_fBuyPrice1;								// �����1
        public System.Single m_fBuyPrice2;								// �����2
        public System.Single m_fBuyPrice3;								// �����3
        public System.Single m_fBuyVolume1;							// ������1
        public System.Single m_fBuyVolume2;							// ������2
        public System.Single m_fBuyVolume3;							// ������3
        public System.Single m_fSellPrice1;							// ������1
        public System.Single m_fSellPrice2;							// ������2
        public System.Single m_fSellPrice3;							// ������3
        public System.Single m_fSellVolume1;							// ������1
        public System.Single m_fSellVolume2;							// ������2
        public System.Single m_fSellVolume3;							// ������3
        public System.Single m_fBuyPrice4;								// �����4
        public System.Single m_fBuyVolume4;								// ������4
        public System.Single m_fSellPrice4;								// ������4
        public System.Single m_fSellVolume4;								// ������4

        public System.Single m_fBuyPrice5;								// �����5
        public System.Single m_fBuyVolume5;								// ������5
        public System.Single m_fSellPrice5;								// ������5
        public System.Single m_fSellVolume5;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct RCV_DATA
    {
        public System.Int32 m_wDataType;			// �ļ�����
        public System.Int32 m_nPacketNum;			// ��¼��,�μ�עһ
        public RCV_FILE_HEADEx m_File;					// �ļ��ӿ�
        public System.Int32 m_bDISK;
        //			[ MarshalAs( UnmanagedType.LPArray)]
        //			public RCV_REPORT_STRUCTExV3[] rpt;
        //			[ MarshalAs( UnmanagedType.AsAny)]
        public IntPtr ptr;
        //			public rcvdata data;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct RCV_FILE_HEADEx
    {
        public System.UInt32 m_dwAttrib;							// �ļ�������
        public System.UInt32 m_dwLen;							// �ļ�����
        public System.UInt32 m_dwSerialNo;						// ���к�
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
        public string m_szFileName;				// �ļ��� or URL
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct tagRCV_MINUTE_STRUCTEx
    {
        public System.UInt32 m_time;                 // Uct
        public System.Single m_fPrice;
        public System.Single m_fVolume;
        public System.Single m_fAmount;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct tagRCV_MINUTE_STRUCTEx_Detail
    {
        public System.Single m_fPrice;
        public System.Single m_fVolume;
        public System.Single m_fAmount;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct tagRCV_EKE_HEADEx
    {
        public System.UInt32 m_dwHeadTag;                  // = EKE_HEAD_TAG
        public System.UInt16 m_wMarket;                    // �г�����

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 10)] // ��Ʊ����
        public string m_szLabel;

    }

    [StructLayout(LayoutKind.Sequential)]
    public struct tagRCV_TICK_STRUCTEx
    {
        public System.UInt32 m_time;                 // Uct

        public System.Single m_fNewPrice;								// ����
        public System.Single m_fVolume;									// �ɽ���

    }

    [StructLayout(LayoutKind.Sequential)]
    public struct WLDTBar_STRUCT               //WLD K�߽ṹ
    {

        public float fOpen;			//���̼�
        public float fHigh;			//��߼�		
        public float fLow;				//��ͼ�
        public float fClose;			//���̼�
        public int fVolume;	       //�ɽ���
       
        public float fBid;             //���
        public float fAsk;             //����
    }


    public struct tagRCV_HISTORY_STRUCTEx
    {
        public System.UInt32 m_time;
        public System.Single m_fnewprice;			//�ɽ���
        public System.Single m_fVolume;			//��
        public System.Single m_fAmount;			//��
        public System.Single m_fBuyPrice1;								// �����1
        public System.Single m_fBuyPrice2;								// �����2
        public System.Single m_fBuyPrice3;								// �����3
        public System.Single m_fSellPrice1;							// ������1
        public System.Single m_fSellPrice2;							// ������2
        public System.Single m_fSellPrice3;							// ������3
        public System.Single m_fBuyVolume1;							// ������1
        public System.Single m_fBuyVolume2;							// ������2
        public System.Single m_fBuyVolume3;							// ������3


    }

    //zzzzzzzzzzzzzzz
    [StructLayout(LayoutKind.Sequential)]
    public struct HistoryData
    {
        public System.UInt32 m_time; //UCT
        public float m_fOpen; //����
        public float m_fHigh; //���
        public float m_fLow; //���
        public float m_fClose; //����
        public float m_fVolume; //��
        public float m_fAmount; //��
        public System.UInt16 m_wAdvance; //����,��������Ч
        public System.UInt16 m_wDecline; //����,��������Ч

    }

    [StructLayout(LayoutKind.Sequential)]
    public struct RCV_HISTORY_STRUCTEx
    {
        //[FieldOffset(0)]
        public HistoryData H;

        //[FieldOffset(0)]
        public tagRCV_EKE_HEADEx m_head;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct RCV_HISTORY_STRUCTEx_tag
    {
        public tagRCV_EKE_HEADEx m_head;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct RCV_HISTORY_STRUCTEx_data
    {
        public HistoryData data;
    }
   //zzzzzzzzzzzzzzzzzzzzz



    #endregion 
    #region ί��ָ����
    public struct OrderAlert
    {
        public int OrderID;
        public String Symbol;
        public int Shares;
        public int Position;
        public int Order;
        public double Price;
        public OrderAlert(int id, String sym, int shares, int p, int o, double price)
        {
            OrderID = id;
            Symbol = sym;
            Shares = shares;
            Position = p;
            Order = o;
            Price = price;
        }
    }
#endregion

