using System;
using System.Collections.Generic;
using System.Text;

namespace Drzwz.TSCommon
{
   public static class Singleton

    {
        static readonly TongShiWindow TsW = new TongShiWindow ();
        public static TongShiWindow RTdrv 
        {
            get
            {
                return TsW;
            }
        }
    }
}
