using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Reflection.Emit;
using Microsoft.Win32;
using System.IO;



namespace Drzwz.TSCommon
{
    public partial class TongShiWindow : UserControl
    {
        
        private bool Drvloaded = false;
        private const int RCV_REPORT = 0x3f001234;
        private const int RCV_FILEDATA = 0x3f001235;

        private const int FILE_HISTORY_EX = 2;   // ����������
        private const int FILE_MINUTE_EX = 4;// ������������
        private const int FILE_POWER_EX = 6;   // �����Ȩ����
        private const int FILE_MIN5_EX = 81; // ��5��������
        private const int FILE_MIN1_EX = 82; // ��1��������
        private const int FILE_BASE_EX = 0x1000; // Ǯ�����ݻ��������ļ�,m_szFileName�������ļ���
        private const int FILE_NEWS_EX = 0x1002; // ������,��������m_szFileName����Ŀ¼������
        private const int FILE_HTML_EX = 0x1004; // HTML�ļ�,m_szFileNameΪURL
        private const int FILE_TICK_EX = 83;

        private const int TSMSG = 55;

        private const ushort SHMKT = 18515; //�Ϻ�
        private const ushort SZMKT = 23123; //����
        private const ushort SHFMKT = 20819; //����
        private const ushort DCEMKT = 20804; //����
        private const ushort CZCMKT = 20826; //֣��
        private const ushort CFFMKT = 18755; //��ָ�ڻ����н�����

        event NewBarEventHandler OnNewBar; //������watchlist ��Ĺ�Ʊ�Ƿ�����bar�¼�
        SortedList<string,int> watchlist = new SortedList<string,int>(); //�򵥵Ĺ۲��嵥��������TICK��ʾ
        RTCollector stockst = new RTCollector();

        private string dllpath ;


        public SortedList<string, string> StockNameList = new SortedList<string, string>();
        internal delegate int LoadDll(int hWnd, uint Msg, int nWorkMode);
        internal delegate int UnLoadDll(int hWnd);
        [DllImport("kernel32.dll")]
        internal static extern IntPtr LoadLibrary(String dllname);
        [DllImport("kernel32.dll")]
        internal static extern IntPtr GetProcAddress(IntPtr hModule, String procname);
        
       
        private IntPtr libraryHandle;
  
        private bool disposed = false;

       
        /*
         * 1.����dll��һ�ַ���(��̬�� ʹ��dllimport
        //��dllimport ·������Ϊ��̬
       
         [DllImport(@"D:\scengine\SCStock.dll", CharSet = CharSet.Auto)]
          public static extern int Stock_Init(int hWnd, uint Msg, int nWorkMode);

         [DllImport(@"D:\scengine\SCStock.dll", CharSet = CharSet.Auto)]
          public static extern int Stock_Quit(int hWnd);
        
         2.��2�ַ�������̬��
         * 
         * 
         * private object Dynamicdll(string DllPath, string EntryPoint, object[] ParameterValues)
         {

             string entryPoint = EntryPoint;
             Type[] parameterTypes = new Type[ParameterValues.Length];
             for (int i = 0; i < ParameterValues.Length; i++)
             {
                 parameterTypes[i] = ParameterValues[i].GetType();
             }
             object[] parameterValues = new object[ParameterValues.Length];
             parameterValues = ParameterValues;


             // Create a dynamic assembly and a dynamic module
             AssemblyName asmName = new AssemblyName();
             asmName.Name = "tempDll";
             AssemblyBuilder dynamicAsm =
               AppDomain.CurrentDomain.DefineDynamicAssembly(asmName,
               AssemblyBuilderAccess.Run);
             ModuleBuilder dynamicMod =
               dynamicAsm.DefineDynamicModule("tempModule");

             // Dynamically construct a global PInvoke signature 
             // using the input information
             MethodBuilder dynamicMethod = dynamicMod.DefinePInvokeMethod(
               entryPoint, DllPath, MethodAttributes.Static | MethodAttributes.Public
               | MethodAttributes.PinvokeImpl, CallingConventions.Standard,
               null, parameterTypes, CallingConvention.Winapi, CharSet.Ansi);

             // This global method is now complete
             dynamicMod.CreateGlobalFunctions();

             // Get a MethodInfo for the PInvoke method
             MethodInfo mi = dynamicMod.GetMethod(EntryPoint);
             // Invoke the static method and return whatever it returns
             object retval = mi.Invoke(null, parameterValues);
             // Filled verstr paramter.
             return retval;
         }
         * ���÷�ʽ
         * public void DrvOpen()
        {
            dllpath=this.GetRTDllPath();
            //dllpath =@"d:\helloworld\stock.dll";
            if (!Drvloaded && dllpath!=string.Empty )
            {
                
                string EntryPoint = "Stock_Init";
                object[] parameterValues = new  object [3];
                parameterValues[0] = this.Handle.ToInt32();
                parameterValues[1] = TSMSG ;
                parameterValues[2] = 4;
                

                object tempobj = Dynamicdll(dllpath, EntryPoint, parameterValues);


                Drvloaded = true;
            }
        }

        public void DrvClose()
        {
            if (Drvloaded)
            {
              
                string EntryPoint = "Stock_Quit";


                object[] parameterValues = new object[1];
                parameterValues[0] = this.Handle.ToInt32();

                object tempobj = Dynamicdll(dllpath, EntryPoint, parameterValues);

                Drvloaded = false;
            }
        }
        3.�����ַ�������2.0 net ��GetDelegateForFunctionPointer
         * internal delegate int LoadDll(int hWnd, uint Msg, int nWorkMode);
        internal delegate int UnLoadDll(int hWnd);
        [DllImport("kernel32.dll")]
        internal static extern IntPtr LoadLibrary(String dllname);
        [DllImport("kernel32.dll")]
        internal static extern IntPtr GetProcAddress(IntPtr hModule, String procname);
        IntPtr user32 = LoadLibrary("D:\\helloworld\\stock.dll");
       
         *  private void BtnLoadDll_Click(object sender, EventArgs e)
        {
            IntPtr procaddr1 = GetProcAddress(user32, "Stock_Init");
            LoadDll dyloaddll = (LoadDll)Marshal.GetDelegateForFunctionPointer(procaddr1, typeof(LoadDll));
            dyloaddll(this.Handle.ToInt32(), 55, 4);
            

        }

        private void BtnUnLoadDll_Click(object sender, EventArgs e)
        {
            IntPtr procaddr2 = GetProcAddress(user32, "Stock_Quit");
            UnLoadDll dyunloaddll = (UnLoadDll)Marshal.GetDelegateForFunctionPointer(procaddr2, typeof(UnLoadDll));
            dyunloaddll(this.Handle.ToInt32());
        }
         * 
          */

        public TongShiWindow()
        {
            InitializeComponent();
        }

       
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == TSMSG && Drvloaded)
            {
                try
                {
                    RCV_DATA d = (RCV_DATA)m.GetLParam(typeof(RCV_DATA));
                    switch (m.WParam.ToInt32())
                    {
                        
                        case RCV_REPORT:
                            
                            for (int i = 0; i < d.m_nPacketNum; i++)
                            {
                                RCV_REPORT_STRUCTExV3_HEAD report_head = (RCV_REPORT_STRUCTExV3_HEAD)Marshal.PtrToStructure
                                    (new IntPtr((int)d.ptr + 158 * i), typeof(RCV_REPORT_STRUCTExV3_HEAD));
                                RCV_REPORT_STRUCTExV3_DETAIL report_detail = (RCV_REPORT_STRUCTExV3_DETAIL)Marshal.PtrToStructure
                                    (new IntPtr((int)d.ptr + 158 * i + 50), typeof(RCV_REPORT_STRUCTExV3_DETAIL));
                                string stockcode = new string(report_head.m_szLabelName, 0, 6);
                                if(stockcode.IndexOf("\0")>0) stockcode = stockcode.Substring(0, stockcode.IndexOf("\0"));
                                string stockname = new string(report_head.m_szLabelName, 10, 32);
                                switch (report_head.m_wMarket)
                                {
                                    case SHMKT:
                                        stockcode = stockcode + ".SH";
                                        break;
                                    case SZMKT:
                                        stockcode = stockcode + ".SZ";
                                        break;
                                    case SHFMKT:
                                        stockcode = stockcode.Trim() + ".SHF";
                                        break;
                                    case DCEMKT:
                                        stockcode = stockcode + ".DCE";
                                        break;
                                    case CZCMKT:
                                        stockcode = stockcode + ".CZC";
                                        break;
                                    case CFFMKT:
                                        stockcode = stockcode + ".CFF";
                                        break;
                                    default:
                                        stockcode = stockcode + ".EX";
                                        break;
                                }
                                //Console.WriteLine("RCV_REPORT: {0} , {1}", stockcode.Trim(), stockname.Trim());//zzz
                                        
                                //Ҫ����tolocaltime,����ʱ��ֻ��uct time
                                DateTime temptime = new DateTime(1970, 1, 1).AddSeconds(report_head.m_time).ToLocalTime();
                                stockst.addData(stockcode, temptime, report_detail);
                                alertOnNewTick(stockcode);

                                //�����µĹ�Ʊ�����б�
                                lock (StockNameList)   //���� StockName.List
                                {
                                    if (StockNameList.Count == 0)
                                    {
                                        StockNameList.Add(stockcode, stockname);
                                    }
                                    else
                                    {
                                        if (!StockNameList.ContainsKey(stockcode))
                                        {
                                            StockNameList.Add(stockcode, stockname);
                                        }
                                    }
                                }
                            }

                            break;
                        case RCV_FILEDATA:
                            System.UInt32 EKE_HEAD_TAG = 0xffffffff;  //����ͷ m_dwHeadTag == EKE_HEAD_TAG

                            switch (d.m_wDataType)
                            {
                                case FILE_HISTORY_EX:             //����������
                                    // RCV_HISTORY_STRUCTEx history=(RCV_HISTORY_STRUCTEx)Marshal.PtrToStructure(data.ptr,typeof(RCV_HISTORY_STRUCTEx));
                                    // RCV_HISTORY_STRUCTEx_data hdata= (RCV_HISTORY_STRUCTEx_data)Marshal.PtrToStructure(new IntPtr((int)data.ptr+Marshal.SizeOf(typeof(RCV_HISTORY_STRUCTEx_data))),typeof(RCV_HISTORY_STRUCTEx_data));
                                    RCV_HISTORY_STRUCTEx_tag taginfo = (RCV_HISTORY_STRUCTEx_tag)Marshal.PtrToStructure(d.ptr, typeof(RCV_HISTORY_STRUCTEx_tag));
                                    if (taginfo.m_head.m_dwHeadTag == EKE_HEAD_TAG)
                                    {
                                        string mkt;
                                        for (int i = 1; i < d.m_nPacketNum; i++) // start from 1?
                                        {

                                            RCV_HISTORY_STRUCTEx_data hdata = (RCV_HISTORY_STRUCTEx_data)Marshal.PtrToStructure(new IntPtr((int)d.ptr + (i) * Marshal.SizeOf(typeof(RCV_HISTORY_STRUCTEx_data)) ), typeof(RCV_HISTORY_STRUCTEx_data));
                                            switch (taginfo.m_head.m_wMarket)
                                            {
                                                case SHMKT:
                                                    mkt = "SH";
                                                    break;
                                                case SZMKT:
                                                    mkt = "SZ";
                                                    break;
                                                case SHFMKT:
                                                    mkt = "SHF";
                                                    break;
                                                case DCEMKT:
                                                    mkt = "DCE";
                                                    break;
                                                case CZCMKT:
                                                    mkt = "CZC";
                                                    break;
                                                case CFFMKT:
                                                    mkt = "CFF";
                                                    break;
                                                default:
                                                    mkt = "EX";
                                                    break;
                                            }
                                            string dm = taginfo.m_head.m_szLabel;
                                            DateTime temptime = new DateTime(1970, 1, 1).AddSeconds(hdata.data.m_time).ToLocalTime();
                                            Console.WriteLine("FILE_HISTORY_EX: wMarket={0}, {1} {2} {3}",taginfo.m_head.m_wMarket, dm + "." + mkt, temptime, hdata.data.m_fClose);

                                        }
                                    }
                                        Console.WriteLine("����������");//zzz
                                    break;
                                case FILE_MINUTE_EX:            // ������������
                                    /*	tagRCV_EKE_HEADEx min_report_header=(tagRCV_EKE_HEADEx)Marshal.PtrToStructure(d.ptr,typeof(tagRCV_EKE_HEADEx));
							
							
                                        if (min_report_header.m_dwHeadTag==EKE_HEAD_TAG) 
                                        {
                                            float prevolume=0;
                                            for(int i=0;i<d.m_nPacketNum ;i++)
                                            {
                                                tagRCV_MINUTE_STRUCTEx min_report_detail=(tagRCV_MINUTE_STRUCTEx)Marshal.PtrToStructure(new IntPtr((int )d.ptr+16*i+16),typeof(tagRCV_MINUTE_STRUCTEx));
                                                WLDTBar_STRUCT temp_report_min_detail;
											
                                                temp_report_min_detail.fAsk=0;
                                                temp_report_min_detail.fBid=0;
                                                temp_report_min_detail.fHigh=min_report_detail.m_fPrice;
                                                temp_report_min_detail.fLow=min_report_detail.m_fPrice;
                                                temp_report_min_detail.fOpen=min_report_detail.m_fPrice;
										
                                                temp_report_min_detail.fClose=min_report_detail.m_fPrice;  
                                                temp_report_min_detail.fVolume=(int)(min_report_detail.m_fVolume-prevolume);  
                                                prevolume=min_report_detail.m_fVolume;
 
                                                stock_min.addData(min_report_header.m_szLabel,(int)min_report_detail.m_time,(object)temp_report_min_detail);
											
                                            }
                                        }
                                     */
                                    break;
                                case FILE_TICK_EX://����ֱ�����

                                    tagRCV_EKE_HEADEx tick_report_header = (tagRCV_EKE_HEADEx)Marshal.PtrToStructure(d.ptr, typeof(tagRCV_EKE_HEADEx));
                                    string stockcode = (tick_report_header.m_szLabel);
                                    if (stockcode.IndexOf("\0") > 0) stockcode = stockcode.Substring(0, stockcode.IndexOf("\0"));
                                    switch (tick_report_header.m_wMarket)
                                    {
                                        case SHMKT:

                                            stockcode = stockcode + ".SH";
                                            break;
                                        case SZMKT:
                                            stockcode = stockcode + ".SZ";
                                            break;
                                        case SHFMKT:
                                            stockcode = stockcode + ".SHF";
                                            break;
                                        case DCEMKT:
                                            stockcode = stockcode + ".DCE";
                                            break;
                                        case CZCMKT:
                                            stockcode = stockcode + ".CZC";
                                            break;
                                        case CFFMKT:
                                            stockcode = stockcode + ".CFF";
                                            break;
                                        default:
                                            stockcode = stockcode + ".EX";
                                            break;
                                    }

                                    if (tick_report_header.m_dwHeadTag == EKE_HEAD_TAG)
                                    {

                                        for (int i = 0; i < d.m_nPacketNum; i++)
                                        {
                                            tagRCV_HISTORY_STRUCTEx tick_report_detail = (tagRCV_HISTORY_STRUCTEx)Marshal.PtrToStructure(new IntPtr((int)d.ptr + 52 * i + 52), typeof(tagRCV_HISTORY_STRUCTEx));

                                            RCV_REPORT_STRUCTExV3_DETAIL report_detail = (RCV_REPORT_STRUCTExV3_DETAIL)Marshal.PtrToStructure
                                                (new IntPtr((int)d.ptr + 158 * i + 50), typeof(RCV_REPORT_STRUCTExV3_DETAIL));

                                            report_detail.m_fNewPrice = tick_report_detail.m_fnewprice;
                                            report_detail.m_fVolume = tick_report_detail.m_fVolume;
                                            report_detail.m_fAmount = tick_report_detail.m_fAmount;
                                            //Ҫ����tolocaltime,����ʱ��ֻ��uct time
                                            DateTime temptime = new DateTime(1970, 1, 1).AddSeconds(tick_report_detail.m_time).ToLocalTime();
                                            stockst.addData(stockcode, temptime, report_detail);

                                        }
                                    }

                                    break;
                                case FILE_POWER_EX: // �����Ȩ����
                                    break;
                                case FILE_BASE_EX:// Ǯ�����ݻ��������ļ�,m_szFileName�������ļ���
                                    break;
                                case FILE_NEWS_EX: // ������,��������m_szFileName����Ŀ¼������
                                    break;
                                case FILE_HTML_EX: // HTML�ļ�,m_szFileNameΪURL
                                    break;
                                default:
                                    //Console.WriteLine(d.m_wDataType);
                                    break;

                            }
                            break;

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("����{0}",ex.Message);
                }

            }
            base.WndProc(ref m);


        }

        private void alertOnNewTick(string Symbol)
        {
            if (watchlist.ContainsKey(Symbol))
            {
                SortedList<DateTime, RCV_REPORT_STRUCTExV3_DETAIL> testlist = stockst.GetRtTick(Symbol.TrimEnd());
               
               
                    int prevolume = 0;//����ǰһ���ۼƳɽ���

                    if (testlist.Count > 1) //
                    {
                        RCV_REPORT_STRUCTExV3_DETAIL pretempdata = testlist.Values[testlist.Count - 2];
                        prevolume = (int)pretempdata.m_fVolume;  //ǰһ���ۼƳɽ���
                    }


                    RCV_REPORT_STRUCTExV3_DETAIL tempdata = testlist.Values[testlist.Count - 1];


                    DateTime dt = testlist.Keys[testlist.Count - 1];

                    WLDTBar_STRUCT tempbars = new WLDTBar_STRUCT();
                    tempbars.fOpen = tempdata.m_fOpen; ;
                    tempbars.fHigh = tempdata.m_fHigh;
                    tempbars.fLow = tempdata.m_fLow;
                    tempbars.fClose = tempdata.m_fNewPrice;
                    tempbars.fBid = tempdata.m_fBuyPrice1;
                    tempbars.fAsk = tempdata.m_fSellPrice1;
                    tempbars.fVolume = (int)tempdata.m_fVolume - prevolume;
                    if (OnNewBar != null && tempbars.fVolume > 0)
                    {
                        NewBarEventArgs tickalert = new NewBarEventArgs(Symbol, tempbars,(int)tempdata.m_fVolume , dt, TSCommon.BarIntervalEnum.biTicks, 1, true);
                        OnNewBar(this, tickalert);
                    }
                
            }
        }
       

        private string  GetRTDllPath() 
        {
            string DLLPATH=string.Empty ;
            RegistryKey rk = Registry.LocalMachine.OpenSubKey("SOFTWARE\\stockdrv", true);
            if (rk != null)
            {
                DLLPATH = (String)rk.GetValue("Driver");
            }
            return DLLPATH;
        }
       
         #region ��������

        public SortedList<DateTime, RCV_REPORT_STRUCTExV3_DETAIL> GetRTData(string Symbol)
        {
            lock (watchlist)
            {
                if (!watchlist.ContainsKey(Symbol))
                {
                    watchlist.Add(Symbol, 1);
                }
                else
                {
                    watchlist[Symbol] = watchlist[Symbol] + 1;
                }
            }
            return stockst.GetRtTick(Symbol.Trim());

        }

        public void RemoveSymbol(string Symbol) 
        {
            lock (watchlist)
            {
                if (watchlist.ContainsKey(Symbol))
                {
                    if (watchlist[Symbol] > 1)
                    {
                        watchlist[Symbol] = watchlist[Symbol] - 1;
                    }
                    else
                    {
                        watchlist.Remove(Symbol);
                    }
                }
            }
        }
        //��ȡ֤ȯ���� 
        public string get_symbolname(string securitycode)
        {
            string symbolname = "";

            if (StockNameList.ContainsKey(securitycode))
            {
                symbolname = (string)StockNameList[securitycode];
            }

            return symbolname;

        }



        public void DrvOpen()
        {
            //dllpath=this.GetRTDllPath();
            dllpath = TSCommon.StMyFunction.GetStockFileName();
            if (!File.Exists (@dllpath))
            {
                dllpath = this.GetRTDllPath();
            }
            if (!Drvloaded &&  File.Exists(@dllpath)  )
            {
                libraryHandle = LoadLibrary(@dllpath);
                IntPtr procaddr1 = GetProcAddress(libraryHandle, "Stock_Init");
                LoadDll dyloaddll = (LoadDll)Marshal.GetDelegateForFunctionPointer(procaddr1, typeof(LoadDll));
                if (dyloaddll(this.Handle.ToInt32(), TSMSG, 4) == 1)
                {

                    Drvloaded = true;
                }
                else 
                { 
                    Drvloaded = false; 
                }
            }
        }

        public void DrvClose()
        {
            if (Drvloaded)
            {

                IntPtr procaddr2 = GetProcAddress(libraryHandle, "Stock_Quit");
                UnLoadDll dyunloaddll = (UnLoadDll)Marshal.GetDelegateForFunctionPointer(procaddr2, typeof(UnLoadDll));
                dyunloaddll(this.Handle.ToInt32());

                Drvloaded = false;
            }
        }



        public void registerBarHandler(NewBarEventHandler handler)
        {
            OnNewBar += handler;
        }

        public void unregisterBarHandler(NewBarEventHandler handler)
        {
            OnNewBar -= handler;
            
        }



        /// <summary>
        /// ���¼� ֻ��quote ������������
        /// </summary>
        /// <param name="Symbol"></param>
        /// <returns>����ָ�������ʵʱ�������¼�λ</returns>
        public float symbo_lastclose(string Symbol)
        {

            SortedList<DateTime, RCV_REPORT_STRUCTExV3_DETAIL> testlist = stockst.GetRtTick(Symbol.TrimEnd());

            if (testlist.Count > 0)
            {
                RCV_REPORT_STRUCTExV3_DETAIL tempdata = testlist.Values[(testlist.Count - 1)];
                return tempdata.m_fLastClose;
            }
            return 0;
        }

        public double GetMarketSingelPrice( TSCommon.AlertTypeEnum OrderType,string Symbol) 
        {
            double MarketSingelPrice = 0;
            SortedList<DateTime, RCV_REPORT_STRUCTExV3_DETAIL> testlist = stockst.GetRtTick(Symbol.TrimEnd());

            if (testlist.Count > 0)
            {
                RCV_REPORT_STRUCTExV3_DETAIL tempdata = testlist.Values[(testlist.Count - 1)];
                switch (OrderType)
                {
                    case TSCommon.AlertTypeEnum.alertBuy:
                        MarketSingelPrice = (double)tempdata.m_fSellPrice2;
                        //MessageBox.Show(string.Format("�������Ϊ:{0}", MarketSingelPrice));
                        break;
                    case TSCommon.AlertTypeEnum.alertSell:

                        MarketSingelPrice = (double)tempdata.m_fBuyPrice2;                        

                        break;
                    default:
                        break;
                }
            }
            return MarketSingelPrice;
        }
        #endregion





    }
}
