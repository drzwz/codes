﻿using System;
using System.Collections.Generic;
using System.Text;

namespace testTS
{
    [StructLayout(LayoutKind.Sequential)]
    public struct RCV_DATA
    {
        //[FieldOffset(0)]
        public int m_wDataType; // 文件类型
        //[FieldOffset(4)]
        public int m_nPacketNum; // 记录数,参见注一
        //[FieldOffset(8)]
        public RCV_FILE_HEADEx m_File; // 文件接口
        //[FieldOffset(8)]
        //[MarshalAs(UnmanagedType.I4)]
        public int m_bDISK; // 文件是否已存盘的文件

        public IntPtr ptr;

        //[FieldOffset(292)]
        //[MarshalAs(UnmanagedType.ByValArray)]
        //public RCV_REPORT_STRUCTEx[] m_pReport;
        //[FieldOffset(292)]
        //[MarshalAs(UnmanagedType.ByValArray)]
        //public RCV_REPORT_STRUCTEx1[] m_pReport1;
        //[FieldOffset(292)]
        //[MarshalAs(UnmanagedType.ByValArray)]
        //public RCV_REPORT_STRUCTEx2[] m_pReport2;
        //[FieldOffset(292)]
        //[MarshalAs(UnmanagedType.ByValArray)]
        //public RCV_HISTORY_STRUCTEx[] m_pDay;
        //[FieldOffset(292)]
        //[MarshalAs(UnmanagedType.ByValArray)]
        //public RCV_MINUTE_STRUCTEx[] m_pMinute;
        //[FieldOffset(292)]
        //[MarshalAs(UnmanagedType.ByValArray)]
        //public RCV_POWER_STRUCTEx[] m_pPower;
        //[FieldOffset(292)]
        //[MarshalAs(UnmanagedType.AsAny)]
        //public object m_pData; // 参见注二
    }

    enum BYTE : byte
    {
        m_Dec = 4,
        m_Enabled = 1,
        m_VolFlag = 1,
        m_Other = 2
    }


    [StructLayout(LayoutKind.Explicit, CharSet = CharSet.Auto)]
    public struct RCV_REPORT_STRUCTEx
    {
        public ushort m_cbSize; // 结构大小
        public uint m_time; // 交易时间
        public ushort m_wMarket; // 股票市场类型

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STKLABEL_LEN)]
        public string m_szLabel; // 股票代码,以'\0'结尾
        [FieldOffset(18)]
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STKNAME_LEN - 15)]
        public string m_szName; // 股票名称,以'\0'结尾

        BYTE BYTE;

        //BYTE m_Dec:4;
        //BYTE m_Enabled:1;
        //BYTE m_VolFlag:1;
        //BYTE m_Other:2;

        public ushort m_ID;
        public Single m_fOpenInterest;
        public Single m_fLastOpenInterest;
        public Single m_fLastSettle;

        public Single m_fLastClose; // 昨收
        public Single m_fOpen; // 今开
        public Single m_fHigh; // 最高
        public Single m_fLow; // 最低
        public Single m_fNewPrice; // 最新
        public Single m_fVolume; // 成交量
        public Single m_fAmount; // 成交额

        public Single m_fBuyPrice1; // 申买价1
        public Single m_fBuyPrice2; // 申买价2
        public Single m_fBuyPrice3; // 申买价3

        public Single m_fBuyVolume1; // 申买量1
        public Single m_fBuyVolume2; // 申买量2
        public Single m_fBuyVolume3; // 申买量3

        public Single m_fSellPrice1; // 申卖价1
        public Single m_fSellPrice2; // 申卖价2
        public Single m_fSellPrice3; // 申卖价3

        public Single m_fSellVolume1; // 申卖量1
        public Single m_fSellVolume2; // 申卖量2
        public Single m_fSellVolume3; // 申卖量3

        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        //public Single[] m_fBuyPrice; // 申买价1,2,3
        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        //public Single[] m_fBuyVolume; // 申买量1,2,3
        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        //public Single[] m_fSellPrice; // 申卖价1,2,3
        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        //public Single[] m_fSellVolume; // 申卖量1,2,3

        public Single m_fBuyPrice4; // 申买价4
        public Single m_fBuyVolume4; // 申买量4
        public Single m_fSellPrice4; // 申卖价4
        public Single m_fSellVolume4; // 申卖量4

        public Single m_fBuyPrice5; // 申买价5
        public Single m_fBuyVolume5; // 申买量5
        public Single m_fSellPrice5; // 申卖价5
        public Single m_fSellVolume5; // 申卖量5
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 48)]
        public string m_szName2;
        public long m_IName;
    }


    public class StockDataDriver : System.Windows.Forms.Form
    {
        private const int RCV_WORK_SENDMSG = 4; // 版本 2 建议使用的方式 
        // 其他工作方式保留

        // 消息类型
        private const int RCV_REPORT = 0x3f001234;
        private const int RCV_FILEDATA = 0x3f001235;


        //==================================== 数据结构 =================================================
        // 证券市场
        private const ushort SH_MARKET_EX = 18515; //"HS"; // 上海
        private const string SZ_MARKET_EX = "ZS"; // 深圳
        private const string HK_MARKET_EX = "KH"; // 香港

        // 文件数据类型
        // 结构数组形式的文件数据
        private const int FILE_HISTORY_EX = 2; // 补日线数据
        private const int FILE_MINUTE_EX = 4; // 补分钟线数据
        private const int FILE_POWER_EX = 6; // 补充除权数据
        private const int FILE_MIN5_EX = 81; // 补5分钟数据
        private const int FILE_MIN1_EX = 82; // 补1分钟数据

        private const int FILE_BASE_EX = 0x1000; // 钱龙兼容基本资料文件,m_szFileName仅包含文件名
        private const int FILE_NEWS_EX = 0x1002; // 新闻类,其类型由m_szFileName中子目录名来定
        private const int FILE_HTML_EX = 0x1004; // HTML文件,m_szFileName为URL

        private const int FILE_SOFTWARE_EX = 0x2000; // 升级软件

        private const int FILE_SHAZQDATA_EX = 0x3000; // 上海债券净价交易

        private const int FILE_TYPE_RES = -1; // 保留

        // 消息子类型
        private const int News_Sha_Ex = 2; // 上证消息
        private const int News_Szn_Ex = 4; // 深证消息
        private const int News_Fin_Ex = 6; // 财经报道
        private const int News_TVSta_Ex = 8; // 电视台通知
        private const int News_Unknown_Ex = -1; // 未知提供者

        //Definition For nInfo of Function GetStockDrvInfo(int nInfo,void * pBuf);
        private const int RI_IDSTRING = 1; // 厂商名称,返回(LPCSTR)厂商名
        private const int RI_IDCODE = 2; // 卡号
        private const int RI_VERSION = 3; // 驱动程序版本
        private const int RI_ERRRATE = 4; // 取信道误码
        private const int RI_STKNUM = 5; // 取上市股票总家数
        private const int RI_SUPPORTEXTHQ = 6; // 是否支持JSJ格式
        private const int RI_ENABLEDZHTRANS = 7; // 支持传输大智慧文件系统
        private const int RI_ENABLETS3FILE = 8; // 支持文件传输

        private const int RI_HASASKDATA = 0x1000; //双向支持，待定
        private const int RI_HIGHSPEED = 0x1002; //如果分析软件处理数据足够快，可以要求系统高速初始化代码
        //一般不能调用。目前只有倚天2000服务器和网络版使用
        private const int RI_SUPPORT_FUTURES = 0x1003;
        private const int RI_USERNAME = 0x1004; // 登陆用户
        private const int RI_PASSWORD = 0x1005; // 登密码
        private const int RI_IP = 0x1006; // 登陆用户
        private const int RI_SUPPORT_ID = 0x1007;
        private const int RI_HIDE = 0x1008; // 登陆时候隐藏界面
        private const int RI_SLEEP = 0x1009; // 登密码
        private const int RI_ASKDATA = 0x1010; // 登密码

        //软件完全按照倚天规范开发，调用本函数后，如果产品是期货
        //tagRCV_REPORT_STRUCTEx结构中
        //m_fAmount为成交金额，
        //m_fOpenInterest为持仓量
        //m_fLastOpenInterest为昨日持仓量
        //m_fLastSettle为昨结算，请不要使用这个变量，可能发生改变
        //m_fLastSettle为当日结算（如果有）请不要使用这个变量，可能发生改变
        //否则为持仓量
        //不调用则m_fAmount为持仓量，上述几个字段为无效
        private const int STKLABEL_LEN = 10; // 股号数据长度,国内市场股号编码兼容钱龙
        private const int STKNAME_LEN = 32; // 股名长度
        private const int STKLABEL_LEN_SKY = 48;

        //消息
        private const int My_Msg_StkData = 0x8000 + 1;


        //软件完全按照倚天规范开发，调用本函数后，如果产品是期货
        //tagRCV_REPORT_STRUCTEx结构中
        //m_fAmount为成交金额，
        //m_fOpenInterest为持仓量
        //m_fLastOpenInterest为昨日持仓量
        //m_fLastSettle为昨结算，请不要使用这个变量，可能发生改变
        //m_fLastSettle为当日结算（如果有）请不要使用这个变量，可能发生改变
        //否则为持仓量
        //不调用则m_fAmount为持仓量，上述几个字段为无效


        //国债净价交易数据
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public struct GzLxBINData
        {
            public ushort m_wMarket; // 股票市场类型
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STKLABEL_LEN)]
            public string m_szLabel; // 股票代码,以'\0'结尾
            public ushort m_LiXiDate; //开始计算利息的日期
            public double m_fMoney100; //每100元的利息
            public ushort m_DayNum; //利息计算天数
            public Single m_fShowPrice; //票面价格
        }

        [Flags]
        enum BYTE : byte
        {
            m_Dec = 4,
            m_Enabled = 1,
            m_VolFlag = 1,
            m_Other = 2
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public struct RCV_REPORT_STRUCTEx1
        {
            public ushort m_wMarket; // 股票市场类型
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STKLABEL_LEN)]
            public string m_szLabel; // 股票代码,以'\0'结尾
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STKNAME_LEN - 15)]
            public string m_szName; // 股票名称,以'\0'结尾
            BYTE BYTE;
            //BYTE m_Dec:4;
            //BYTE m_Enabled:1;
            //BYTE m_VolFlag:1;
            //BYTE m_Other:2;
            public ushort m_ID;
            public Single m_fOpenInterest;
            public Single m_fLastOpenInterest;
            public Single m_fLastSettle;

            public Single m_fLastClose; // 昨收
            public Single m_fOpen; // 今开
            public Single m_fHigh; // 最高
            public Single m_fLow; // 最低
            public Single m_fNewPrice; // 最新
            public Single m_fVolume; // 成交量
            public Single m_fAmount; // 成交额

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            public Single[] m_fBuyPrice; // 申买价1,2,3
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            public Single[] m_fBuyVolume; // 申买量1,2,3
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            public Single[] m_fSellPrice; // 申卖价1,2,3
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            public Single[] m_fSellVolume; // 申卖量1,2,3
        }

        [StructLayout(LayoutKind.Explicit, CharSet = CharSet.Auto)]
        public struct RCV_REPORT_STRUCTEx
        {
            public ushort m_cbSize; // 结构大小
            public uint m_time; // 交易时间
            public ushort m_wMarket; // 股票市场类型

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STKLABEL_LEN)]
            public string m_szLabel; // 股票代码,以'\0'结尾
            [FieldOffset(18)]
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STKNAME_LEN - 15)]
            public string m_szName; // 股票名称,以'\0'结尾

            BYTE BYTE;

            //BYTE m_Dec:4;
            //BYTE m_Enabled:1;
            //BYTE m_VolFlag:1;
            //BYTE m_Other:2;

            public ushort m_ID;
            public Single m_fOpenInterest;
            public Single m_fLastOpenInterest;
            public Single m_fLastSettle;

            public Single m_fLastClose; // 昨收
            public Single m_fOpen; // 今开
            public Single m_fHigh; // 最高
            public Single m_fLow; // 最低
            public Single m_fNewPrice; // 最新
            public Single m_fVolume; // 成交量
            public Single m_fAmount; // 成交额

            public Single m_fBuyPrice1; // 申买价1
            public Single m_fBuyPrice2; // 申买价2
            public Single m_fBuyPrice3; // 申买价3

            public Single m_fBuyVolume1; // 申买量1
            public Single m_fBuyVolume2; // 申买量2
            public Single m_fBuyVolume3; // 申买量3

            public Single m_fSellPrice1; // 申卖价1
            public Single m_fSellPrice2; // 申卖价2
            public Single m_fSellPrice3; // 申卖价3

            public Single m_fSellVolume1; // 申卖量1
            public Single m_fSellVolume2; // 申卖量2
            public Single m_fSellVolume3; // 申卖量3

            //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            //public Single[] m_fBuyPrice; // 申买价1,2,3
            //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            //public Single[] m_fBuyVolume; // 申买量1,2,3
            //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            //public Single[] m_fSellPrice; // 申卖价1,2,3
            //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            //public Single[] m_fSellVolume; // 申卖量1,2,3

            public Single m_fBuyPrice4; // 申买价4
            public Single m_fBuyVolume4; // 申买量4
            public Single m_fSellPrice4; // 申卖价4
            public Single m_fSellVolume4; // 申卖量4

            public Single m_fBuyPrice5; // 申买价5
            public Single m_fBuyVolume5; // 申买量5
            public Single m_fSellPrice5; // 申卖价5
            public Single m_fSellVolume5; // 申卖量5
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 48)]
            public string m_szName2;
            public long m_IName;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public struct RCV_REPORT_STRUCTEx2
        {
            public ushort m_cbSize; // 结构大小
            public ulong m_time; // 交易时间
            public ushort m_wMarket; // 股票市场类型
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STKLABEL_LEN)]
            public string m_szLabel; // 股票代码,以'\0'结尾
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STKNAME_LEN - 15)]
            public string m_szName; // 股票名称,以'\0'结尾
            BYTE BYTE;

            //BYTE m_Dec:4;
            //BYTE m_Enabled:1;
            //BYTE m_VolFlag:1;
            //BYTE m_Other:2;
            public ushort m_ID;
            public Single m_fOpenInterest;
            public Single m_fLastOpenInterest;
            public Single m_fLastSettle;

            public Single m_fLastClose; // 昨收
            public Single m_fOpen; // 今开
            public Single m_fHigh; // 最高
            public Single m_fLow; // 最低
            public Single m_fNewPrice; // 最新
            public Single m_fVolume; // 成交量
            public Single m_fAmount; // 成交额

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            public Single[] m_fBuyPrice; // 申买价1,2,3
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            public Single[] m_fBuyVolume; // 申买量1,2,3
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            public Single[] m_fSellPrice; // 申卖价1,2,3
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            public Single[] m_fSellVolume; // 申卖量1,2,3

            public Single m_fBuyPrice4; // 申买价4
            public Single m_fBuyVolume4; // 申买量4
            public Single m_fSellPrice4; // 申卖价4
            public Single m_fSellVolume4; // 申卖量4

            public Single m_fBuyPrice5; // 申买价5
            public Single m_fBuyVolume5; // 申买量5
            public Single m_fSellPrice5; // 申卖价5
            public Single m_fSellVolume5; // 申卖量5
        }

        //补充数据头
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public struct RCV_EKE_HEADEx
        {
            public uint m_dwHeadTag; // = EKE_HEAD_TAG
            public ushort m_wMarket; // 市场类型
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STKLABEL_LEN)]
            public string m_szLabel; // 股票代码
        }


        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public class AskDataStructHead
        {
            public ushort m_PacketType;
            public ushort m_wPacketNum;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public struct HisInfo
        {
            public ushort m_ID;
            public ushort m_HisType;
        }

        /// <summary>
        /// 需要重新定义
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public class AskDataStruct : AskDataStructHead
        {
            [MarshalAs(UnmanagedType.LPArray, SizeConst = 3)]
            IntPtr[] m_His;
        }


        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public class AskHisInfo
        {
            public byte m_DataType;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 3)]
            public string m_Extend;
            public long m_Start;
            public long m_End;
        }


        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public class ASK_HISTORY_STRUCTBase : AskDataStructHead
        {
            public ushort m_cbSize; // 结构大小
            public ushort m_wMarket; // 市场类型
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STKLABEL_LEN)]
            public string m_szLabel; // 股票代码
        }

        /// <summary>
        /// 需要重新定义
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public class ASK_HISTORY_STRUCT : ASK_HISTORY_STRUCTBase
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
            public AskHisInfo[] m_Info;//最多支持同时申请八种类型
        }


        //补充日线数据
        [StructLayout(LayoutKind.Explicit, CharSet = CharSet.Auto)]
        public struct RCV_HISTORY_STRUCTEx
        {
            [FieldOffset(0)]
            public long m_time;
            [FieldOffset(8)]
            public Single m_fOpen; //开盘
            [FieldOffset(12)]
            public Single m_fHigh; //最高
            [FieldOffset(16)]
            public Single m_fLow; //最低
            [FieldOffset(20)]
            public Single m_fClose; //收盘
            [FieldOffset(24)]
            public Single m_fVolume; //量
            [FieldOffset(28)]
            public Single m_fAmount; //额
            [FieldOffset(32)]
            public ushort m_wAdvance; //涨数,仅大盘有效
            [FieldOffset(34)]
            public ushort m_wDecline; //跌数,仅大盘有效
            [FieldOffset(32)]
            public Single m_fOI;

            [FieldOffset(0)]
            public IntPtr m_head;
        }

        //补充分时线数据
        [StructLayout(LayoutKind.Explicit, CharSet = CharSet.Auto)]
        public struct RCV_MINUTE_STRUCTEx
        {
            [FieldOffset(0)]
            public long m_time; // UCT
            [FieldOffset(16)]
            public Single m_fPrice;
            [FieldOffset(20)]
            public Single m_fVolume;
            [FieldOffset(24)]
            public Single m_fAmount;
            [FieldOffset(0)]
            public IntPtr m_head;
        }

        //补充除权数据
        [StructLayout(LayoutKind.Explicit, CharSet = CharSet.Auto)]
        public struct RCV_POWER_STRUCTEx
        {
            [FieldOffset(0)]
            public long m_time; // UCT
            [FieldOffset(16)]
            public Single m_fGive; // 每股送
            [FieldOffset(20)]
            public Single m_fPei; // 每股配
            [FieldOffset(24)]
            public Single m_fPeiPrice; // 配股价,仅当 m_fPei!=0.0f 时有效
            [FieldOffset(28)]
            public Single m_fProfit; // 每股红利
            [FieldOffset(0)]
            public IntPtr m_head;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public struct RCV_SHAGZ_STRUCTEx
        {
            public ushort m_wMarket; // 市场类型
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = STKLABEL_LEN)]
            public string m_szLabel; // 股票代码
            public ushort m_StartDate; //开始计算利息的日期 YYMMDD format
            public double m_fLiXi100RMB; //票面100员的
            public ushort m_DayNum;
            public Single m_fPrice;
        }

        //////////////////////////////////////////////////////////////////////////////////
        // 文件类型数据包头
        // 注一:
        // m_wDataType == FILE_BASE_EX
        // m_dwAttrib = 股票证券市场,m_szFileName仅包含文件名
        // m_FileTime = 基本面资料文件创建日期
        // m_wDataType == FILE_NEWS_EX
        // m_dwAttrib = 消息来源,m_szFileName 包含目录的文件名,目录名为消息来源
        // m_dwSerialNo = 序列号
        // 如: "上交所消息\\0501Z012.TXT","新兰德\\XLD0001.TXT"
        // m_wDataType == FILE_HTML_EX
        // m_dwAttrib 保留, m_szFileName为URL
        // m_wDataType == FILE_SOFTWARE_EX
        // m_dwAttrib 分析软件类型, 用于初步判断
        // m_szFileName 分析软件 ID 特征字符串 + '\\' + 文件名
        // 如 "TongShi\\TS\\RECEIVE\\RECEIVE.EXE",
        // ID 特征字符串为 "TongShi", "TS\\RECEIVE\\RECEIVE.EXE" 为文件名
        // 特征字符串 和 文件名及其含义由分析软件商定义
        // 注二:
        // 数据文件循环播出,每个文件有唯一的序列号,以避免重复接收
        [StructLayout(LayoutKind.Explicit, CharSet = CharSet.Auto)]
        public struct RCV_FILE_HEADEx
        {
            [FieldOffset(0)]
            public uint m_dwAttrib; // 文件子类型
            [FieldOffset(4)]
            public uint m_dwLen; // 文件长度
            [FieldOffset(8)]
            public uint m_dwSerialNo; // 序列号,对股评
            [FieldOffset(8)]
            public long m_FileTime; // 文件创建时间
            [FieldOffset(20)]
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
            public string m_szFileName; // 文件名 or URL
        }


        //////////////////////////////////////////////////////////////////////////////////
        // 数据通知消息
        //查询方式通知消息
        // wParam = MsgPara_StkData 有股票数据
        // wParam = MsgPara_File 有文件数据文件
        //直接数据引用通知消息
        // wParam = RCV_WPARAM;
        // lParam 指向 RCV_DATA结构;
        // 返回 1 已经处理, 0 未处理或不能处理,目前该返回值被忽略

        // 注一:
        // 记录数表示行情数据和补充数据(包括 Header)的数据包数,对文件类型数据, = 1
        // 注二:
        // 若 m_bDISK = FALSE, m_pData 为数据缓冲区指针
        // ******** 数据共享,不能修改数据 **********
        // m_bDISK = TRUE, m_pData 为该文件的存盘文件名,一般情况只有
        // 升级软件等大文件用存盘方式
        //[StructLayout(LayoutKind.Explicit, CharSet = CharSet.Auto)]
        [StructLayout(LayoutKind.Sequential)]
        public struct RCV_DATA
        {
            //[FieldOffset(0)]
            public int m_wDataType; // 文件类型
            //[FieldOffset(4)]
            public int m_nPacketNum; // 记录数,参见注一
            //[FieldOffset(8)]
            public RCV_FILE_HEADEx m_File; // 文件接口
            //[FieldOffset(8)]
            //[MarshalAs(UnmanagedType.I4)]
            public int m_bDISK; // 文件是否已存盘的文件

            public IntPtr ptr;

            //[FieldOffset(292)]
            //[MarshalAs(UnmanagedType.ByValArray)]
            //public RCV_REPORT_STRUCTEx[] m_pReport;
            //[FieldOffset(292)]
            //[MarshalAs(UnmanagedType.ByValArray)]
            //public RCV_REPORT_STRUCTEx1[] m_pReport1;
            //[FieldOffset(292)]
            //[MarshalAs(UnmanagedType.ByValArray)]
            //public RCV_REPORT_STRUCTEx2[] m_pReport2;
            //[FieldOffset(292)]
            //[MarshalAs(UnmanagedType.ByValArray)]
            //public RCV_HISTORY_STRUCTEx[] m_pDay;
            //[FieldOffset(292)]
            //[MarshalAs(UnmanagedType.ByValArray)]
            //public RCV_MINUTE_STRUCTEx[] m_pMinute;
            //[FieldOffset(292)]
            //[MarshalAs(UnmanagedType.ByValArray)]
            //public RCV_POWER_STRUCTEx[] m_pPower;
            //[FieldOffset(292)]
            //[MarshalAs(UnmanagedType.AsAny)]
            //public object m_pData; // 参见注二
        }



        private RichTextBox richTextBox1;
        private Button button2;
        private Button button1;

        // 注册函数

        // 股票初始化
        // 入口参数:
        // hWnd 处理消息的窗口句柄
        // Msg 用户自定义消息
        // nWorkMode 接口工作方式, 应等于 RCV_WORK_SENDMSG
        // 返回参数:
        // 1 成功 
        // -1 失败
        [DllImport("jet158.dll")]
        private static extern int Stock_Init(IntPtr hWnd, uint Msg, int nWorkMode);

        // 退出,停止发送消息
        // 入口参数:
        // hWnd 处理消息的窗口句柄,同 Stock_Init 的调用入口参数
        // 返回参数:
        // 1 成功 
        // -1 失败
        [DllImport("jet158.dll")]
        private static extern int Stock_Quit(IntPtr hWnd);
        //////////////////////////////////////////////////////////////////////////////////
        // 行情接口 

        // 取已接收到的股票总数
        [DllImport("jet158.dll")]
        private static extern int GetTotalNumber();

        // 由序号取股票数据(扩展)
        // 入口参数: 
        // nNo 序号
        // pBuf 存放股票数据的缓冲区
        // 返回参数:
        // NoStockData 无股票数据 
        // 注:
        // 该函数提供股票数据的主要数据;分析软件刚运行时,可以快速建立数据框架
        [DllImport("jet158.dll")]
        private static extern int GetStockByNoEx(int nNo, [MarshalAs(UnmanagedType.LPStruct)]RCV_REPORT_STRUCTEx pBuf);

        // 由股号取股票数据(扩展)
        // 入口参数: 
        // pszStockCode股票代号 
        // nMarket 证券市场
        // pBuf 存放股票数据的缓冲区
        // 返回参数:
        // NoStockData 无股票数据 
        // 注:
        // 该函数提供股票数据的主要数据;分析软件刚运行时,可以快速建立数据框架
        //[DllImport("jet158.dll")]
        //private static extern int GetStockByCodeEx(char* pszStockCode, int nMarket, RCV_REPORT_STRUCTEx* pBuf);

        // 激活接收程序,进行设置
        // 入口参数:
        // bShowWindow TRUE 显示窗口,进行设置
        // FALSE 隐含窗口
        // 返回参数:
        // 1 成功
        // -1 失败
        //[DllImport("jet158.dll")] //private static extern int SetupReceiver(BOOL bShowWindow);

        // 取得股票驱动信息
        // 入口参数:
        // nInfo 索引
        // pBuf 缓冲区
        // 出口参数:
        // nInfo == RI_IDSTRING, 返回特征字符串长度, pBuf 为特征字符串
        // 如: "TongShi_StockDrv_1.00"
        // nInfo == RI_IDCODE, 返回信息卡 ID 号, pBuf 为字符串形式的 ID 号
        // 如: 0x78001234 "78001234"
        // nInfo == RI_VERSION, 返回信息卡版本号, pBuf 为字符串版本
        // 如: 1.00 "1.00" 
        // nInfo == RI_ERRRATE, 取信道误码,
        // nInfo == RI_STKNUM, 取上市股票总家数
        [DllImport("jet158.dll")]
        private static extern int GetStockDrvInfo(int nInfo, [MarshalAs(UnmanagedType.AsAny)] object pBuf);

        public StockDataDriver()
        {
            InitializeComponent();
        }

        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case My_Msg_StkData:
                    RCV_DATA pHeader = (RCV_DATA)m.GetLParam(typeof(RCV_DATA));
                    if (pHeader.ptr != IntPtr.Zero)
                    {
                        RCV_REPORT_STRUCTEx pRCV_REPORT_STRUCTEx = (RCV_REPORT_STRUCTEx)Marshal.PtrToStructure(pHeader.ptr, typeof(RCV_REPORT_STRUCTEx));
                        ushort nBufSize = pRCV_REPORT_STRUCTEx.m_cbSize;
                        this.richTextBox1.Text = "";

                        switch (m.WParam.ToInt32())
                        {
                            case RCV_REPORT:
                                {
                                    for (int i = 0; i < pHeader.m_nPacketNum; i++)
                                    {
                                        RCV_REPORT_STRUCTEx report = (RCV_REPORT_STRUCTEx)Marshal.PtrToStructure(new IntPtr(pHeader.ptr.ToInt32() + nBufSize * i), typeof(RCV_REPORT_STRUCTEx));
                                        this.richTextBox1.Text += String.Format("%6s %8s %8.3f %8.3f %8.3f %8.3f %8.3f %10.0f %10.f\n", new string(report.m_szLabelName, 0, 6), new string(report.m_szLabelName, 10, 16), report.m_fNewPrice, report.m_fOpen, report.m_fLastClose, report.m_fHigh, report.m_fLow, report.m_fVolume, report.m_fAmount);
                                    }
                                    break;


                                }
                        }
                    }
                    break;
                default:
                    base.WndProc(ref m);
                    break;
            }
        }


        public void GetKMIN5()
        {
            //IntPtr ptrs = Marshal.AllocHGlobal(128);
            //char[] SupportExtHQ = new char[128];
            //int i = GetStockDrvInfo(RI_SUPPORTEXTHQ, SupportExtHQ);

            //string SupportExtHQ = Marshal.PtrToStringAnsi(ptrs);

            //MessageBox.Show(SupportExtHQ.to);
            int ok = Stock_Init(this.Handle, My_Msg_StkData, RCV_WORK_SENDMSG);

            //ASK_HISTORY_STRUCT ask = new ASK_HISTORY_STRUCT();

            //ask.m_wPacketNum = 1;
            //ask.m_wMarket = SH_MARKET_EX;
            //ask.m_szLabel = "600000"; ;
            //ask.m_PacketType = 23;
            //ask.m_wPacketNum = 1;
            //ask.m_Info = new AskHisInfo[8];


            //AskHisInfo ahi = new AskHisInfo();
            //ahi.m_Extend = "";
            ////ahi.m_Extend[0] = (char)0;
            ////ahi.m_Extend[1] = (char)0;
            ////ahi.m_Extend[2] = (char)0;
            //ask.m_Info[0] = ahi;
            //ahi = new AskHisInfo();
            //ahi.m_Extend = "";
            //ask.m_Info[1] = ahi;
            //ahi = new AskHisInfo();
            //ahi.m_Extend = "";
            //ask.m_Info[2] = ahi;
            //ahi = new AskHisInfo();
            //ahi.m_Extend = "";
            //ask.m_Info[3] = ahi;
            //ahi = new AskHisInfo();
            //ahi.m_Extend = "";
            //ask.m_Info[4] = ahi;
            //ahi = new AskHisInfo();
            //ahi.m_Extend = "";
            //ask.m_Info[5] = ahi;
            //ahi = new AskHisInfo();
            //ahi.m_Extend = "";
            //ask.m_Info[6] = ahi;
            //ahi = new AskHisInfo();
            //ahi.m_Extend = "";
            //ask.m_Info[7] = ahi;
            //ask.m_Info[0].m_DataType = (byte)2;

            //ushort len = (ushort)(Marshal.SizeOf(typeof(ASK_HISTORY_STRUCTBase)) + ask.m_wPacketNum * Marshal.SizeOf(typeof(AskHisInfo)));
            //ask.m_cbSize = len;

            //IntPtr ptrs = Marshal.AllocHGlobal(len);
            //Marshal.StructureToPtr(ask, ptrs, true);


            //ok = GetStockDrvInfo(RI_ASKDATA, ask);
            //Marshal.FreeHGlobal(ptrs);


        }



        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new StockDataDriver());
        }

        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1040, 572);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(37, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(3, 3);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(1021, 653);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1050, 115);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(37, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // StockDataDriver
            // 
            this.ClientSize = new System.Drawing.Size(1127, 668);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.button1);
            this.Name = "StockDataDriver";
            this.ResumeLayout(false);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            GetKMIN5();
        }

    }

}
