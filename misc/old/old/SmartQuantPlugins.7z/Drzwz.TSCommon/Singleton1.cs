using System;
using System.Collections.Generic;
using System.Text;

namespace Common
{
    public sealed class Singleton
    {
        private static volatile Singleton instance;

        public static TongShiWindow RTdrv = new TongShiWindow();
        private Singleton()
        {

        }

        public static Singleton Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (RTdrv)
                    {
                        if (instance == null)
                            instance = new Singleton();
                    }
                }
                return instance;

            }
        }
       
    }
}
