using System;
using System.IO;

namespace Drzwz.TSCommon
{
	/// <summary>
	/// FinanceStruct ��ժҪ˵����
	/// </summary>

	
	public struct FinanceStruct
	{
		public DateTime  mtime; //��1970-1-1�պ������
		public float fsonggu; //�͹�
		public float fpeigu; //���
		public float fpeigujia;//��ɼ�
		public float fcash;//�ֽ����

		
		public static  FinanceStruct read(BinaryReader br)
		{
			FinanceStruct  s= new  FinanceStruct();
			DateTime temptime=new DateTime(1970,1,1);
             
			s.mtime=temptime.AddSeconds((double)(br.ReadInt32()));
			s.fsonggu=br.ReadSingle();
			s.fpeigu =br.ReadSingle();
			s.fpeigujia=br.ReadSingle();
			s.fcash=br.ReadSingle();   
			
			return s;
		}

		
	}
}
