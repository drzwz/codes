using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Win32;
using System.Data;

namespace Drzwz.TSCommon
{
   public  class IHisDataCollection
    {
        private string fxjpath = string.Empty;
        private int FxjVer;

       public IHisDataCollection() 
       {
           get_fxj_path();
       } 
        public SortedList<DateTime, WLDTBar_STRUCT> requestBar(string Symbol,  TSCommon.BarIntervalEnum RequestType, int BarInterval)
        {
            SortedList<DateTime, WLDTBar_STRUCT> Tbars = new SortedList<DateTime, WLDTBar_STRUCT>();

            try
            {
                switch (RequestType)
                {
                    case TSCommon.BarIntervalEnum.biTicks:

                        Tbars = StMyFunction.vol_to_netvol(GetHisTicks(Symbol));
                        break;
                    case TSCommon.BarIntervalEnum.biMinutes:
                        if ((BarInterval % 5) == 0)
                        {   //�ɽ���Ϊʵ�ʳɽ���(�������vol_to_netvol)
                            Tbars = GetHis5MinORdaily(Symbol, "Min.dat");

                        }
                        else
                        {   //���ǣ��ı���ʱ���ӷֱ�������ת���ɷ���(�ɽ���Ϊ�ۼƳɽ��� )
                            Tbars = StMyFunction.vol_to_netvol(StMyFunction.tick2min(GetHisTicks(Symbol), BarInterval, false));
                        }
                        break;
                    case TSCommon.BarIntervalEnum.biDaily:
                        //�ɽ���Ϊʵ�ʳɽ���(�������vol_to_netvol)
                        Tbars = GetHis5MinORdaily(Symbol, "day.dat");
                        break;
                    default:
                        break;

                }
            }
            catch (Exception ex) { StMyFunction.textwrite(string.Format("{0}\t����ʷ���ݳ����� �������ࣺ{1} \t ������Ϣ :{2} ", DateTime.Now, RequestType, ex.Message)); }
            
            return Tbars;
        }


        #region ����ʷ����
        private void get_fxj_path()
        {   string[] fxjdata=StMyFunction.GetFxjPath();
            fxjpath = fxjdata[0];
            FxjVer = int.Parse (fxjdata[1]);
             
        }

        private SortedList<DateTime, string> get_tick_file_list(string dirname)  //
        {//�ҳ������� SZ��SH Ŀ¼�зֱ��ļ�(*.prp)���ļ������������죩

            DirectoryInfo di = new DirectoryInfo(dirname);
            FileInfo[] files = di.GetFiles("*.prp");
            SortedList<DateTime, string> filelist = new SortedList<DateTime, string>();

            if (files.Length != 0)
            {
                foreach (FileInfo filetemp in files)
                {
                    string tempfn = filetemp.Name.ToString();
                    DateTime tempdt = new DateTime(Convert.ToInt32(tempfn.Substring(0, 4)), Convert.ToInt32(tempfn.Substring(4, 2)), Convert.ToInt32(tempfn.Substring(6, 2)), 0, 0, 0);
                    string tempfullfn = filetemp.FullName.ToString();

                    filelist.Add(tempdt, tempfullfn);
                }

                DateTime comparedt = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 0, 0, 0);

                for (int i = filelist.Count - 1; i > -1; i--)
                {
                    if (DateTime.Compare(comparedt, (DateTime)filelist.Keys[i]) > 0)
                    {   //�Ƴ�����ֱ��ļ�
                        filelist.RemoveAt(i);
                        break;
                    }
                }
            }

            return filelist;
        }

        /// <summary> historytickdata
        ///  ����������ʷ�ֱ��ļ�(tick)
        /// </summary>
        /// <param name="symbol">֤ȯ����</param>
        /// <returns>ע�ⷵ�طֱ����ݵĳɽ���Ϊ�ۼƳɽ�����
        /// ����ת��������ʱ�����Ļ�Ҫת����ʵ�ɽ��� ����vol_to_netvol
        /// ���ظ�ʽΪ (DateTime,WLDTBar_STRUCT)
        /// </returns>

        private SortedList<DateTime, WLDTBar_STRUCT> GetHisTicks(string symbol)
        {
            string tempsymbol = symbol;

            SortedList<DateTime, WLDTBar_STRUCT> tempsl = new SortedList<DateTime, WLDTBar_STRUCT>();

            string mainpath = string.Empty;
            if (tempsymbol.Substring(7, 2) == "SZ")
            {
                mainpath = fxjpath + "\\data\\sz\\";
            }
            else
            {
                mainpath = fxjpath + "\\data\\sh\\";
            }
            SortedList<DateTime, string> tickfilelist = get_tick_file_list(mainpath);

            foreach (string FILE_NAME in tickfilelist.Values)
            {
                ITickBarsReader TickDataReader = new ITickBarsReader(FILE_NAME);
                FxjTickDetailStruct TickData;
                TickDataReader.Open();

                if (TickDataReader.SeekIndex(tempsymbol.Substring(0, 6)))
                {
                    while (TickDataReader.read_bars_EOF())
                    {
                        TickData = TickDataReader.data;
                        WLDTBar_STRUCT wld_tick = new WLDTBar_STRUCT();
                        wld_tick.fOpen = TickData.newprice;
                        wld_tick.fHigh = TickData.newprice;
                        wld_tick.fLow = TickData.newprice;
                        wld_tick.fClose = TickData.newprice;
                        wld_tick.fVolume = (int)TickData.volume;
                        wld_tick.fAsk = 0;
                        wld_tick.fBid = 0;
                        while (tempsl.ContainsKey(TickData.dt_of_tick))
                        {
                            TickData.dt_of_tick = TickData.dt_of_tick.AddTicks(1);
                        }
                        tempsl.Add(TickData.dt_of_tick, wld_tick);
                    }
                }
                TickDataReader.Close();
                TickDataReader = null;
            }

            return tempsl; //���û���ݷ��ؿյ�sortedlist ע���ⲻ�Ƿ���null!!
        }//~
        /// <summary>
        /// ��������5���������ļ�
        /// </summary>
        /// <param name="Symbol"></param>
        /// <returns>ע�ⷵ�صĳɽ������Ǿ��ɽ���</returns>
        private SortedList<DateTime, WLDTBar_STRUCT> GetHis5MinORdaily(string Symbol,string filename)
        {
            //���������ļ���ΪMin.dat
            //�����ļ���ΪDay.dat
            string tempsymbol = Symbol;
            string FILE_NAME = "";
            IDayBarsReader daylinereader;
            SortedList<DateTime, WLDTBar_STRUCT> Tbars = new SortedList<DateTime, WLDTBar_STRUCT>();
            try
            {
                if (tempsymbol.Substring(7, 2) == "SZ")
                {
                    FILE_NAME = fxjpath + "\\data\\sz\\" + filename;
                }
                else
                {
                    FILE_NAME = fxjpath + "\\data\\sh\\" + filename;
                }

                tempsymbol = tempsymbol.Remove(6, 3);
                if (File.Exists(FILE_NAME))
                {
                    daylinereader = new IDayBarsReader(FILE_NAME);
                    daylinereader.Open();

                    List<DayLineStruct> templist = daylinereader.ReadBars(tempsymbol);
                    daylinereader.Close();


                    StkinfoReader stkinforeader = new StkinfoReader();
                    List<FinanceStruct> financedata = stkinforeader.GetFinanceData(FxjVer, fxjpath, Symbol);

                    for (int i = 0; i < templist.Count; i++)
                    {
                        DayLineStruct tempdata = templist[i];
                        WLDTBar_STRUCT tempbars;

                        tempbars.fOpen = returnprice(tempdata.mtime, tempdata.fopen, financedata);
                        tempbars.fHigh = returnprice(tempdata.mtime, tempdata.fhigh, financedata);
                        tempbars.fLow = returnprice(tempdata.mtime, tempdata.flow, financedata);
                        tempbars.fClose = returnprice(tempdata.mtime, tempdata.fclose, financedata);
                        if (tempdata.fvolume == 0 || tempdata.fmoney == 0)
                        {
                            tempbars.fVolume = 0;
                        }
                        else
                        {
                            tempbars.fVolume = (int)(tempdata.fmoney / (returnprice(tempdata.mtime, tempdata.fmoney / tempdata.fvolume, financedata)));
                        }
                        tempbars.fBid = 0;
                        tempbars.fAsk = 0;

                        Tbars.Add(tempdata.mtime, tempbars);
                    }
                }
            }
            catch (Exception ex) 
            {
                StMyFunction.textwrite(string.Format("{0}\t����{1}\t������Ϣ:{1}\t �������ƣ�GetHis5MinORdaily ������1",
                     DateTime.Now,Symbol , ex.Message));
            }
            return Tbars;
        }
        //��Ȩ����
        private float returnprice(DateTime indate, float inprice, List<FinanceStruct> finacedatalist)
        {
            float tempprice = inprice;
            for (int i = 0; i < finacedatalist.Count; i++)
            {
                FinanceStruct temp = finacedatalist[i];

                if (DateTime.Compare(indate, temp.mtime) < 0)
                {
                    tempprice = ((tempprice - temp.fcash) / (1 + temp.fsonggu) + temp.fpeigu * temp.fpeigujia) / (1 + temp.fpeigu);
                    //=����A-������/��1+�͹ɣ�+�����*��ɽ�/��1+�������
                }
            }

            return (float)(Math.Round (tempprice,2));

        }
        #endregion

        
        
        

        

       
       
        
    }
}
