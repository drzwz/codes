﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Threading;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Drawing.Design;
using SmartQuant;
using SmartQuant.Data;
using SmartQuant.Series;
using SmartQuant.Providers;
using SmartQuant.Instruments;

namespace Drzwz
{
    public class FT2SQ : IProvider, IHistoryProvider
    {

        public FT2SQ()
        {
            ProviderManager.Add(this);
        }
        #region 导入数据的方法
        private string dataFile = @"D:\FinData\FoxTrader\qhhq.qda";
        private string symbolRegex = string.Empty;
        private bool autoImport = true;
        [Category("设置"), Description("QDA文件"),
        Editor(typeof(System.Windows.Forms.Design.FileNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string DataFile
        {
            get { return this.dataFile; }
            set
            {
                this.dataFile = value.Trim();
            }
        }
        [Category("设置"), Description("要导入数据的代码的正则表达式；若为空则导入QDA文件中的所有代码。"), DefaultValue("")]
        public string SymbolRegex
        {
            get { return this.symbolRegex; }
            set
            {
                this.symbolRegex = value.Trim();
            }
        }
        [Category("设置"), Description("true-连接后自动导入；false-连接后不导入，若运行中，则中断导入。"), DefaultValue("")]
        public bool AutoImport
        {
            get { return this.autoImport; }
            set
            {
                this.autoImport = value;
            }
        }
        private void doWork()
        {
            try
            {
                if (File.Exists(this.dataFile) == false)
                {
                    Console.WriteLine("{0}不存在！", this.dataFile);
                    this.Disconnect();
                    return;
                }
                bool regexIsNotEmpty = (this.symbolRegex != string.Empty);
                
                FileStream fs = new FileStream(this.dataFile, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                int flag = br.ReadInt32();
                if(flag!=-30) 
                {
                    Console.WriteLine("{0} {1}不是有效的QDA文件！",DateTime.Now, this.dataFile);
                    this.Disconnect();
                    br.Close();
                    fs.Close();
                    return;
                }
                fs.Position = 8;
                uint secCounts = br.ReadUInt32();
                string dm, jc, mkt,symbol, securitytype; uint recordCounts;
                uint rq; float kp, zg, zd, sp, sl, cc, zz;
                DateTime dt70 = new DateTime(1970, 1, 1);
                //DailySeries ds;
                StringBuilder sb = new StringBuilder(); sb.AppendLine();
                Console.WriteLine("{0} 开始导入{1}中的数据（含{2}个代码；如果数据已存在，则导入较慢）...", DateTime.Now,this.dataFile,secCounts);
                int num = 0;
                for (int sec = 0; sec < secCounts; sec++)
                {
                    Application.DoEvents();
                    if (!this.autoImport)
                    {
                        Console.WriteLine("{0} 处理了{1}个代码后，用户中断操作(AutoImport被设为False)。", DateTime.Now, sec);
                        break;
                    }
                    //读取代码信息:dm jc recordCounts
                    dm = Encoding.Default.GetString(br.ReadBytes(12));//dm 12B
                    jc = Encoding.Default.GetString(br.ReadBytes(12));//jc 12B
                    recordCounts = br.ReadUInt32();//记录数 4B
                    int dmlen = dm.IndexOf('\0');
                    if (dmlen > 0) dm = dm.Substring(0, dmlen + 1);
                    dm = dm.Replace("\0", "");
                    mkt=dm.Substring(0, 2);
                    symbol = dm.Substring(2,dm.Length-2)+"."+ mkt;
                    //securitytype = Drzwz.SQCommon.GetSecurityType(symbol);
                    jc = jc.Replace("\0", "");
                    //Console.WriteLine("{0} 正在读取{1}...", DateTime.Now, symbol);

                    //如果与SymbolRegex不匹配，则不导入，文件指针往后移动recordCounts*32个字节
                    if (regexIsNotEmpty)
                    {
                        if (!Regex.IsMatch(symbol, this.symbolRegex))
                        {
                            fs.Position = fs.Position + 32 * recordCounts;
                            //Console.WriteLine("{0} {1}与SymbolRegex不匹配。不导入。", DateTime.Now, symbol);
                            continue;
                        }
                    }
                    //判断该symbol是否已存在
                    Instrument instrument = InstrumentManager.Instruments[symbol];
                    if (instrument == null)
                    {
                        instrument = new Instrument(symbol, "Z");
                        instrument.SecurityDesc = jc;
                        instrument.SecurityExchange = mkt;
                        instrument.Save();
                        sb.Append(symbol + "(新)");
                        //Console.WriteLine("{0} 添加SYMBOL {1}。", DateTime.Now, symbol);
                    }
                    else
                    {
                        sb.Append( symbol+" ");
                    }
                    num++;
                    if (num % 10 == 0) sb.AppendLine();
                    //导入数据
                    DateTime dt ;
                    Daily daily;
                    //ds = instrument.GetDailySeries();
                    //Console.WriteLine("{0} 准备导入{1}的数据。", DateTime.Now, symbol);
                    for (int r = 0; r < recordCounts; r++)
                    {
                        rq = br.ReadUInt32();
                        kp = br.ReadSingle();
                        zg = br.ReadSingle();
                        zd = br.ReadSingle();
                        sp = br.ReadSingle();
                        sl = br.ReadSingle();
                        cc = br.ReadSingle();
                        zz = br.ReadSingle();
                        dt = dt70.AddDays(rq / 86400);
                        
                        daily = new Daily(dt, (double)kp, (double)zg, (double)zd, (double)sp, (long)Math.Round(sl, 0), (long)Math.Round(cc, 0));
                        instrument.Add(daily);
                        //Console.WriteLine("添加了{0}: {1}  {2}  {3} ", symbol, jc, dt70.AddDays(rq / 86400).ToString("yyyy-MM-dd"), sp);
                    }
                }
                br.Close();
                fs.Close();

                Console.WriteLine("{0} 导入完成，共导入{1}个代码。\n {2}", DateTime.Now,num,sb.ToString());
                this.Disconnect();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        #endregion

        #region IProvider 成员
        private bool isConnected = false;

        public void Connect(int timeout)
        {
            this.Connect();
            ProviderManager.WaitConnected(this, timeout);
        }
        public void Connect()
        {
            isConnected = true;
            Console.WriteLine("{0} Connected!",DateTime.Now);
            if (Connected != null)
                Connected(this, new EventArgs());
            this.doWork();
            //Thread th = new Thread(new ThreadStart(this.doWork));
            //th.Start();
        }
        public event EventHandler Connected;
        public void Disconnect()
        {
            try
            {
                Console.WriteLine("{0} Disconnected!",DateTime.Now);
                isConnected = false;
                if (Disconnected != null)
                    Disconnected(this, new EventArgs());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Disconnect：" + ex.Message);
            }

        }

        public event EventHandler Disconnected;

        public event ProviderErrorEventHandler Error;
        [Category("信息")]
        public byte Id
        {
            get { return 139; }
        }
        [Category("信息")]
        public bool IsConnected
        {
            get { return isConnected; }
        }
        [Category("信息")]
        public string Name
        {
            get { return "FT2SQ"; }
        }
        [Category("信息")]
        public string Title
        {
            get { return "FT2SQ 自动将FoxTrader QDA数据导入SQ。"; }
        }
        [Category("信息")]
        public string URL
        {
            get { return String.Empty; }
        }
        public void Shutdown()
        {
            
        }
        [Category("信息")]
        public ProviderStatus Status
        {
            get
            {
                if (!IsConnected)
                    return ProviderStatus.Disconnected;
                else
                    return ProviderStatus.Connected;
            }
        }

        public event EventHandler StatusChanged;

        #endregion

        #region IHistoryProvider 成员
        [Category("信息")]
        public bool BarSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool DailySupported
        {
            get { return false; }
        }

        public Bar[] GetBarHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, int barSize)
        {
            throw new NotImplementedException();
        }

        public Daily[] GetDailyHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, bool dividendAndSplitAdjusted)
        {
            throw new NotImplementedException();
        }

        public Quote[] GetQuoteHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }

        public Trade[] GetTradeHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }
        [Category("信息")]
        public bool QuoteSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool TradeSupported
        {
            get { return false; }
        }

        #endregion
    }
}
