﻿using System;
using System.Drawing;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Drawing.Design;
using System.Windows.Forms;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;
using System.Reflection.Emit;
using System.Reflection;
using System.Net;
using System.IO;
using System.Net.Sockets;
using SmartQuant.FIX;
using SmartQuant.Providers;
using SmartQuant.Instruments;
using SmartQuant.Data;
using SmartQuant.File;

namespace SmartQuant.Pobo
{

    public class PoboLocalProvider : IProvider,  IHistoryProvider
    {
        private string poboPath = @"D:\GLPobo\Pobo\";
        private string poboBlocks = "我的板块";
        public PoboLocalProvider()
        {
            ProviderManager.Add(this);
        }
        [Category("设置"),DefaultValue(@"D:\GLPobo\Pobo\")]
        public string PoboPath
        {
            get { return this.poboPath; }
            set { this.poboPath = value; }
        }
        [Category("设置"),Description("自动添加到Instrument的板块；\n多个板块以半角分号隔开。"), DefaultValue("我的板块")]
        public string PoboBlocks
        {
            get { return this.poboBlocks; }
            set { this.poboBlocks = value; }
        }
        #region IProvider 成员
        private bool isConnected = false;
        public void Connect(int timeout)
        {
            this.Connect();
            ProviderManager.WaitConnected(this, timeout);
        }

        public void Connect()
        {
            if (System.IO.Directory.Exists(this.poboPath))
            {
                PoboReader.PoboPath = this.PoboPath;

                SortedList<string, PoboSymbol> poboSymbolList = PoboReader.PoboSymbolList;
                string[] blockArray = this.poboBlocks.Split(';');
                for (int i = 0; i < blockArray.Length;i++ )
                {
                    Dictionary<string, string> dict = PoboReader.GetBlockSymbols(blockArray[i]);
                    foreach (string symbol in dict.Keys)
                    {
                        if (poboSymbolList.ContainsKey(symbol) && !InstrumentManager.Instruments.Contains(symbol))
                        {
                            PoboSymbol pbsymbol = poboSymbolList[symbol];
                            Instrument instrument = new Instrument(symbol, "Futures");
                            instrument.SecurityDesc = pbsymbol.Name;
                            //instrument.SecurityExchange = pbsymbol.FolderName;
                            instrument.Save();
                        }
                    }
                }
                isConnected = true;
                if (Connected != null)
                    Connected(this, new EventArgs());
            }
            else
            {
                this.EmitError(-1, -1, this.poboPath+"的Pobo文件夹不存在！");
            }
        }

        public event EventHandler Connected;

        public void Disconnect()
        {
            isConnected = false;
            if (Disconnected != null)
                Disconnected(this, new EventArgs());
        }

        public event EventHandler Disconnected;

        public event ProviderErrorEventHandler Error;
        [Category("信息")]
        public byte Id
        {
            get { return 132; }
        }
        [Category("信息")]
        public bool IsConnected
        {
            get { return isConnected; }
        }
        [Category("信息")]
        public string Name
        {
            get { return "PoboLocal"; }
        }

        public void Shutdown()
        {
            return;
        }
        [Category("信息")]
        public ProviderStatus Status
        {
            get
            {
                if (!IsConnected)
                    return ProviderStatus.Disconnected;
                else
                    return ProviderStatus.Connected;
            }
        }

        public event EventHandler StatusChanged;
        [Category("信息")]
        public string Title
        {
            get { return "Pobo's 本地数据 Provider"; }
        }
        [Category("信息")]
        public string URL
        {
            get { return ""; }
        }

        #endregion
        private void EmitError(int id, int code, string message)
        {

            if (Error != null)

                Error(new ProviderErrorEventArgs(new ProviderError(Clock.Now, this, id, code, message)));

        }
        #region IHistoryProvider 成员
        [Category("支持类型")]
        public bool BarSupported
        {
            get { return false; }
        }
        [Category("支持类型")]
        public bool DailySupported
        {
            get { return true; }
        }
        [Category("支持类型")]
        public bool QuoteSupported
        {
            get { return false; }
        }
        [Category("支持类型")]
        public bool TradeSupported
        {
            get { return false; }
        }
        public Bar[] GetBarHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, int barSize)
        {
            throw new NotImplementedException();
        }
        public Daily[] GetDailyHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, bool dividendAndSplitAdjusted)
        {
            lock (this)
            {
                List<Daily> list = new List<Daily>();
                string symbol = instrument.Symbol;
                SortedList<string, PoboSymbol> poboSymbolList = PoboReader.PoboSymbolList;
                if (poboSymbolList.ContainsKey(symbol))
                {
                    PoboSymbol pbsymbol = poboSymbolList[symbol];
                    list = PoboReader.GetDailyList(pbsymbol);

                }
                return (list.ToArray());
            }
        }

        public Quote[] GetQuoteHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }
        public Trade[] GetTradeHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }
        #endregion
    }

    /// <summary>
    /// 读取Pobo本地数据。
    /// </summary>
    public class PoboReader
    {
        private static string poboPath = "";
        public static string PoboPath
        {
            get { return poboPath; }
            set { poboPath = value; }
        }
        public static SortedList<string, PoboSymbol> PoboSymbolList
        {
            get
            {
                SortedList<string, PoboSymbol> poboSymbolList = new SortedList<string, PoboSymbol>();
                SortedList<string, PoboMarketInfo> mktList = GetMarketInfo();
                for (int m = 0; m < mktList.Count; m++)
                {
                    SortedList<string, PoboSymbol> list = GetSymbolList(mktList.Values[m].FolderName);
                    for (int i = 0; i < list.Count; i++)
                    {
                        PoboSymbol pbSymbol = list.Values[i];
                        pbSymbol.FolderName = mktList.Values[m].FolderName;
                        if (!poboSymbolList.ContainsKey(list.Keys[i])) poboSymbolList.Add(list.Keys[i], pbSymbol);
                    }
                }
                return poboSymbolList;
            }
        }
        /// <summary>
        /// 从mkinfo.cfg获取PoboMarketInfo
        /// </summary>
        /// <returns></returns>
        public static SortedList<string, PoboMarketInfo> GetMarketInfo()
        {
            SortedList<string, PoboMarketInfo> list = new SortedList<string, PoboMarketInfo>();
            FileStream fs = new FileStream(Path.Combine(poboPath, @"cfg\mkinfo.cfg"), FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            long pos = 0;
            long l = fs.Length;
            while (pos < l)
            {
                fs.Position = pos;
                PoboMarketInfo mktInfo = new PoboMarketInfo();
                mktInfo.ID = br.ReadByte();
                fs.Position += 1;
                string s = Encoding.Default.GetString(br.ReadBytes(15));
                s = s.Substring(0, s.IndexOf("\0") + 1).Replace("\0", "");
                mktInfo.Name = s;
                mktInfo.FolderName = Encoding.Default.GetString(br.ReadBytes(8)).Replace("\0", "");
                list.Add(mktInfo.FolderName, mktInfo);
                pos += 1590;
            }
            br.Close();
            fs.Close();
            return list;
        }
        /// <summary>
        /// 从Nametbl.pb 获取PoboSymbol
        /// </summary>
        /// <param name="marketFolder"></param>
        /// <returns></returns>
        public static SortedList<string, PoboSymbol> GetSymbolList(string marketFolder)
        {
            SortedList<string, PoboSymbol> list = new SortedList<string, PoboSymbol>();
            FileStream fs = new FileStream(Path.Combine(poboPath, @"data\" + marketFolder + @"\NAMETBL.PB"), FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            long pos = 0;
            long l = fs.Length;
            //sas:input u1 ib2. dm $6. u2 ib1. jc $8.  u3 ib1. bs ib2.  ;
            while (pos < l)
            {
                fs.Position = pos + 2;
                PoboSymbol poboSymbol = new PoboSymbol();
                string s = Encoding.Default.GetString(br.ReadBytes(6));
                poboSymbol.Symbol = s.Trim().Replace("\0", "");
                fs.Position += 1;
                s = Encoding.Default.GetString(br.ReadBytes(8));
                poboSymbol.Name = s.Trim().Replace("\0", "");
                fs.Position += 1;
                poboSymbol.Divisor = br.ReadInt16();
                fs.Position += 6;
                poboSymbol.PriceDigits = br.ReadByte();  //offset:1A
                fs.Position += 1;
                poboSymbol.No = br.ReadByte();
                poboSymbol.FolderName = marketFolder;
                if (!list.ContainsKey(poboSymbol.Symbol)) list.Add(poboSymbol.Symbol, poboSymbol);
                pos += 32;
            }
            br.Close();
            fs.Close();
            return list;
        }
        /// <summary>
        /// 取板块中的代码及其所处目录名
        /// </summary>
        /// <param name="blockName">板块名称</param>
        /// <returns>代码及其所处目录名</returns>
        public static Dictionary<string, string> GetBlockSymbols(string blockName)
        {
            Dictionary<string, string> dict = new Dictionary<string, string>();

            string userPath = IniFile.ReadIniData("PATH", "userpath", "", Path.Combine(PoboPath, @"cfg\userpath.ini"));
            string s = "";
            int blockID = 1;
            do
            {
                s = IniFile.ReadIniData(blockName, "i" + blockID.ToString().Trim(), "", Path.Combine(userPath, @"blocks.ini"));
                string[] ss = s.Split('\x20');
                if (ss.Length >= 2)
                {
                    if (!dict.ContainsKey(ss[1])) dict.Add(ss[1], ss[0]);
                }
                blockID++;
            } while (s != "");
            return dict;
        }

        public static List<Daily> GetDailyList(PoboSymbol pbSymbol)
        {
            List<Daily> dailyList = new List<Daily>();
            string filePath = Path.Combine(poboPath, @"data\" + pbSymbol.FolderName + @"\Day\" + pbSymbol.Symbol.Trim() + @".DAY");
            if (System.IO.File.Exists(filePath))
            {
                FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                double div = pbSymbol.Divisor * 1.0;
                int pd = pbSymbol.PriceDigits;
                long pos = 0;
                long filelen = fs.Length;
                while (pos < filelen)
                {
                    fs.Position = pos;
                    uint rq = br.ReadUInt32();
                    int sp = br.ReadInt32();
                    int kp = br.ReadInt32();
                    int zg = br.ReadInt32();
                    int zd = br.ReadInt32();
                    long sl = (long)Math.Round(br.ReadSingle(), 0);
                    long cc = (long)Math.Round(br.ReadSingle(), 0);
                    int y = int.Parse((rq >> 20).ToString());
                    int m = int.Parse((rq << 12 >> 28).ToString());
                    int d = int.Parse((rq << 16 >> 27).ToString());

                    Daily daily = new Daily(new DateTime(y, m, d), Math.Round(kp / div, pd), Math.Round(zg / div, pd), Math.Round(zd / div, pd), Math.Round(sp / div, pd), sl, cc);
                    dailyList.Add(daily);
                    pos += 32;
                }
                br.Close();
                fs.Close();
            }
            return dailyList;
        }
    }
    public struct PoboMarketInfo
    {
        public byte ID;
        public string Name;
        public string FolderName;
    }
    public struct PoboSymbol
    {
        public string Symbol;
        public string Name;
        public short Divisor;
        public byte PriceDigits;
        public byte No;
        public string FolderName;
    }

    public class IniFile
    {
        #region API函数声明

        [System.Runtime.InteropServices.DllImport("kernel32")]//返回0表示失败，非0为成功
        private static extern long WritePrivateProfileString(string section, string key,
            string val, string filePath);

        [System.Runtime.InteropServices.DllImport("kernel32")]//返回取得字符串缓冲区的长度
        private static extern long GetPrivateProfileString(string section, string key,
            string def, StringBuilder retVal, int size, string filePath);


        #endregion

        #region 读Ini文件

        public static string ReadIniData(string Section, string Key, string NoText, string iniFilePath)
        {
            if (System.IO.File.Exists(iniFilePath))
            {
                StringBuilder temp = new StringBuilder(1024);
                GetPrivateProfileString(Section, Key, NoText, temp, 1024, iniFilePath);
                return temp.ToString();
            }
            else
            {
                return String.Empty;
            }
        }

        #endregion

        #region 写Ini文件

        public static bool WriteIniData(string Section, string Key, string Value, string iniFilePath)
        {
            if (System.IO.File.Exists(iniFilePath))
            {
                long OpStation = WritePrivateProfileString(Section, Key, Value, iniFilePath);
                if (OpStation == 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                return false;
            }
        }

        #endregion
    }
}
