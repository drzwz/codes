using System;
using System.Drawing;
using System.ComponentModel;
using System.ComponentModel.Design ;
using System.Drawing.Design;
using System.Windows.Forms;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;
using System.Reflection.Emit;
using System.Reflection;
using System.Net;
using System.IO;
using System.Net.Sockets;
using SmartQuant.FIX;
using SmartQuant.Providers;
using SmartQuant.Instruments;
using SmartQuant.Data;
using SmartQuant.File;

namespace SmartQuant.Pobo
{
    /// <summary>
    /// ��Pobo��������ȡMarketData����Pobo�����ļ���ȡHistoryData��
    /// </summary>
    public class TPoboProvider : IProvider,IMarketDataProvider
    {
        private IBarFactory factory;
        //private int LOTSIZE = 100;

        private bool isConnected = false;
        //private string pwd = "";
        private Hashtable subscribedSymbols = new Hashtable();
        private Hashtable symbolMaps = new Hashtable();
        private PoboAccountItemList accounts;
        private Hashtable adapters;
        //protected SCRTcontrol fTSdrv;
        private Hashtable QuoteCache = Hashtable.Synchronized(new Hashtable());
        //[Editor(typeof(PoboAccountListEditor), typeof(UITypeEditor))]
        //public Simulator Simulator { get; }
        [Category("Accounts")]
        public PoboAccountItemList Accounts
        {
            get
            {
                return this.accounts;
            }
        }
        //[Category("Accounts"), PasswordPropertyText(true )]
        //public string Password
        //{
        //    get
        //    {
        //        return pwd;
        //    }
        //    set
        //    {
        //        pwd = value;
        //    }
        //}

        public TPoboProvider()
        {
            //factory = new BarFactory(false);
            this.BarFactory = new BarFactory(false);
            adapters = new Hashtable();
            accounts = new PoboAccountItemList();
            accounts.Add("61.144.235.20", 13152, 13153, "1111", "1111");
            //fTSdrv = new SCRTcontrol();
            //fTSdrv.OnSC_Symbol += new SC_Symbols_EventHandler(fTSdrv_OnSC_Symbol);
            //fTSdrv.OnQuote += new SC_NOWDATAEventHandler(fTSdrv_OnQuote);
            //fTSdrv.OnSC_PANKOU += new SC_PANKOU_EventHandler(fTSdrv_OnSC_TraceDnld);
            ProviderManager.Add(this);

        }
        #region IProvider Members

        public void Connect(int timeout)
        {
            this.Connect();
            ProviderManager.WaitConnected(this, timeout);
        }

        public void Connect()
        {

            if (!isConnected)
            {
                if (accounts.Count == 0)
                {
                    MessageBox.Show("No server cfg exists, please add at least one Pobo server to connect.", "Error Message");
                    //if (Disconnected != null)

                    //    Disconnected(this, new EventArgs());
                }
                else
                {
                    //MessageBox.Show("Nothing wrong");
                    if (adapters.Count > 0)
                    {
                        foreach (PoboAdapter adapter in adapters.Values )
                        {
                            adapter.OnConnection -= new PoboConnectionEventHandler(adapter_OnConnection);
                        }
                        adapters.Clear();
                    }
                    for (int k = 0; k < accounts.Count; k++)
                    {
                        PoboAccountItem ac = accounts[k];
                        PoboAdapter adapter = null;
                        if (!adapters.ContainsKey(k))
                        {
                            adapter = new PoboAdapter(ac);
                            adapters.Add(k, adapter);
                        }
                        else
                        {
                            adapter = (PoboAdapter)adapters[k];
                        }
                        if (k == 0)
                        {
                            adapter.SetAsPrimary();
                        }
                        adapter.OnConnection += new PoboConnectionEventHandler(adapter_OnConnection);
                        adapter.OnQuote += new PoboQuoteEventHandler(adapter_OnQuote);
                        //adapter1.OnRawQuote += new PoboRawQuoteEventHandler(adapter_OnRawQuote);
                        adapter.OnInstrumentDef += new PoboInstrumentDefEventHandler(adapter_OnInstrumentDef);
                        Thread t = new Thread(new ThreadStart(adapter.Connect));
                        t.Start();
                    }
                    //PoboAccountItem ac1 = accounts[0];
                    //PoboAdapter adapter1 = null ;
                    //if (!adapters.ContainsKey(0))
                    //{
                    //    adapter1 = new PoboAdapter(ac1);
                    //    adapters.Add(0, adapter1);
                    //}
                    //else
                    //{
                    //    adapter1 = (PoboAdapter)adapters[0];
                    //}
                    //adapter1.SetAsPrimary();
                    //adapter1.OnConnection += new PoboConnectionEventHandler(adapter_OnConnection);
                    //adapter1.OnQuote += new PoboQuoteEventHandler(adapter_OnQuote);
                    ////adapter1.OnRawQuote += new PoboRawQuoteEventHandler(adapter_OnRawQuote);
                    //adapter1.OnInstrumentDef += new PoboInstrumentDefEventHandler(adapter_OnInstrumentDef);
                    //Thread t = new Thread(new ThreadStart(adapter1.Connect));
                    //t.Start();

                }

            }
        }

        void adapter_OnRawQuote(PoboAdapter sender, string pobosymbol,byte[] qbuffer)
        {
            //throw new Exception("The method or operation is not implemented.");
            //string Symbol = pobosymbol;
            //Console.WriteLine(Symbol);
            //if (Symbol == "040011")
            //{
            //    int last = BitConverter.ToInt32(qbuffer, 20);
            //    int bid = BitConverter.ToInt32(qbuffer, 36);
            //    Console.WriteLine(last.ToString("F2"));
            //    Console.WriteLine(bid.ToString("F2"));
            //}

            //if (symbolMaps.Contains(Symbol))
            //{
            //    //Console.WriteLine(Symbol + " rcved");

            //    bool isNewTrade = true;
            //    bool isNewQuote = true;
            //    //bool isNewDepth = true;
            //    Instrument instrument = (Instrument)symbolMaps[Symbol];
            //    //PoboQuote report = quote;

            //    DateTime timestamp = DateTime .Now ;
            //    SmartQuant.Data.Trade td = new SmartQuant.Data.Trade();
            //    td.DateTime = timestamp;

            //    SmartQuant.Data.Quote qt = new SmartQuant.Data.Quote();
            //    qt.DateTime = timestamp;

            //    //int divisor = 1;
            //    int divisor = ((PoboSymbolDef)subscribedSymbols[Symbol]).pDivisor;
            //    //int digits = (int)((PoboSymbolDef)subscribedSymbols[Symbol]).pPriceDigits;

            //    if (!QuoteCache.ContainsKey(Symbol))
            //    {
            //        //td.Price = (double)Math.Round((double)quote.Last / divisor, digits);
            //        td.Price = (double)quote.Last / divisor;
            //        td.Size = (int)quote.Size;
            //        //qt.Bid = (double)Math.Round((double)quote.Bid1 / divisor, digits);
            //        //qt.Ask = (double)Math.Round((double)quote.Ask1 / divisor, digits);
            //        qt.Bid = (double)quote.Bid1 / divisor;
            //        qt.Ask = (double)quote.Ask1 / divisor;
            //        qt.BidSize = (int)quote.Bidsize1;
            //        qt.AskSize = (int)quote.Asksize1;

            //        QuoteCache.Add(Symbol, quote);
            //    }
            //    else
            //    {
            //        PoboQuote lastreport = (PoboQuote)QuoteCache[Symbol];
            //        //int divisor = ((PoboSymbolDef)subscribedSymbols[Symbol]).pDivisor;
            //        if (lastreport.Volume < quote.Volume)
            //        {
            //            //td.Price = (double)Math.Round((double)quote.Last / divisor, digits);
            //            //double p = ((double)quote.Last )/ divisor;
            //            //double p = (double)quote.Last;
            //            td.Price = (double)quote.Last / divisor;
            //            td.Size = (int)quote.Size;
            //            if (Symbol == "040011")
            //            {
            //                Console.WriteLine(td.Price.ToString("F2"));
            //                Console.WriteLine(quote.Last.ToString("F2"));
            //            }
            //        }
            //        else
            //        {
            //            isNewTrade = false;
            //        }
            //        if (lastreport.Ask1 != 0 || lastreport.Bid1 != 0)
            //        {
            //            if (lastreport.Ask1 != report.Ask1 || lastreport.Asksize1 != report.Asksize1
            //                || lastreport.Bid1 != report.Bid1 || lastreport.Bidsize1 != report.Bidsize1)
            //            {
            //                //qt.Bid = (double)Math.Round((double)quote.Bid1 / divisor, digits);
            //                //qt.Ask = (double)Math.Round((double)quote.Ask1 / divisor, digits);
            //                qt.Bid = (double)quote.Bid1 / divisor;
            //                qt.Ask = (double)quote.Ask1 / divisor;
            //                qt.BidSize = (int)quote.Bidsize1;
            //                qt.AskSize = (int)quote.Asksize1;
            //            }
            //            else
            //            {
            //                isNewQuote = false;
            //            }
            //        }
            //        else
            //        {
            //            isNewQuote = false;
            //            //isNewDepth = false;
            //        }
            //        QuoteCache[Symbol] = report;
            //    }
            //    if (NewTrade != null && isNewTrade && instrument.SecurityType != "FOR")
            //    {
            //        TradeEventArgs tdarg = new TradeEventArgs(td, instrument, this);
            //        NewTrade(this, tdarg);
            //    }
            //    if (NewQuote != null && isNewQuote && instrument.SecurityType != "IDX")
            //    {
            //        QuoteEventArgs qtarg = new QuoteEventArgs(qt, instrument, this);
            //        NewQuote(this, qtarg);
            //    }
            //}
        }

        void adapter_OnQuote(PoboAdapter sender, PoboQuote quote)
        {
            //throw new Exception("The method or operation is not implemented.");
            string Symbol=quote.Symbol;
            
            if (symbolMaps.Contains(Symbol))
            {
                //Console.WriteLine(Symbol + " rcved");
                
                bool isNewTrade = true;
                bool isNewQuote = true;
                //bool isNewDepth = true;
                Instrument instrument = (Instrument)symbolMaps[Symbol];
                PoboQuote report = quote;

                DateTime timestamp = quote.TimeStamp;
                SmartQuant.Data.Trade td = new SmartQuant.Data.Trade();
                td.DateTime = timestamp;

                SmartQuant.Data.Quote qt = new SmartQuant.Data.Quote();
                qt.DateTime = timestamp;

                //int divisor = 1;
                int divisor = ((PoboSymbolDef)subscribedSymbols[Symbol]).pDivisor;
                int digits = (int)((PoboSymbolDef)subscribedSymbols[Symbol]).pPriceDigits;

                if (!QuoteCache.ContainsKey(Symbol))
                {
                    td.Price = (double)Math.Round((double)quote.Last / divisor, digits);
                    //td.Price = (double)quote.Last / divisor;
                    td.Size = (int)quote.Size;
                    qt.Bid = (double)Math.Round((double)quote.Bid1 / divisor, digits);
                    qt.Ask = (double)Math.Round((double)quote.Ask1 / divisor, digits);
                    //qt.Bid = (double)quote.Bid1 / divisor;
                    //qt.Ask = (double)quote.Ask1 / divisor;
                    qt.BidSize = (int)quote.Bidsize1;
                    qt.AskSize = (int)quote.Asksize1;

                    QuoteCache.Add(Symbol, quote);
                }
                else
                {
                    PoboQuote lastreport = (PoboQuote)QuoteCache[Symbol];
                    //int divisor = ((PoboSymbolDef)subscribedSymbols[Symbol]).pDivisor;
                    if (lastreport.Volume < quote.Volume)
                    {
                        td.Price = (double)Math.Round((double)quote.Last  / divisor, digits);
                        //double p = ((double)quote.Last )/ divisor;
                        //double p = (double)quote.Last;
                        //td.Price = (double)quote.Last / divisor;
                        td.Size = (int)quote.Size;
                        //if (Symbol == "040011")
                        //{
                        //    Console.WriteLine(td.Price.ToString("F2"));
                        //    Console.WriteLine(quote.Last.ToString("F2"));
                        //}
                    }
                    else
                    {
                        isNewTrade = false;
                    }
                    if (lastreport.Ask1 != 0 || lastreport.Bid1 != 0)
                    {
                        if (lastreport.Ask1 != report.Ask1 || lastreport.Asksize1 != report.Asksize1
                            || lastreport.Bid1 != report.Bid1 || lastreport.Bidsize1 != report.Bidsize1)
                        {
                            qt.Bid = (double)Math.Round((double)quote.Bid1 / divisor, digits);
                            qt.Ask = (double)Math.Round((double)quote.Ask1 / divisor, digits);
                            //qt.Bid = (double)quote.Bid1 / divisor;
                            //qt.Ask = (double)quote.Ask1 / divisor;
                            qt.BidSize = (int)quote.Bidsize1;
                            qt.AskSize = (int)quote.Asksize1;
                        }
                        else
                        {
                            isNewQuote = false;
                        }
                    }
                    else
                    {
                        isNewQuote = false;
                        //isNewDepth = false;
                    }
                    QuoteCache[Symbol] = report;
                }
                if (NewTrade != null && isNewTrade && instrument.SecurityType != "FOR" && instrument.SecurityType != "FORWARD")
                {
                    TradeEventArgs tdarg = new TradeEventArgs(td, instrument, this);
                    NewTrade(this, tdarg);
                    BarHandler bhdlr = new BarHandler(MakeBar);
                    bhdlr.BeginInvoke(instrument, td, null, null);
                    //if (this.factory != null)
                    //{
                    //    //ThreadPool .QueueUserWorkItem(new WaitCallback (this.factory.OnNewTrade),
                    //    this.factory.OnNewTrade(instrument, td);
                    //}
                }
                if (NewQuote != null && isNewQuote && instrument.SecurityType != "IDX")
                {
                    QuoteEventArgs qtarg = new QuoteEventArgs(qt, instrument, this);
                    NewQuote(this, qtarg);
                }
            }
        }

        void adapter_OnInstrumentDef(PoboAdapter sender, PoboSymbolDef symboldef)
        {
            //throw new Exception("The method or operation is not implemented.");
            if (!subscribedSymbols.ContainsKey(symboldef.pSymbol))
            {
                if (symboldef.pSymbol != "PoboLast")
                {
                    subscribedSymbols.Add(symboldef.pSymbol, symboldef);
                    //zzz
                    //Console.WriteLine("{0} {1}", symboldef.pSymbol,symboldef.pName);
                }
                else
                {
                    //Console.WriteLine("total " + subscribedSymbols.Count );
                    int j = subscribedSymbols.Keys.Count / 250;
                    if (subscribedSymbols.Keys.Count % 250 != 0)
                    {
                        j += 1;
                    }
                    int k = 0;
                    byte[] srcbuffer = new byte[j*250 * 3];
                    foreach (string symbol in subscribedSymbols.Keys)
                    {
                        PoboSymbolDef sdef = (PoboSymbolDef)subscribedSymbols[symbol];
                        sdef.pCode.CopyTo(srcbuffer, k * 3);
                        k++;
                        if (k == subscribedSymbols.Keys.Count)
                        {
                            break;
                        }
                    }
                    int links = adapters.Count;
                    if (adapters.Count > j)
                    {
                        links = j;
                    }
                    for (int l = 0; l < adapters.Count; l++)
                    {
                        PoboAdapter adapter = (PoboAdapter)adapters[l];
                        byte[] dstbuffer = new byte[250 * 3];
                        Array.Copy(srcbuffer, l * 250 * 3, dstbuffer, 0, 250 * 3);
                        adapter.GetSymbolBuffer(dstbuffer);
                        Thread t = new Thread(new ThreadStart(adapter.RequestRTQuote));
                        t.Start();
                    }
                    //int i=0;
                    //byte[] buffer = new byte[250*3];
                    //foreach (string symbol in subscribedSymbols.Keys)
                    //{
                    //    PoboSymbolDef sdef = (PoboSymbolDef)subscribedSymbols[symbol];
                    //    sdef.pCode.CopyTo(buffer, i * 3);
                    //    i++;
                    //    if (i == 250)
                    //        break;
                    //}
                    //PoboAdapter adapter = (PoboAdapter)adapters[0];
                    //adapter.GetSymbolBuffer(buffer);
                    //Thread t=new Thread (new ThreadStart(adapter .RequestRTQuote));
                    //t.Start();
                }
            }
            //if (InstrumentManager.Instruments.Contains(symboldef.pSymbol, "Pobo"))
            //    Console.WriteLine("symbol " + symboldef.pSymbol + " found for " + InstrumentManager.Instruments[symboldef.pSymbol, "Pobo"].Symbol);
        }
        

        void adapter_OnConnection(PoboAdapter sender, bool isconnected)
        {

            if (isconnected)
            {
                isConnected = true;
                if (Connected != null)
                    Connected(this, new EventArgs());
            }
            else
            {

                isConnected = false;

                if (Disconnected != null)
                {
                    Disconnected(this, new EventArgs());
                }
                //sender.OnConnection -= new PoboConnectionEventHandler(adapter_OnConnection);
            }
        }

        public event EventHandler Connected;

        public void Disconnect()
        {
            foreach (PoboAdapter adapter in adapters.Values)
            {
                //adapter.OnConnection
                Thread t = new Thread(new ThreadStart(adapter.Disconnect));
                t.Start ();
                adapter.OnQuote -= new PoboQuoteEventHandler(adapter_OnQuote);
                //adapter.OnRawQuote -= new PoboRawQuoteEventHandler(adapter_OnRawQuote);
                //if (adapter.OnInstrumentDef != null)
                //{
                adapter.OnInstrumentDef -= new PoboInstrumentDefEventHandler(adapter_OnInstrumentDef);
                //}
            }
            //isConnected = false;

            //if (Disconnected != null)

            //    Disconnected(this, new EventArgs());
        }
        public void Shutdown()
        {
        }

        public event EventHandler Disconnected;

        public event ProviderErrorEventHandler Error;

        public byte Id
        {
            get { return 92; }
        }

        public bool IsConnected
        {
            get { return isConnected; }
        }

        public string Name
        {
            get { return "Pobo"; }
        }

        public ProviderStatus Status
        {
            get
            {

                if (!IsConnected)

                    return ProviderStatus.Disconnected;

                else

                    return ProviderStatus.Connected;

            }
        }

        public event EventHandler StatusChanged;

        public string Title
        {
            get { return "This is a Pobo provider."; }
        }

        public string URL
        {
            get { return String.Empty; }
        }

        #endregion

        #region IMarketDataProvider Members

        public IBarFactory BarFactory
        {
            get
            {
                return this.factory;
            }
            set
            {
                if (this.factory != null)
                {
                    this.factory.NewBar -= new BarEventHandler(this.OnNewBar);
                    this.factory.NewBarOpen -= new BarEventHandler(this.OnNewBarOpen);
                    this.factory.NewBarSlice -= new BarSliceEventHandler(this.OnNewBarSlice);
                }
                this.factory = value;
                if (this.factory != null)
                {
                    this.factory.NewBar += new BarEventHandler(this.OnNewBar);
                    this.factory.NewBarOpen += new BarEventHandler(this.OnNewBarOpen);
                    this.factory.NewBarSlice += new BarSliceEventHandler(this.OnNewBarSlice);
                }
            }
        }

        public event MarketDataRequestRejectEventHandler MarketDataRequestReject;

        public event MarketDataSnapshotEventHandler MarketDataSnapshot;

        public event BarEventHandler NewBar;

        public event BarEventHandler NewBarOpen;

        public event BarSliceEventHandler NewBarSlice;

        public event CorporateActionEventHandler NewCorporateAction;

        public event FundamentalEventHandler NewFundamental;

        public event BarEventHandler NewMarketBar;

        public event MarketDataEventHandler NewMarketData;

        public event MarketDepthEventHandler NewMarketDepth;

        public event QuoteEventHandler NewQuote;

        public event TradeEventHandler NewTrade;

        public void SendMarketDataRequest(FIXMarketDataRequest request)
        {
            if (!IsConnected)
            {

                EmitError(-1, -1, "Not connected.");

                return;

            }
            switch (request.SubscriptionRequestType)
            {

                case DataManager.MARKET_DATA_SUBSCRIBE:

                    for (int i = 0; i < request.NoRelatedSym; i++)
                    {

                        FIXRelatedSymGroup group = request.GetRelatedSymGroup(i);
                        Instrument instrument=InstrumentManager.Instruments[group.Symbol];
                        if (instrument != null)
                        {
                            RequestSymbol(instrument.GetSymbol(this.Name), instrument);
                        }
                        

                        //if (group.SecurityAltIDGroup[i].SecurityAltIDSource == "Pobo")
                        //{                            
                        //    string altsymbol=group.SecurityAltIDGroup[i].SecurityAltID;
                        //    //Console.WriteLine("sub " + group .Symbol +""+altsymbol );
                        //    RequestSymbol(altsymbol,InstrumentManager.Instruments[altsymbol,"Pobo"] );
                        //}

                    }
                    //FIXRelatedSymGroup group1 = request.GetRelatedSymGroup(0);
                    //if (group1.SecurityAltIDGroup[0].SecurityAltIDSource == "Pobo")
                    //{
                    //    RequestSymbol(group1.Symbol);
                    //}

                    break;

                case DataManager.MARKET_DATA_UNSUBSCRIBE:

                    //FIXRelatedSymGroup group2 = request.GetRelatedSymGroup(0);
                    //if (group2.SecurityAltIDGroup[0].SecurityAltIDSource == "Pobo")
                    //{
                    //    UnsubscribeSymbol(group2.Symbol);
                    //}

                    for (int i = 0; i < request.NoRelatedSym; i++)
                    {

                        FIXRelatedSymGroup group = request.GetRelatedSymGroup(i);
                        UnsubscribeSymbol(group.Symbol);

                        //if (group.SecurityAltIDGroup[i].SecurityAltIDSource == "Pobo")
                        //{
                        //    UnsubscribeSymbol(group.Symbol);
                        //}

                    }

                    break;

                default:

                    throw new ArgumentException("Unknown subscription type: " + request.SubscriptionRequestType.ToString());

            }
        }

        #endregion
        private void RequestSymbol(string symbol,Instrument instrument)
        {

            if (!symbolMaps.Contains(symbol))
            {
                //Console.WriteLine("sub " + symbol + " " + instrument.Symbol);
                symbolMaps.Add(symbol, instrument);
            }

            //    subscribedSymbols.Add(symbol);
            

        }
        private void UnsubscribeSymbol(string symbol)
        {
            

            if (symbolMaps.Contains(symbol))
            {
                //Console.WriteLine("unsub " + symbol);
                symbolMaps.Remove(symbol);
            }

            //    subscribedSymbols.Remove(symbol);

            //if (subscribedSymbols.Count == 0 )
            //{
            //}

        }
        private void EmitError(int id, int code, string message)
        {

            if (Error != null)

                Error(new ProviderErrorEventArgs(new ProviderError(Clock.Now, this, id, code, message)));

        }
        private void OnNewBar(object sender, BarEventArgs args)
        {
            if (this.NewBar != null)
            {
                this.NewBar(this, new BarEventArgs(args.Bar, args.Instrument, this));
            }
        }

        private void OnNewBarOpen(object sender, BarEventArgs args)
        {
            if (this.NewBarOpen != null)
            {
                this.NewBarOpen(this, new BarEventArgs(args.Bar, args.Instrument, this));
            }
        }

        private void OnNewBarSlice(object sender, BarSliceEventArgs args)
        {
            if (this.NewBarSlice != null)
            {
                this.NewBarSlice(this, new BarSliceEventArgs(args.BarSize, this));
            }
        }

        private void MakeBar(Instrument instrument, Trade trade)
        {
            if (this.factory != null)
            {
                //ThreadPool .QueueUserWorkItem(new WaitCallback (this.factory.OnNewTrade),
                this.factory.OnNewTrade(instrument, trade);
            }
        }
        private delegate void BarHandler(Instrument instrument, Trade trade);

    }
    public class PoboAdapter
    {
        #region Private field
        private string poboserver;
        private int loginport;
        private int dataport;
        private string username;
        private string password;
        private bool isprimary=false ;
        private bool stoprcv = false;
        private bool reconn = false;
        //private bool suspend = false;
        //private bool isconnected = false;
        private const int LoginSuccess = 66368;
        private const int RequestFailure = 66112;
        private const int RequestQuote = 91200;
        private const int SymbolDefinition = 67136;
        private const int NewQuote = 67648;
        //private string strFileName = @"C:\WINDOWS\Media\chimes.wav";
        private TcpClient ctrlclient;
        //private TcpClient rtdclient = null;
        private DataReceiver rtdreceiver ;
        //private DataReceiver ctrlreceiver = null;
        //private Hashtable poboSymbols = new Hashtable();
        private byte[] symbolReq=null;
        #endregion
        public event PoboConnectionEventHandler OnConnection;
        public event PoboQuoteEventHandler OnQuote;
        public event PoboRawQuoteEventHandler OnRawQuote;
        public event PoboInstrumentDefEventHandler OnInstrumentDef;

        public string PoboServer
        {
            get
            {
                return poboserver;
            }
            set
            {
                poboserver = value;
            }
        }
        public int LoginPort
        {
            get
            {
                return loginport;
            }
            set
            {
                loginport = value;
            }
        }
        public int DataPort
        {
            get
            {
                return dataport;
            }
            set
            {
                dataport = value;
            }
        }
        public string Username
        {
            get
            {
                return username;
            }
            set
            {
                username = value;
            }
        }
        public string Password
        {
            get
            {
                return password;
            }
            set
            {
                password = value;
            }
        }

        public PoboAdapter()
        {
            //username = user;
            //password = pwd;

        }
        public PoboAdapter(PoboAccountItem option)
        {
            poboserver = option .Server;
            loginport = option .LoginPort;
            dataport = option .DataPort ;
            username = option.Username;
            password = option.Password;
        }
        public void SetAsPrimary()
        {
            isprimary = true;
        }
        public void Connect()
        {
            Init();
            LoginNow();
        }
        public void Disconnect()
        {
            LogoutNow();
        }
        public void GetSymbolBuffer(byte[] symbols)
        {
            symbolReq = symbols;
        }
        public void RequestRTQuote()
        {
            //			ArrayList symbols=new ArrayList ();
            TcpClient client = new TcpClient(poboserver, dataport);
            //Console.WriteLine("Init data link " + client.GetHashCode());
            byte[] pData = new byte[774];
            //byte[] instruments = new byte[] { 0x04, 0x00, 0x00, 0x04, 0x01, 0x00 };
            //byte[] stkidx = new byte[] { 0x00, 0x00, 0x00, 0x01, 0xb9, 0x03 };//��ָ֤�������ڳ�ָ
            symbolReq.CopyTo(pData, 0);
            //stkidx.CopyTo(pData, instruments.Length);
            //BitConverter.GetBytes(instruments.Length / 3 + stkidx.Length / 3).CopyTo(pData, 768);
            BitConverter.GetBytes(symbolReq.Length / 3).CopyTo(pData, 768);
            BitConverter.GetBytes(symbolReq.Length / 3).CopyTo(pData, 770);

            pData[772] = 0x01;//n201

            rtdreceiver = new DataReceiver(ReceiveData);
            RequestMarketData(client, RequestQuote, pData);
        }
       
        private void Init()
        {
            if (poboserver ==string.Empty)
            {
                poboserver = "61.144.235.20";
                loginport = 13152;
                dataport = 13153;
                username = "1111";
                password = "1111";
            }
            //ctrlclient = null;
            //rtdreceiver = null;
        }
        private void LoginNow()
        {
            try
			{
				stoprcv=false;
				reconn=false;

				TcpClient client=new TcpClient (poboserver,loginport);
                ctrlclient = client;
                //Console.WriteLine("Init ctrl link " + ctrlclient.GetHashCode());
                byte[] pData=new byte [64];
				byte[] user_b=System.Text.Encoding.ASCII.GetBytes(username);
				byte[] pwd_b=System.Text.Encoding.ASCII.GetBytes(password );
				user_b.CopyTo (pData,0);
				pwd_b.CopyTo (pData,16);
				pData[28]=0x01;//n201

				NetworkStream stream=ctrlclient.GetStream();
				if(stream.CanWrite)
				{
					RequestCtrlData(ctrlclient,LoginSuccess,pData);
				}
				if(stream.CanRead )
				{
					byte[] response=ReceiveCtrlData(ctrlclient);
					int pactype=BitConverter.ToInt32(response,0);
					if(pactype==LoginSuccess)
					{
                        //MessageBox.Show ("Login success");
						OnLoginSuccess();
					}
					else if(pactype==RequestFailure)
					{
                        //MessageBox.Show ("Login failure");
					}
					else
					{
						Console.WriteLine ("unknow data response.");
					}
				}		
			}
            catch(Exception e)
            {
                Console.WriteLine(e.Message );
                ResetAll();
            }
        }
        private void RequestCtrlData(TcpClient client, int msgtype, byte[] command)
        {
            NetworkStream stream = client.GetStream();
            Byte[] pData = new Byte[command.Length + 10];
            BitConverter.GetBytes(msgtype).CopyTo(pData, 0);
            BitConverter.GetBytes((short)command.Length).CopyTo(pData, 6);
            command.CopyTo(pData, 10);
            stream.Write(pData, 0, pData.Length);
            stream.Flush();
        }
        private byte[] ReceiveCtrlData(TcpClient client)
        {
            NetworkStream stream = client.GetStream();
            int nRead = 0;
            int nTotal = 10;
            byte[] pData = new byte[10];
            byte[] pHeader = null;
            byte[] pCtrl = null;

            while (true)
            {
                nRead += stream.Read(pData, nRead, nTotal - nRead);
                if (pHeader == null && nRead == 10)
                {
                    nRead = 0;
                    nTotal = BitConverter.ToInt16(pData, 6);
                    pHeader = pData;
                    pData = new byte[nTotal];
                }
                if (pHeader != null && nRead == nTotal)
                {
                    stream.Flush();
                    break;
                }
            }
            //			pHeader.
            pCtrl = new byte[nTotal + 10];
            pHeader.CopyTo(pCtrl, 0);
            pData.CopyTo(pCtrl, 10);
            return pCtrl;
        }
        private void OnLoginSuccess()
        {
            //if (isprimary)
            //{
            //    if (OnConnection != null)
            //    {
            //        OnConnection(this, true);
            //    }
                
            //    RequestSymBols();
                
            //}
            if (symbolReq == null)
            {
                if (isprimary)
                {
                    if (OnConnection != null)
                    {
                        OnConnection(this, true);
                    }

                    RequestSymBols();
                }
            }
            else
            {
                if (isprimary)
                {
                    if (OnConnection != null)
                    {
                        OnConnection(this, true);
                    }
                }
                RequestRTQuote();
            }
        }
        private void RequestSymBols()
        {
            //			ArrayList symbols=new ArrayList ();
            for (byte mkt = 0x00; mkt < 0x11; mkt++)//0x11��00�Ϻ���01���ڡ�02��ۡ�03���̡�04��㡢05���ƽ�06�¼��¡�07�ձ���08�������ǡ�09�׶ء�10ŦԼ������11ŦԼ��Դ��12֥�Ӹ硢13NYBOT��14������ֻ���15�����ֻ���16ȫ��ָ��
            {
                //if (mkt == 0x03) continue; //zzzzz
                byte[] pData = new byte[1];
                pData[0] = mkt;
                RequestCtrlData(ctrlclient, SymbolDefinition, pData);
                byte[] response = ReceiveCtrlData(ctrlclient);
                int pactype = BitConverter.ToInt32(response, 0);
                if (pactype == RequestFailure)
                {
                    Console.WriteLine("Invalid data request.");
                }
                else if (pactype == SymbolDefinition)
                {
                    int count2 = (response.Length - 11) / 32;
                    //					byte mkt=Data[10];
                    for (int i = 0; i < count2; i++)
                    {
                        string symbol = System.Text.Encoding.ASCII.GetString(response, 11 + i * 32 + 2, 6);
                        symbol = symbol.Replace('\0', ' ').Trim();
                        string name = Encoding.GetEncoding("gb2312").GetString(response, 11 + i * 32 + 9, 8);
                        short divisor = BitConverter.ToInt16(response, 11 + i * 32 + 18);
                        byte[] pobosymbol = new byte[3];
                        byte digits = response[11 + i * 32 + 26];
                        pobosymbol[0] = mkt;
                        pobosymbol[1] = response[11 + i * 32 + 28];
                        pobosymbol[2] = response[11 + i * 32 + 29];
                        //						symbols.Add ("Symbol "+symbol+" name "+name);
                        PoboSymbolDef pdef = new PoboSymbolDef();
                        pdef.pSymbol = symbol;
                        pdef.pName = name;
                        pdef.pDivisor = divisor;
                        pdef.pPriceDigits =digits;
                        pdef.pCode = pobosymbol;

                        //poboSymbols.Add(symbol, pdef);

                        if (OnInstrumentDef != null)
                        {
                            OnInstrumentDef(this, pdef);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("unknow data response.");
                }
            }
            PoboSymbolDef pdeflast= new PoboSymbolDef();//���һ������ֵ
            pdeflast.pSymbol = "PoboLast";
            if (OnInstrumentDef != null)
            {
                OnInstrumentDef(this, pdeflast);
            }
        }
        private void ResetAll()
        {
            if (rtdreceiver != null)
            {
                stoprcv = true;
                reconn = true;
            }
            //Thread.Sleep(100);
            ThreadPool.QueueUserWorkItem(ResetCtrl);

            //Thread closectrl = new Thread(new ThreadStart(ResetCtrl));
            //closectrl.Start();
            
            //
        }
        private void Reset(TcpClient client)
        {
            if (client != null)
            {
                try
                {
                    NetworkStream stream = client.GetStream();
                    if (stream != null)
                    {
                        stream.Close();
                    }

                }
                catch(Exception e)
                {
                    Console.WriteLine("Socket already closed");
                }
                finally
                {
                    Console.WriteLine("Data reception socket " + client.GetHashCode() + " closed");

                    client.Close();                   
                }
            }
            if (rtdreceiver != null)
            {
                rtdreceiver = null;
            }

            if (rtdreceiver == null && ctrlclient.Connected == false)
            {
                if (OnConnection != null)
                {
                    if (isprimary)
                    {
                        OnConnection(this, false);
                        Console.WriteLine(DateTime.Now + " Primary adapter closed.");
                    }
                    else
                    {
                        Console.WriteLine(DateTime.Now +" Secondary adapter closed.");
                    }
                    stoprcv = false;
                }
                if (reconn == true)
                {
                    reconn = false;
                    Console.WriteLine("Connection lost.");
                    Thread rc = new Thread(new ThreadStart(ReConnect));
                    rc.Start();
                }
            }

        }
        private void ResetCtrl(object state)
        {
            if (ctrlclient != null)
            {
                Thread.Sleep(100);
                Reset(ctrlclient);
                //SoundHelpers.PlaySound(strFileName, IntPtr.Zero, SoundHelpers.PlaySoundFlags.SND_FILENAME | SoundHelpers.PlaySoundFlags.SND_ASYNC);
            }
        }
        private void RequestMarketData(TcpClient client, int msgtype, byte[] command)
        {
            try
            {
                //				Monitor.Enter(this);
                NetworkStream stream = client.GetStream();
                if (stream.CanWrite)
                {
                    Byte[] pData = new Byte[command.Length + 10];
                    BitConverter.GetBytes(msgtype).CopyTo(pData, 0);
                    BitConverter.GetBytes((short)command.Length).CopyTo(pData, 6);
                    command.CopyTo(pData, 10);
                    stream.Write(pData, 0, pData.Length);
                    stream.Flush();

                    rtdreceiver.BeginInvoke(client, null, null);
                }
            }
            catch (SocketException se)
            {
                Console.WriteLine(se.Message);

                ResetAll();
            }
        }
        private void ReceiveData(TcpClient client)
        {
            int nRead = 0;
            int nTotal = 10;
            Byte[] pData = new Byte[10];
            Byte[] pHeader = null;
            DateTime lastrcvtime=DateTime.MinValue ;

            while (true)
            {
                try
                {
                    if (stoprcv)
                    {
                        //Console.WriteLine("logout now");

                        break;
                    }                    
                                       
                    NetworkStream stream = client.GetStream();         //					Monitor.TryEnter(stream);
                    if (stream.DataAvailable)
                    {
                        nRead += stream.Read(pData, nRead, nTotal - nRead);
                        if (pHeader == null && nRead == 10)
                        {
                            nRead = 0;
                            nTotal = BitConverter.ToInt16(pData, 6);
                            pHeader = pData;
                            pData = new Byte[nTotal];
                        }
                        if (pHeader != null && nRead == nTotal)
                        {
                            DataHandler procdata = new DataHandler(OnDataReceived);
                            lastrcvtime = DateTime.Now;
                            procdata.BeginInvoke(lastrcvtime, pHeader, pData, null, null);

                            nRead = 0;
                            nTotal = 10;
                            pData = new Byte[10];
                            pHeader = null;
                            stream.Flush();                            
                        }
                    }
                    else
                    {
                        if (lastrcvtime!=DateTime.MinValue &&DateTime.Now.CompareTo(lastrcvtime.AddMinutes(1)) > 0)
                        {
                            Console.WriteLine("market data rcv stopped at "+lastrcvtime);
                            lastrcvtime = DateTime.MinValue;
                            ResetAll();
                            //break;
                        }
                       
                    }
                    Thread.Sleep(5);//					Monitor.Exit(stream);
                }
                catch (SocketException se)
                {
                    Console.WriteLine("data link error");
                    ResetAll();
                    //break;
                }
            }

            Reset(client);
        }
        private void OnDataReceived(DateTime Timestamp, byte[] Header, byte[] Data)
        {
            int pactype = BitConverter.ToInt32(Header, 0);
            if (pactype == NewQuote)
            {
                int count1 = Data.Length / 124;
                if (count1 > 0)
                {
                    //string quote = string.Empty;
                    for (int i = 0; i < count1; i++)
                    {
                        string symbol = System.Text.Encoding.ASCII.GetString(Data, i * 124 + 116, 6);
                        symbol = symbol.Replace('\0', ' ').Trim();

                        if (symbol != string .Empty )
                        {
                            if (OnRawQuote != null)
                            {
                                OnRawQuote(this, symbol,Data);
                            }
                            if (OnQuote != null)
                            {
                                PoboQuote quote = new PoboQuote();
                                quote.TimeStamp = Timestamp;
                                quote.Symbol = symbol;
                                quote.PrvClose = BitConverter.ToInt32(Data, i * 124 + 4);
                                quote.Open = BitConverter.ToInt32(Data, i * 124 + 8);
                                quote.High = BitConverter.ToInt32(Data, i * 124 + 12);
                                quote.Low = BitConverter.ToInt32(Data, i * 124 + 16);
                                quote.Last = BitConverter.ToInt32(Data, i * 124 + 20);
                                quote.Volume = BitConverter.ToSingle(Data, i * 124 + 24);
                                quote.OpInt = BitConverter.ToSingle(Data, i * 124 + 28);
                                quote.Size = BitConverter.ToSingle(Data, i * 124 + 32);
                                quote.Bid1 = BitConverter.ToInt32(Data, i * 124 + 36);
                                quote.Bidsize1 = BitConverter.ToSingle(Data, i * 124 + 40);
                                quote.Ask1 = BitConverter.ToInt32(Data, i * 124 + 76);
                                quote.Asksize1 = BitConverter.ToSingle(Data, i * 124 + 80);

                                if (symbol.StartsWith("IF"))
                                {
                                    quote.Bid2 = BitConverter.ToInt32(Data, i * 124 + 44);
                                    quote.Bidsize2 = BitConverter.ToSingle(Data, i * 124 + 48);
                                    quote.Bid3 = BitConverter.ToInt32(Data, i * 124 + 52);
                                    quote.Bidsize3 = BitConverter.ToSingle(Data, i * 124 + 56);
                                    quote.Bid4 = BitConverter.ToInt32(Data, i * 124 + 60);
                                    quote.Bidsize4 = BitConverter.ToSingle(Data, i * 124 + 64);
                                    quote.Bid5 = BitConverter.ToInt32(Data, i * 124 + 68);
                                    quote.Bidsize5 = BitConverter.ToSingle(Data, i * 124 + 72);


                                    quote.Ask2 = BitConverter.ToInt32(Data, 84);
                                    quote.Asksize2 = BitConverter.ToSingle(Data, 88);
                                    quote.Ask3 = BitConverter.ToInt32(Data, 92);
                                    quote.Asksize3 = BitConverter.ToSingle(Data, 96);
                                    quote.Ask4 = BitConverter.ToInt32(Data, 100);
                                    quote.Asksize4 = BitConverter.ToSingle(Data, 104);
                                    quote.Ask5 = BitConverter.ToInt32(Data, 108);
                                    quote.Asksize5 = BitConverter.ToSingle(Data, 112);
                                }
                                OnQuote(this, quote);
                            }

                            //quote = string.Concat(quote, Timestamp + " " + symbol + " " + last + " " + bid1 + " " + volume);
                        }

                    }
                    //if (quote != string.Empty)
                    //{
                    //    info = quote;
                    //    MethodInvoker miv = new MethodInvoker(UpdateQuote);
                    //    this.BeginInvoke(miv);
                    //}
                }
            }		
        }
        private void LogoutNow()
        {
            symbolReq = null;
            reconn = false;
            stoprcv = true;
            //Thread.Sleep(100);
            //Reset(ctrlclient);   
            ThreadPool.QueueUserWorkItem(ResetCtrl);
            //Thread closectrl = new Thread(new ThreadStart(ResetCtrl));
            //closectrl.Start();

        }
        private void ReConnect()
        {
            Console.WriteLine("Try to reconnect in 5 seconds.");
            Thread.Sleep(5000);
            LoginNow();
        }

        private delegate void DataReceiver(TcpClient client);
        private delegate void DataHandler(DateTime Time, byte[] Header, byte[] Data);
        //private enum PoboDataType
        //{
        //    Ctrl,Market
        //}


    }
    public class PoboAccountItem:IComparable 
    {
        string poboserver;
        int loginport;
        int dataport;
        string username;
        string password;
        //bool isprimary; 
        //private const string CATEGORY_PROPERTIES = "Properties";

        //[Category("Properties")]
        //[DefaultValue("222.73.0.178")]
        public string Server
        {
            get
            {
                return poboserver;
            }
            set
            {
                poboserver = value;
            }
        }
        //[Category("Properties")]
        //[DefaultValue(6666)]
        public int LoginPort
        {
            get
            {
                return loginport;
            }
            set
            {
                loginport = value;
            }
        }
        //[Category("Properties")]
        //[DefaultValue(6668)]
        public int DataPort
        {
            get
            {
                return dataport;
            }
            set
            {
                dataport = value;
            }
        }
        //[Category("Properties")]
        //[DefaultValue("1111")]
        public string Username
        {
            get
            {
                return username;
            }
            set
            {
                username = value;
            }
        }
        //[Category("Properties")]
        //[DefaultValue("1111")]
        public string Password
        {
            get
            {
                return password;
            }
            set
            {
                password = value;
            }
        }

        public PoboAccountItem(string svr,int lport,int dport,string user,string pwd)
        {
            poboserver = svr;
            loginport = lport;
            dataport = dport;
            username = user;
            password = pwd;
            //isprimary = primary;
        }
        public PoboAccountItem()
            : this("61.144.235.20", 13152, 13153, "1111", "1111") //this("211.154.43.243", 6666, 6668, "gelin", "gelin")
        {
        }
        public override string ToString()
        {
            return poboserver;
        }

        #region IComparable Members

        public int CompareTo(object obj)
        {
            if (!(obj is PoboAccountItem))
            {
                throw new Exception("The method or operation is not implemented.");
            }
            //return 0;
            return this.poboserver.CompareTo((obj as PoboAccountItem).poboserver);

        }

        #endregion
    }
    public class PoboAccountListEditor: CollectionEditor
    {
        private CollectionEditor.CollectionForm form;
        static EventHandler ListChanged;

        //public static event EventHandler ListChanged;
        public PoboAccountListEditor(): base(typeof(List<PoboAccountItem>))
        {
        }
        protected override CollectionEditor.CollectionForm CreateCollectionForm()
        {
            this.form = base.CreateCollectionForm();
            this.form.FormClosed +=new FormClosedEventHandler(form_FormClosed);
            return this.form;

        }
        private void form_FormClosed(object sender, FormClosedEventArgs e)
        {
            if ((this.form.DialogResult == DialogResult.OK) && (PoboAccountListEditor.ListChanged != null))
            {
                PoboAccountListEditor.ListChanged(this, EventArgs.Empty);
            }
        }
    }
    [Editor(typeof(PoboAccountListEditor), typeof(UITypeEditor))]
    public class PoboAccountItemList : IList, ICollection, IEnumerable 
    {
        private ArrayList items;

        #region IList Members

        int IList.Add(object value)
        {
            return this.Add(value as PoboAccountItem);
        }

        public int Add(PoboAccountItem item)
        {
            this.items.Add(item);
            this.items.Sort();
            return this.items.IndexOf(item);
        }

        public int Add(string svr, int lport, int dport, string user, string pwd)
        {
            return this.Add(new PoboAccountItem(svr, lport, dport, user, pwd));
        }

        public void Clear()
        {
            this.items.Clear();
        }

        public bool Contains(object value)
        {
            return this.items.Contains(value);
        }

        public int IndexOf(object value)
        {
            return this.items.IndexOf(value);
        }

        public void Insert(int index, object value)
        {
            this.items.Insert(index, value);
        }

        public bool IsFixedSize
        {
            get
            {
                return this.items.IsFixedSize;
            }
        }

        public bool IsReadOnly
        {
            get
            {
                return this.items.IsReadOnly;
            }
        }

        public void Remove(object value)
        {
            this.items.Remove(value);
        }

        public void RemoveAt(int index)
        {
            this.items.RemoveAt(index);
        }

        public PoboAccountItem this[int index]
        {
            get
            {
                return (this.items[index] as PoboAccountItem);
            }
        }
        object IList.this[int index]
        {
            get
            {
                return this[index];
            }
            set
            {
                throw new NotSupportedException();
            }
        }


        #endregion

        #region ICollection Members

        public void CopyTo(Array array, int index)
        {
            this.items.CopyTo(array, index);
        }

        public int Count
        {
            get
            {
                return this.items.Count;
            }
        }

        public bool IsSynchronized
        {
            get
            {
                return this.items.IsSynchronized;
            }
        }

        public object SyncRoot
        {
            get
            {
                return this.items.SyncRoot;
            }
        }

        #endregion

        #region IEnumerable Members

        public IEnumerator GetEnumerator()
        {
            return this.items.GetEnumerator();
        }

        #endregion

        public PoboAccountItemList()
        {
            this.items = new ArrayList();
        }
        
    }
    internal class SoundHelpers
    {
        [Flags]
        public enum PlaySoundFlags : int
        {
            SND_SYNC = 0x0000,  /* play synchronously (default) */
            SND_ASYNC = 0x0001,  /* play asynchronously */
            SND_NODEFAULT = 0x0002,  /* silence (!default) if sound not found */
            SND_MEMORY = 0x0004,  /* pszSound points to a memory file */
            SND_LOOP = 0x0008,  /* loop the sound until next sndPlaySound */
            SND_NOSTOP = 0x0010,  /* don't stop any currently playing sound */
            SND_NOWAIT = 0x00002000, /* don't wait if the driver is busy */
            SND_ALIAS = 0x00010000, /* name is a registry alias */
            SND_ALIAS_ID = 0x00110000, /* alias is a predefined ID */
            SND_FILENAME = 0x00020000, /* name is file name */
            SND_RESOURCE = 0x00040004  /* name is resource name or atom */
        }

        [DllImport("core.dll")]
        public static extern bool PlaySound(string szSound, IntPtr hMod, PlaySoundFlags flags);
    }


    public struct PoboSymbolDef
    {
        public string pSymbol;
        public string pName;
        public short pDivisor;
        public byte pPriceDigits;
        public byte[] pCode;
    }
    public struct PoboQuote
    {
        public string Symbol;
        public DateTime TimeStamp;
        public int PrvClose;
        public int Open;
        public int High;
        public int Low;
        public int Last;
        public float   Volume;
        public float OpInt;
        public float Size;
        public int Bid1;
        public float Bidsize1;
        public int Bid2;
        public float Bidsize2;
        public int Bid3;
        public float Bidsize3;
        public int Bid4;
        public float Bidsize4;
        public int Bid5;
        public float Bidsize5;
        public int Ask1;
        public float Asksize1;
        public int Ask2;
        public float Asksize2;
        public int Ask3;
        public float Asksize3;
        public int Ask4;
        public float Asksize4;
        public int Ask5;
        public float Asksize5;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct PoboQuote2
    {
        public int Mkt;
        public int PrvClose;
        public int Open;
        public int High;
        public int Low;
        public int Last;
        public float Volume;
        public float OpInt;
        public float Size;
        public int Bid1;
        public float Bidsize1;
        public int Bid2;
        public float Bidsize2;
        public int Bid3;
        public float Bidsize3;
        public int Bid4;
        public float Bidsize4;
        public int Bid5;
        public float Bidsize5;
        public int Ask1;
        public float Asksize1;
        public int Ask2;
        public float Asksize2;
        public int Ask3;
        public float Asksize3;
        public int Ask4;
        public float Asksize4;
        public int Ask5;
        public float Asksize5;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 8)]
        public string Symbol;
    }

    public delegate void PoboConnectionEventHandler(PoboAdapter sender, bool isconnected);
    public delegate void PoboQuoteEventHandler(PoboAdapter sender, PoboQuote quote);
    public delegate void PoboRawQuoteEventHandler(PoboAdapter sender, string symbol,byte[] qbuffer); 
    public delegate void PoboInstrumentDefEventHandler(PoboAdapter sender, PoboSymbolDef symboldef);   

}
