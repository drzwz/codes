﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Threading;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Drawing.Design;
using SmartQuant;
using SmartQuant.Data;
using SmartQuant.Series;
using SmartQuant.Providers;
using SmartQuant.Instruments;

namespace Drzwz
{
    public class SQ2TXT : IProvider, IHistoryProvider
    {

        public SQ2TXT()
        {
            ProviderManager.Add(this);
        }
        #region 导出数据
        private string symbolRegex = @"(000001\.SZ)";
        private bool autoExport = true;
        [Category("设置"), Description("要导出数据的代码的正则表达式。"), DefaultValue("")]
        public string SymbolRegex
        {
            get { return this.symbolRegex; }
            set
            {
                this.symbolRegex = value.Trim();
            }
        }
        [Category("设置"), Description("true-连接后立即导出；false-连接后不导出，若运行中，则中断操作。"), DefaultValue(true)]
        public bool AutoExport
        {
            get { return this.autoExport; }
            set
            {
                this.autoExport = value;
            }
        }

        private string symbolFile = @"D:\FinData\TXT\Symbol.TXT";
        [Category("设置"), Description("Symbol文件。若为空则不导出。"),
        Editor(typeof(System.Windows.Forms.Design.FileNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string File_Symbol
        {
            get { return this.symbolFile; }
            set
            {
                this.symbolFile = value.Trim();
            }
        }
        private string dailyFile = @"D:\FinData\TXT\Daily.TXT";
        [Category("设置"), Description("Daily文件。若为空则不导出。"),
        Editor(typeof(System.Windows.Forms.Design.FileNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string File_Daily
        {
            get { return this.dailyFile; }
            set
            {
                this.dailyFile = value.Trim();
            }
        }
        private DateTime startDate = new DateTime(DateTime.Now.Year,1,1);
        [Category("设置"), Description("开始日期")]
        public DateTime Date_Start
        {
            get { return this.startDate; }
            set
            {
                this.startDate = value;
            }
        }
        private DateTime endDate = DateTime.Now.Date;
        [Category("设置"), Description("结束日期")]
        public DateTime Date_End
        {
            get { return this.endDate; }
            set
            {
                this.endDate = value;
            }
        }
        private void doWork()
        {
            try
            {
                
                StringBuilder sb = new StringBuilder(); sb.AppendLine();
                Console.WriteLine("{0} 开始导出数据...", DateTime.Now);
                int num = 0;
                string symbol;
                StreamWriter symbolsw=null,dailysw=null;
                bool symbolWrite = false,dailyWrite=false;
                if (this.symbolFile != "")
                {
                    symbolWrite = true;
                    symbolsw = new StreamWriter(this.symbolFile, false);
                    symbolsw.WriteLine("dm,jc");
                }
                
                if (this.dailyFile != "")
                {
                    dailyWrite = true;
                    dailysw = new StreamWriter(this.dailyFile, false);
                    dailysw.WriteLine("dm,rq,kp,zg,zd,so,sl,cc");
                }
                foreach(Instrument inst in InstrumentManager.Instruments) //
                {
                    Application.DoEvents();
                    if (!this.autoExport)
                    {
                        Console.WriteLine("{0} 处理了{1}个代码后，用户中断操作(AutoImport被设为False)。", DateTime.Now, num);
                        break;
                    }
                    symbol = inst.Symbol;
                    //Console.WriteLine("{0} 正在读取{1}...", DateTime.Now, symbol);

                    //如果与SymbolRegex不匹配，则不导入，文件指针往后移动recordCounts*32个字节
                    if (!Regex.IsMatch(symbol, this.symbolRegex))
                    {
                        //Console.WriteLine("{0} {1}与SymbolRegex不匹配。不导入。", DateTime.Now, symbol);
                        continue;
                    }
                    sb.Append( symbol+" ");
                    num++;
                    if (num % 10 == 0) sb.AppendLine();
                    //导出数据
                    if (symbolWrite)
                    {
                        symbolsw.WriteLine(symbol+","+inst.SecurityDesc);

                    }
                    if (dailyWrite)
                    {
                        foreach (Daily d in inst.GetDailySeries(startDate,endDate))
                        {
                            dailysw.Write(symbol + ",");
                            dailysw.Write(d.DateTime.ToString("yyyy-MM-dd")+ ",");
                            dailysw.Write(d.Open.ToString("F2") + ",");
                            dailysw.Write(d.High.ToString("F2") + ",");
                            dailysw.Write(d.Low.ToString("F2") + ",");
                            dailysw.Write(d.Close.ToString("F2") + ",");
                            dailysw.Write(d.Volume.ToString() + ",");
                            dailysw.WriteLine(d.OpenInt.ToString() );
                        }
                    }


                    
                }
                if (this.symbolFile != "")     symbolsw.Close();
                if (this.dailyFile != "")     dailysw.Close();
                Console.WriteLine("{0} 导出完成。\n {2}", DateTime.Now,num,sb.ToString());
                this.Disconnect();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        #endregion

        #region IProvider 成员
        private bool isConnected = false;

        public void Connect(int timeout)
        {
            this.Connect();
            ProviderManager.WaitConnected(this, timeout);
        }
        public void Connect()
        {
            isConnected = true;
            Console.WriteLine("{0} Connected!",DateTime.Now);
            if (Connected != null)
                Connected(this, new EventArgs());
            this.doWork();
            //Thread th = new Thread(new ThreadStart(this.doWork));
            //th.Start();
        }
        public event EventHandler Connected;
        public void Disconnect()
        {
            try
            {
                Console.WriteLine("{0} Disconnected!",DateTime.Now);
                isConnected = false;
                if (Disconnected != null)
                    Disconnected(this, new EventArgs());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Disconnect：" + ex.Message);
            }

        }

        public event EventHandler Disconnected;

        public event ProviderErrorEventHandler Error;
        [Category("信息")]
        public byte Id
        {
            get { return 113; }
        }
        [Category("信息")]
        public bool IsConnected
        {
            get { return isConnected; }
        }
        [Category("信息")]
        public string Name
        {
            get { return "SQ2TXT"; }
        }
        [Category("信息")]
        public string Title
        {
            get { return "SQ2TXT 将数据导出为TXT格式。"; }
        }
        [Category("信息")]
        public string URL
        {
            get { return String.Empty; }
        }
        public void Shutdown()
        {
            
        }
        [Category("信息")]
        public ProviderStatus Status
        {
            get
            {
                if (!IsConnected)
                    return ProviderStatus.Disconnected;
                else
                    return ProviderStatus.Connected;
            }
        }

        public event EventHandler StatusChanged;

        #endregion

        #region IHistoryProvider 成员
        [Category("信息")]
        public bool BarSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool DailySupported
        {
            get { return false; }
        }

        public Bar[] GetBarHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, int barSize)
        {
            throw new NotImplementedException();
        }

        public Daily[] GetDailyHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, bool dividendAndSplitAdjusted)
        {
            throw new NotImplementedException();
        }

        public Quote[] GetQuoteHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }

        public Trade[] GetTradeHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }
        [Category("信息")]
        public bool QuoteSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool TradeSupported
        {
            get { return false; }
        }

        #endregion
    }
}
