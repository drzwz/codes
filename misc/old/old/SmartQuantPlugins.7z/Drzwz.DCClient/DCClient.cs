﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Runtime.Serialization;
using SmartQuant.Data;
using Drzwz.DC.DCService;
namespace Drzwz.DC
{
    public class DCClient
    {
        DCServiceClient dcClient = null;
        public DCClient()
        {
            this.Init();
        }
        public void Init()
        {
            NetNamedPipeBinding binding = new NetNamedPipeBinding(NetNamedPipeSecurityMode.None);
            binding.MaxReceivedMessageSize = 6553600;
            EndpointAddress epAddress = new EndpointAddress(@"net.pipe://localhost/DC/DCService");
            dcClient = new DCServiceClient(binding, epAddress);
        }
        public List<string> GetSymbolList(string symbol, string securityType, string securityExchange)
        {
            if (dcClient == null) this.Init();
            dcClient.Endpoint.Contract.Operations.Find("GetSymbolList").Behaviors.Find<DataContractSerializerOperationBehavior>().MaxItemsInObjectGraph = 6553600;
            List<string> list = dcClient.GetSymbolList(symbol, securityType, securityExchange);
            return list;
        }
        public SortedList<string, string> GetSecurityNameList(string symbol, string securityType, string securityExchange)
        {
            if (dcClient == null) this.Init();
            dcClient.Endpoint.Contract.Operations.Find("GetSecurityNameList").Behaviors.Find<DataContractSerializerOperationBehavior>().MaxItemsInObjectGraph = 6553600;
            SortedList<string, string> list = dcClient.GetSecurityNameList(symbol, securityType, securityExchange);
            //MessageBox.Show("I 'm from getdata()");
            return list;
        }
        public SortedList<string, string> GetSecurityTypeList(string symbol, string securityType, string securityExchange)
        {
            if (dcClient == null) this.Init();
            dcClient.Endpoint.Contract.Operations.Find("GetSecurityTypeList").Behaviors.Find<DataContractSerializerOperationBehavior>().MaxItemsInObjectGraph = 6553600;
            SortedList<string, string> list = dcClient.GetSecurityTypeList(symbol, securityType, securityExchange);
            //MessageBox.Show("I 'm from getdata()");
            return list;
        }        
        public SortedList<DateTime, double> GetPriceFactorList(string symbol)  
        {
            if (dcClient == null) this.Init();
            dcClient.Endpoint.Contract.Operations.Find("GetPriceFactorList").Behaviors.Find<DataContractSerializerOperationBehavior>().MaxItemsInObjectGraph = 6553600;
            SortedList<DateTime, double> list = dcClient.GetPriceFactorList(symbol);
            return list;
        }        
        public List<SmartQuant.Data.Daily> GetDailyAdjList(string symbol, DateTime datetime1, DateTime datetime2) 
        {
            if (dcClient == null) this.Init();
            dcClient.Endpoint.Contract.Operations.Find("GetDailyAdjList").Behaviors.Find<DataContractSerializerOperationBehavior>().MaxItemsInObjectGraph = 6553600;
            List<Daily> list = dcClient.GetDailyAdjList(symbol, datetime1, datetime2);
            return list;
        }
        public List<SmartQuant.Data.Daily> GetDailyList(string symbol, DateTime datetime1, DateTime datetime2)
        {
            if (dcClient == null) this.Init();
            dcClient.Endpoint.Contract.Operations.Find("GetDailyList").Behaviors.Find<DataContractSerializerOperationBehavior>().MaxItemsInObjectGraph = 6553600;
            List<Daily> list = dcClient.GetDailyList(symbol, datetime1, datetime2);
            return list;
        }
        public List<SmartQuant.Data.Bar> GetBarList(string symbol, DateTime datetime1, DateTime datetime2, int barSize)
        {
            if (dcClient == null) this.Init();
            dcClient.Endpoint.Contract.Operations.Find("GetBarList").Behaviors.Find<DataContractSerializerOperationBehavior>().MaxItemsInObjectGraph = 6553600;
            List<Bar> list = dcClient.GetBarList(symbol, datetime1, datetime2, barSize);
            return list;
        }
        public List<SmartQuant.Data.Quote> GetQuoteList(string symbol, DateTime datetime1, DateTime datetime2)
        {
            if (dcClient == null) this.Init();
            dcClient.Endpoint.Contract.Operations.Find("GetQuoteList").Behaviors.Find<DataContractSerializerOperationBehavior>().MaxItemsInObjectGraph = 6553600;
            List<Quote> list = dcClient.GetQuoteList(symbol, datetime1, datetime2);
            return list;
        }
        public List<SmartQuant.Data.Trade> GetTradeList(string symbol, DateTime datetime1, DateTime datetime2)
        {
            if (dcClient == null) this.Init();
            dcClient.Endpoint.Contract.Operations.Find("GetTradeList").Behaviors.Find<DataContractSerializerOperationBehavior>().MaxItemsInObjectGraph = 6553600;
            List<Trade> list = dcClient.GetTradeList(symbol, datetime1, datetime2);
            return list;
        }
        public List<object> GetSecurityDefinitionList(string symbol, string securityType, string securityExchange)
        {
            if (dcClient == null) this.Init();
            dcClient.Endpoint.Contract.Operations.Find("GetSecurityDefinitionList").Behaviors.Find<DataContractSerializerOperationBehavior>().MaxItemsInObjectGraph = 6553600;
            List<object> list = dcClient.GetSecurityDefinitionList(symbol, securityType, securityExchange);
            return list;
        } 
        public void Close()
        {
            if(dcClient!=null) dcClient.Close();
        }
    }
}
