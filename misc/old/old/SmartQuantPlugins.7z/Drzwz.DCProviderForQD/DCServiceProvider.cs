namespace Drzwz.DCProviderForQD
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;
    using SmartQuant.FIX;
    using SmartQuant.Data;
    using SmartQuant.Providers;
    using Drzwz.DC;
    
    public class DCServiceProvider : IHistoryProvider, IInstrumentProvider, IProvider
    {
        private const string CATEGORY_DATA = "Data";
        private const string CATEGORY_INFO = "Information";
        private const string CATEGORY_SETTINGS = "Settings";
        private const string CATEGORY_STATUS = "Status";
        //private IDataCenterConnection connection = null;
        //private const string DEFAULT_HOST = "localhost";
        //private const int DEFAULT_PORT = 0xbc0;
        //private string host = "localhost";
        //private int port = 3009;
        private const byte PROVIDER_ID = 0xdc;
        private const string PROVIDER_NAME = "DCService";
        private const string PROVIDER_TITLE = "DCServiceProvider";
        private const string PROVIDER_URL = "drzwz.com";

        public event EventHandler Connected;
        public event EventHandler Disconnected;
        public event ProviderErrorEventHandler Error;
        public event SecurityDefinitionEventHandler SecurityDefinition;
        public event EventHandler StatusChanged;

        private DCClient connection = null;

        public DCServiceProvider()
        {
            ProviderManager.Add(this);
        }
        
        public void Connect()
        {
            lock (this)
            {
                if (this.connection == null)
                {
                    try
                    {
                        this.connection = new DCClient();
                        if (this.Connected != null)
                        {
                            this.Connected(this, EventArgs.Empty);
                        }
                    }
                    catch (Exception exception)
                    {
                        this.connection = null;
                        this.EmitError(exception.ToString());
                    }
                }
            }
        }

        public void Connect(int timeout)
        {
            lock (this)
            {
                this.Connect();
                ProviderManager.WaitConnected(this, timeout);
            }
        }

        public void Disconnect()
        {
            lock (this)
            {
                if (this.connection != null)
                {
                    try
                    {
                        this.connection.Close();
                    }
                    catch (Exception exception)
                    {
                        this.EmitError(exception.ToString());
                    }
                    finally
                    {
                        this.connection = null;
                        if (this.Disconnected != null)
                        {
                            this.Disconnected(this, EventArgs.Empty);
                        }
                    }
                }
            }
        }

        private void EmitError(string message)
        {
            if (this.Error != null)
            {
                this.Error(new ProviderErrorEventArgs(this, -1, -1, message));
            }
        }

        public Bar[] GetBarHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, int barSize)
        {
            lock (this)
            {
                if (this.connection == null)
                {
                    this.EmitError("Not connected.");
                    return null;
                }
                List<Bar> list = this.connection.GetBarList(instrument.Symbol, datetime1, datetime2, barSize);
                return (list.ToArray());
            }
        }

        public Daily[] GetDailyHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, bool dividendAndSplitAdjusted)
        {
            lock (this)
            {
                if (this.connection == null)
                {
                    this.EmitError("Not connected.");
                    return null;
                }
                if (dividendAndSplitAdjusted)
                {
                    List<Daily> lst = this.connection.GetDailyAdjList(instrument.Symbol, datetime1, datetime2);
                    return (lst.ToArray());
                }
                else
                {
                    List<Daily> list = this.connection.GetDailyList(instrument.Symbol, datetime1, datetime2);
                    return (list.ToArray());
                }
            }
        }
        public Daily[] GetDailyAdjHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            lock (this)
            {
                if (this.connection == null)
                {
                    this.EmitError("Not connected.");
                    return null;
                }

                List<Daily> list = this.connection.GetDailyAdjList(instrument.Symbol, datetime1, datetime2);
                return (list.ToArray());
            }
        }
        public Quote[] GetQuoteHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            lock (this)
            {
                if (this.connection == null)
                {
                    this.EmitError("Not connected.");
                    return null;
                }
                List<Quote> list = this.connection.GetQuoteList(instrument.Symbol, datetime1, datetime2);
                return (list.ToArray());
            }
        }

        public Trade[] GetTradeHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            lock (this)
            {
                if (this.connection == null)
                {
                    this.EmitError("Not connected.");
                    return null;
                }
                List<Trade> list = this.connection.GetTradeList(instrument.Symbol, datetime1, datetime2);
                return (list.ToArray());
            }
        }

        public void SendSecurityDefinitionRequest(FIXSecurityDefinitionRequest request)
        {
            lock (this)
            {
                if (this.connection == null)
                {
                    this.EmitError("Not connected.");
                }
                else
                {
                    string symbol = request.ContainsField(0x37) ? request.Symbol : null;
                    string securityType = request.ContainsField(0xa7) ? request.SecurityType : null;
                    string securityExchange = request.ContainsField(0xcf) ? request.SecurityExchange : null;
                    List<object> list = this.connection.GetSecurityDefinitionList(symbol, securityType, securityExchange);
                    foreach (System.Collections.Hashtable hashtable in list)
                    {
                        FIXSecurityDefinition definition = new FIXSecurityDefinition();
                        definition.SecurityReqID = request.SecurityReqID;
                        definition.SecurityResponseID = request.SecurityReqID;
                        definition.SecurityResponseType = request.SecurityRequestType;
                        definition.TotNoRelatedSym = list.Count;
                        foreach (System.Collections.DictionaryEntry entry in hashtable)
                        {
                            int key = (int) entry.Key;
                            string str4 = (string) entry.Value;
                            definition.AddField(FIXField.Field(EFIXFieldTypes.GetFIXType(key), key, str4, true));
                        }
                        if (this.SecurityDefinition != null)
                        {
                            this.SecurityDefinition(this, new SecurityDefinitionEventArgs(definition));
                        }
                    }
                }
            }
        }

        public void Shutdown()
        {
            this.Disconnect();
        }

        public override string ToString()
        {
            return this.Name;
        }

        [Category("Data")]
        public bool BarSupported
        {
            get
            {
                return true;
            }
        }

        [Category("Data")]
        public bool DailySupported
        {
            get
            {
                return true;
            }
        }

        //[DefaultValue("localhost"), Category("Settings")]
        //public string Host
        //{
        //    get
        //    {
        //        return this.host;
        //    }
        //    set
        //    {
        //        this.host = value;
        //    }
        //}

        [Category("Information")]
        public byte Id
        {
            get
            {
                return 0xdc;
            }
        }

        [Category("Status")]
        public bool IsConnected
        {
            get
            {
                return (this.connection != null);
            }
        }

        [Category("Information")]
        public string Name
        {
            get
            {
                return "DCService";
            }
        }

        //[Category("Settings"), DefaultValue(0xbc0)]
        //public int Port
        //{
        //    get
        //    {
        //        return this.port;
        //    }
        //    set
        //    {
        //        this.port = value;
        //    }
        //}

        [Category("Data")]
        public bool QuoteSupported
        {
            get
            {
                return true;
            }
        }

        [Category("Status")]
        public ProviderStatus Status
        {
            get
            {
                return ProviderStatus.Unknown;
            }
        }

        [Category("Information")]
        public string Title
        {
            get
            {
                return "DCService Adapter";
            }
        }

        [Category("Data")]
        public bool TradeSupported
        {
            get
            {
                return true;
            }
        }

        [Category("Information")]
        public string URL
        {
            get
            {
                return "";
            }
        }
    }
}

