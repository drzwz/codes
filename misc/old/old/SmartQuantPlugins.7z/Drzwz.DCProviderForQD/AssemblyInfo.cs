using System.Reflection;
using System.Runtime.InteropServices;
// Assembly Drzwz.DCProviderForQD, Version 1.0.2494.25396

[assembly: System.Reflection.AssemblyVersion("1.0.2494.25396")]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Reflection.AssemblyTitle("Drzwz.DCProviderForQD.ServiceProvider")]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Reflection.AssemblyKeyName("")]
[assembly: System.Reflection.AssemblyKeyFile("")]
[assembly: System.Reflection.AssemblyDelaySign(false)]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Reflection.AssemblyCopyright("")]
[assembly: System.Reflection.AssemblyProduct("")]
[assembly: System.Reflection.AssemblyCompany("")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyDescription("")]

[assembly: AssemblyFileVersionAttribute("1.0")]
[assembly: ComVisibleAttribute(false)]
