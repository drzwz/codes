using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.Threading;
using System.Reflection.Emit;
using System.Reflection;
using System.IO;
using SmartQuant.FIX;
using SmartQuant.Providers;
using SmartQuant.Instruments;
using SmartQuant.Data;
using SmartQuant.File;
//using AuxData;
namespace Drzwz.SCProviderForDC
{
    public class SCRTcontrol : UserControl
    {
        private const uint SHMKT = 18515;
        private const uint SZMKT = 23123;

        public event SC_NOWDATAEventHandler OnQuote;
        public event SC_PANKOU_EventHandler OnSC_PANKOU;//��tick;
        public event SC_KLINE_5MinOrDay_EventHandler OnSC_KLINE;
        public event SC_Symbols_EventHandler OnSC_Symbol;

        static int m_lASkIndex = 1;

        public SCRTcontrol()
        {
            InitializeComponent();
        }
        #region �����������ɵĴ���

        /// <summary> 
        /// �����֧������ķ��� - ��Ҫ
        /// ʹ�ô���༭���޸Ĵ˷��������ݡ�
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // SCRTcontrol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "SCRTcontrol";
            this.Size = new System.Drawing.Size(94, 58);
            this.ResumeLayout(false);

        }

        #endregion

        #region ������������
        private const int WM_USER = 0x0400 + 101;
        internal delegate bool LoadDll([MarshalAs(UnmanagedType.AsAny)] Object o, int nSize);
        internal delegate void AskData([MarshalAs(UnmanagedType.AsAny)] Object o, int nSize);
        internal delegate bool SCGetInfoEx([MarshalAs(UnmanagedType.AsAny)] Object o, [MarshalAs(UnmanagedType.AsAny)] Object o1);
        internal delegate void UnLoadDll();
        [DllImport("kernel32.dll")]
        internal static extern IntPtr LoadLibrary(String dllname);
        [DllImport("kernel32.dll")]
        internal static extern IntPtr GetProcAddress(IntPtr hModule, String procname);


        private IntPtr libraryHandle;
        public CodeTable SC_CODETABLE = new CodeTable();
        private SCMarket MKTDATA;
        #endregion
        #region ��������ṹ����


        // �����ӿ�

        // �������ڣ�20060228
        // �������ݣ�
        // 1. tagSCPankou�����ʱ���Ϊuint���͡�
        //    SC_PankouReply����ĸ���short m_nCount��Ϊlong m_lCount
        // 2. SC_KLineAsk��SC_KLineReply��������
        // 3. �����г����壬���塢��㡢�ڻ���̨���г���ʹ��SCMarket���ص�m_wMarketֵ���ɡ�
        // 4. �󲿷��������͵ĵ�#defineֵ�и��ģ����±��뼴��
        // 5. SC_Downdload�е�m_nCount��Ϊm_lCount�����͸�Ϊlong. 
        //    �ṹ���ƴ�'SC_Downdload'��Ϊ'SC_Download'
        // 6. SH_MARKET_EX��SZ_MARKET_EX�ȵĶ�����ɾ����ֱ����SCMarket�����m_wMarket���ɡ�
        // 7. ��ʼ����������ΪSCInit
        // 8. ʾ�����������ϸ����ο����ǵ����ӣ�SCDemo


        private const int SC_INIT = 0x2001;	// SCInit����

        private const int SC_CLEAR_PREVREQ = 0x2101;	// ����ǰ����������󣬽����ڷ����󣨻��������֮ǰ����
        private const int SC_MARKET = 0x2131;	// ����ָ���г�����Ϣ�����������б仯�ͻ��Զ�����

        private const int SC_NOWDATA = 0x2201;

        private const int SC_PANKOU = 0x2301;	// �����̿����ݣ���Ӧ��uint m_time������ʹ�������

        private const int SC_IMTYPELIST = 0x2401;	// ������Ϣ������Ϣ�����
        private const int SC_IMTITLE = 0x2402;	// ������Ϣ���ױ����б�
        private const int SC_IMCONTENT = 0x2403;	// ������Ϣ��������(f10, ���������桢ʵʱ����ʷ�ĸ�����Ϣ��)

        private const int SC_KLINE = 0x2501;	// ����K�����ݣ����ߣ�

        private const int SC_CQ = 0x2601;	// �����Ȩ����

        private const int SC_DL_KLINE = 0x2701;	// K����������
        private const int SC_DL_CQ = 0x2702;	// ��Ȩ��������
        private const int SC_DL_XX = 0x2703;	// ��Ϣ���أ���F10�����������桢���ŵ�
        private const int SC_DL_TRACE = 0x2704;	// ��ϸ���ݣ��ɵģ��°��Ѳ���
        private const int SC_DL_5MIN = 0x2705;	// 5����K������

        //define for SC_KLineAsk::m_wDataType
        private const int KLINE_DAYDATA = 0;		//����
        private const int KLINE_MIN5DATA = 1;		//5������
        //��Ϣ�����������ԵĶ���
        private const int CLASS_JYSXX = 0;	// ����������
        private const int CLASS_STKINFO = 1;	// ��ʷ��Ϣ����
        private const int CLASS_NEWS = 2;	// ����
        private const int CLASS_STOCKBASE = 3;	// F10
        private const int CLASS_MKTINFO = 4;	// �ۺ���Ѷ
        // ������˾�����������ʶwealth-lab 0x25875298
        private const int SMARTQUANT_ID = 0x25875298;
        #endregion



        protected override void WndProc(ref Message m)
        {
            try
            {
                int i, offset, stockrecsize;
                short nIndex;
                ushort wMarket;
                SCMarket pscm;


                if (m.Msg == WM_USER)
                {
                    // Console.WriteLine("��ʼ���ա�����");
                    SCHead pHead = (SCHead)m.GetLParam(typeof(SCHead));
                    switch (pHead.m_nType)
                    {
                        case SC_MARKET:
                            {
                                SC_MarketReply psc = (SC_MarketReply)m.GetLParam(typeof(SC_MarketReply));
                                //Console.WriteLine("�����г�����...");
                                offset = Marshal.SizeOf(typeof(SC_MarketReply));
                                stockrecsize = Marshal.SizeOf(typeof(StockInfo));
                                MKTDATA = psc.m_Market;
                                ArrayList symbols = new ArrayList();

                                for (i = 0; i < psc.m_Market.m_nCount; i++)
                                {
                                    StockInfo record = (StockInfo)Marshal.PtrToStructure
                                       (new IntPtr(m.LParam.ToInt32() + stockrecsize * i +
                                       Marshal.SizeOf(typeof(SC_MarketReply))), typeof(StockInfo));
                                    //string wmarket = GetMarketName(MKTDATA);
                                    string symbol=record.m_szLabel;
                                    #region RemRegion
                                    
                                    //Console.WriteLine("wndProc:"+symbol);
                                    //if (MKTDATA.scmarketcode == "SH" && symbol.StartsWith("00"))
                                    //{
                                    //    switch (symbol)
                                    //    {
                                    //        case "000001":
                                    //            //report.m_szLabelName = A0001;
                                    //            record.m_szLabel = "1A0001";
                                    //            break;
                                    //        case "000002":
                                    //            //report.m_szLabelName = A0002;
                                    //            record.m_szLabel = "1A0002";
                                    //            break;
                                    //        case "000003":
                                    //            //report.m_szLabelName = A0003;
                                    //            record.m_szLabel = "1A0003";
                                    //            break;
                                    //        case "000004":
                                    //            //report.m_szLabelName = B0001;
                                    //            record.m_szLabel = "1B0001";
                                    //            break;
                                    //        case "000005":
                                    //            //report.m_szLabelName = B0002;
                                    //            record.m_szLabel = "1B0002";
                                    //            break;
                                    //        case "000006":
                                    //            //report.m_szLabelName = B0004;
                                    //            record.m_szLabel = "1B0004";
                                    //            break;
                                    //        case "000007":
                                    //            //report.m_szLabelName = B0005;
                                    //            record.m_szLabel = "1B0005";
                                    //            break;
                                    //        case "000008":
                                    //            //report.m_szLabelName = B0006;
                                    //            record.m_szLabel = "1B0006";
                                    //            break;
                                    //        //											case "000009":
                                    //        //												report.m_szLabelName=B0006;
                                    //        //												break;
                                    //        case "000010":
                                    //            //report.m_szLabelName = B0007;
                                    //            record.m_szLabel = "1B0007";
                                    //            break;
                                    //        case "000011":
                                    //            //report.m_szLabelName = B0008;
                                    //            record.m_szLabel = "1B0008";
                                    //            break;
                                    //        case "000012":
                                    //            //report.m_szLabelName = B0009;
                                    //            record.m_szLabel = "1B0009";
                                    //            break;
                                    //        case "000013":
                                    //            //report.m_szLabelName = B0010;
                                    //            record.m_szLabel = "1B0010";
                                    //            break;
                                    //        case "000015":
                                    //            //report.m_szLabelName = C0002;
                                    //            record.m_szLabel = "1C0002";
                                    //            break;
                                    //        case "000016":
                                    //            //report.m_szLabelName = C0003;
                                    //            record.m_szLabel = "1C0003";
                                    //            break;
                                    //        case "000017":
                                    //            //report.m_szLabelName = C0004;
                                    //            record.m_szLabel = "1B0004";
                                    //            break;
                                    //        case "000901":
                                    //            //report.m_szLabelName = Z9901;
                                    //            record.m_szLabel = "399901";
                                    //            break;
                                    //        case "000902":
                                    //            //report.m_szLabelName = Z9902;
                                    //            record.m_szLabel = "399902";
                                    //            break;
                                    //        case "000903":
                                    //            //report.m_szLabelName = Z9903;
                                    //            record.m_szLabel = "399903";
                                    //            break;
                                    //        case "000904":
                                    //            record.m_szLabel = "399904";
                                    //            break;
                                    //        case "000905":
                                    //            record.m_szLabel = "399905";
                                    //            break;
                                    //        case "000906":
                                    //            record.m_szLabel = "399906";
                                    //            break;
                                    //        case "000907":
                                    //            record.m_szLabel = "399907";
                                    //            break;
                                    //        case "000908":
                                    //            record.m_szLabel = "399908";
                                    //            break;
                                    //        case "000909":
                                    //            record.m_szLabel = "399909";
                                    //            break;
                                    //        case "000910":
                                    //            record.m_szLabel = "399910";
                                    //            break;
                                    //        case "000911":
                                    //            record.m_szLabel = "399911";
                                    //            break;
                                    //        case "000912":
                                    //            record.m_szLabel = "399912";
                                    //            break;
                                    //        case "000913":
                                    //            record.m_szLabel = "399913";
                                    //            break;
                                    //        case "000914":
                                    //            record.m_szLabel = "399914";
                                    //            break;
                                    //        case "000915":
                                    //            record.m_szLabel = "399915";
                                    //            break;
                                    //        case "000916":
                                    //            record.m_szLabel = "399916";
                                    //            break;
                                    //        case "000917":
                                    //            record.m_szLabel = "399917";
                                    //            break;
                                    //    }
                                    //}
                                    #endregion

                                    SC_CODETABLE.addData(psc.m_Market.scmarketcode, (short)i, record);
                                    symbols.Add(record.m_szLabel);
                                }
                                if (OnSC_Symbol != null)
                                {
                                    OnSC_Symbol(this, MKTDATA.scmarketcode, symbols);
                                }

                            }
                            break;
                        case SC_NOWDATA:
                            {
                                try
                                {
                                    SC_NowDataReply pnr = (SC_NowDataReply)m.GetLParam(typeof(SC_NowDataReply));
                                    //Console.WriteLine("���ڽ��� SC_nowdata");
                                    if (pnr.m_nCount > 0)
                                    {
                                        offset = Marshal.SizeOf(typeof(SC_NowDataReply));
                                        stockrecsize = Marshal.SizeOf(typeof(RCV_NOW_STRUCTEx));

                                        for (i = 0; i < pnr.m_nCount; i++)
                                        {
                                            RCV_NOW_STRUCTEx record = (RCV_NOW_STRUCTEx)Marshal.PtrToStructure(
                                                new IntPtr(m.LParam.ToInt32() + offset + stockrecsize * i), typeof(RCV_NOW_STRUCTEx));
                                            string wmarket = GetMarketName(record.m_sID.m_wMarket);

                                            //string symbol = SC_CODETABLE.GetSymbolCode(wmarket, record.m_sID.m_nIndex);
                                            string Symbol = SC_CODETABLE.GetSymbolCode(wmarket, record.m_sID.m_nIndex) + "." + wmarket.Trim();

                                            //Console.WriteLine("{0}\t {1} \t{2}\t {3}\t{4} \t{5}\t{6}",record.m_sID.m_wMarket, record.m_sID.m_nIndex,
                                            //stock.m_szLabel ,stock .m_szName , record.m_fNewPrice , record.m_fVolume,record.m_lStroke);
                                            
                                            if (OnQuote != null)
                                            {
                                                OnQuote(this, Symbol, record);
                                            }
                                        }

                                    }
                                }
                                catch (Exception ex)
                                {
                                    //StMyFunction.textwrite(string.Format
                                    //    ("time:{0} \t  SC_NOW ����:{1} \t {2} case is :{3}  ", DateTime.Now, ex.Message, ex.InnerException, ex.Source.ToString()));
                                }
                            }

                            break;
                        case SC_KLINE:
                            {
                                SC_KLineReply pk = (SC_KLineReply)m.GetLParam(typeof(SC_KLineReply));
                                offset = Marshal.SizeOf(typeof(SC_KLineReply));
                                stockrecsize = Marshal.SizeOf(typeof(RCV_HISTORY_STRUCTEx));


                                // StockInfo stockinfo = SC_CODETABLE.GetStockInfo(GetMarketName(pk.m_sID.m_wMarket), pk.m_sID.m_nIndex);
                                //Console.WriteLine("{0}\t {1} \t ", stockinfo.m_szLabel, stockinfo.m_szName);
                                List<RCV_HISTORY_STRUCTEx> Records = new List<RCV_HISTORY_STRUCTEx>();
                                switch (pk.m_wDataType)
                                {
                                    case KLINE_DAYDATA:
                                        //    Console.WriteLine("����");


                                        for (i = 0; i < pk.m_lDataCount; ++i)
                                        {
                                            RCV_HISTORY_STRUCTEx record = (RCV_HISTORY_STRUCTEx)Marshal.PtrToStructure
                                                  (new IntPtr(m.LParam.ToInt32() + stockrecsize * i +
                                                  offset), typeof(RCV_HISTORY_STRUCTEx));
                                            //DateTime mtime = new DateTime(1970, 1, 1).AddSeconds(record.m_time).ToLocalTime();
                                            //Console.WriteLine("{0}\t {1}\t {2}\t ", mtime, record.m_fClose, record.m_fVolume);
                                            Records.Add(record);

                                        }
                                        if (OnSC_KLINE != null)
                                        {
                                            OnSC_KLINE(this, pk.m_Head.m_lIndex, Records);
                                        }

                                        break;
                                    case KLINE_MIN5DATA:
                                        //      Console.WriteLine("5Min :����{0}  ����¼", pk.m_lDataCount);


                                        for (i = 0; i < pk.m_lDataCount; ++i)
                                        {
                                            RCV_HISTORY_STRUCTEx record = (RCV_HISTORY_STRUCTEx)Marshal.PtrToStructure
                                                 (new IntPtr(m.LParam.ToInt32() + stockrecsize * i +
                                                 offset), typeof(RCV_HISTORY_STRUCTEx));

                                            //Console.WriteLine("{0}\t {1}\t {2}\t ", m_timeToDateTime(record.m_time), record.m_fClose, record.m_fVolume);
                                            Records.Add(record);
                                        }
                                        if (OnSC_KLINE != null)
                                        {
                                            OnSC_KLINE(this, pk.m_Head.m_lIndex, Records);
                                        }

                                        break;
                                }
                            }

                            break;
                        case SC_PANKOU:
                            {
                                //StMyFunction .textwrite(string .Format ("time:{0} ���ڽ����̿�����....",DateTime .Now ));
                                SC_PankouReply pp = (SC_PankouReply)m.GetLParam(typeof(SC_PankouReply));
                                offset = Marshal.SizeOf(typeof(SC_PankouReply));
                                stockrecsize = Marshal.SizeOf(typeof(RCV_PANKOU_STRUCTEx));

                                //StockInfo stockinfo = SC_CODETABLE.GetStockInfo(GetMarketName(pp.m_sID.m_wMarket), pp.m_sID.m_nIndex);
                                //StMyFunction.textwrite(string.Format("{0}\t {1} \t reccount:{2} ", 
                                //                       stockinfo.m_szLabel, stockinfo.m_szName, pp, pp.m_lCount));
                                if (pp.m_lCount > 0)
                                {
                                    ArrayList Records = new ArrayList();
                                    for (i = 0; i < pp.m_lCount; ++i)
                                    {
                                        RCV_PANKOU_STRUCTEx record = (RCV_PANKOU_STRUCTEx)Marshal.PtrToStructure
                                                      (new IntPtr(m.LParam.ToInt32() + stockrecsize * i +
                                                      offset), typeof(RCV_PANKOU_STRUCTEx));

                                        //StMyFunction.textwrite(string.Format("{0}\t {1}\t {2}\t {3} \t", m_timeToDateTime(record.m_time), record.m_fNewPrice, record.m_fVolume, record.m_lStroke));
                                        Records.Add(record);
                                    }
                                    //StMyFunction.textwrite(string.Format("fished !! count:{0} lindex:{1}", Records.Count, pp.m_Head.m_lIndex));
                                    //if (OnSC_PANKOU != null)
                                    //{
                                    //    OnSC_PANKOU(this, pp.m_Head.m_lIndex, Records);
                                    //}
                                }
                            }
                            break;
                        case SC_CQ:

                            //Console.WriteLine("SC_CQ");
                            break;
                        case SC_IMTYPELIST:
                            {
                                SC_IMTypeReply pt = (SC_IMTypeReply)m.GetLParam(typeof(SC_IMTypeReply));
                                //Console.WriteLine("SC_IMTypeReply");
                            }
                            break;
                        case SC_IMTITLE:
                            SC_IMTitleReply ptr = (SC_IMTitleReply)m.GetLParam(typeof(SC_IMTitleReply));
                            //Console.WriteLine("SC_IMTitleReply");
                            break;
                        case SC_IMCONTENT:
                            {
                                //Console.WriteLine("SC_imcontent");
                            }
                            break;
                        case SC_DL_KLINE:		// ��k������
                            {
                                SC_Download pdl = (SC_Download)m.GetLParam(typeof(SC_Download));
                                offset = Marshal.SizeOf(typeof(SC_Download));
                                stockrecsize = Marshal.SizeOf(typeof(RCV_HISTORY_STRUCTEx));
                                //Console.WriteLine("�յ������������� ");
                                for (i = 0; i < pdl.m_lCount; i++)
                                {
                                    RCV_HISTORY_STRUCTEx record = (RCV_HISTORY_STRUCTEx)Marshal.PtrToStructure
                                       (new IntPtr(m.LParam.ToInt32() + stockrecsize * i +
                                       offset), typeof(RCV_HISTORY_STRUCTEx));

                                    //Console.WriteLine(string.Format("{0} \t {1} \t {2} \t   \r\n",
                                    //    m_timeToDateTime(record.m_time), record.m_fClose, record.m_fVolume));
                                }
                            }
                            break;
                        case SC_DL_5MIN:		// �����k������
                            {
                                SC_Download pdl = (SC_Download)m.GetLParam(typeof(SC_Download));
                                offset = Marshal.SizeOf(typeof(SC_Download));
                                stockrecsize = Marshal.SizeOf(typeof(RCV_HISTORY_STRUCTEx));
                                //Console.WriteLine("�յ�������������� {0} ", pdl.m_lCount);
                                for (i = 0; i < pdl.m_lCount; i++)
                                {
                                    RCV_HISTORY_STRUCTEx record = (RCV_HISTORY_STRUCTEx)Marshal.PtrToStructure
                                       (new IntPtr(m.LParam.ToInt32() + stockrecsize * i +
                                      offset), typeof(RCV_HISTORY_STRUCTEx));

                                    //Console.WriteLine(string.Format("{0} \t {1} \t {2} \t   \r\n",
                                    //    m_timeToDateTime(record.m_time), record.m_fClose, record.m_fVolume));
                                }
                            }
                            break;
                        case SC_DL_CQ:			// ��Ȩ��������
                            {
                                SC_Download pdl = (SC_Download)m.GetLParam(typeof(SC_Download));
                                offset = Marshal.SizeOf(typeof(SC_Download));
                                stockrecsize = Marshal.SizeOf(typeof(RCV_POWER_STRUCTEx));
                                //Console.WriteLine("�յ����س�Ȩ���� ");
                                for (i = 0; i < pdl.m_lCount; i++)
                                {
                                    RCV_POWER_STRUCTEx record = (RCV_POWER_STRUCTEx)Marshal.PtrToStructure
                                       (new IntPtr(m.LParam.ToInt32() + stockrecsize * i +
                                      offset), typeof(RCV_POWER_STRUCTEx));

                                    Console.WriteLine(string.Format("{0} \t {1} \t {2} \t   \r\n",
                                        m_timeToDateTime(record.m_time), record.m_fGive, record.m_fPei));
                                }

                            }
                            break;
                        case SC_DL_XX:			// ��Ѷ�������أ����������桢��Ϣ���ס����š��ۺϵ�
                            {
                                /*//SC_Download *pdl = (SC_Download *)lParam;
                                switch ( pdl->m_cClass ) {
                                case CLASS_JYSXX:
                                    sprintf(strText, "�յ����ؽ��������� %d ��", pdl->m_lCount);
                                    break;
                                case CLASS_STKINFO:
                                    sprintf(strText, "�յ�������ʷ��Ϣ���� %d ��", pdl->m_lCount);
                                    break;
                                case CLASS_NEWS:
                                    sprintf(strText, "�յ��������� %d ��", pdl->m_lCount);
                                    break;
                                case CLASS_STOCKBASE:
                                    sprintf(strText, "�յ�����F10 %d ��", pdl->m_lCount);
                                    break;
                                case CLASS_MKTINFO:
                                    sprintf(strText, "�յ������ۺ���Ѷ %d ��", pdl->m_lCount);
				                  
                             
                                 break;
                                default:
                                    break;
                                }
                                SetDlgItemText(IDC_DOWN_LOAD, strText);
                            }
                                 *     */
                                //Console.WriteLine("SC_DLXX");
                            }
                            break;
                        case SC_DL_TRACE:		// �ֱ���ϸ����
                            {
                                SC_Download pdl = (SC_Download)m.GetLParam(typeof(SC_Download));
                                offset = Marshal.SizeOf(typeof(SC_Download));
                                stockrecsize = Marshal.SizeOf(typeof(RCV_PANKOU_STRUCTEx));
                                //Console.WriteLine("�յ����طֱ����� ");
                                if (pdl.m_lCount > 0)
                                {
                                    List<RCV_PANKOU_STRUCTEx> Records = new List<RCV_PANKOU_STRUCTEx>();
                                    for (i = 0; i < pdl.m_lCount; i++)
                                    {
                                        RCV_PANKOU_STRUCTEx record = (RCV_PANKOU_STRUCTEx)Marshal.PtrToStructure
                                           (new IntPtr(m.LParam.ToInt32() + stockrecsize * i + offset), typeof(RCV_PANKOU_STRUCTEx));
                                        Records.Add(record);

                                        //Console.WriteLine(string.Format("{0} \t {1} \t {2} \t  {3} \r\n",
                                        //  m_timeToDateTime(record.m_time), record.m_fNewPrice, record.m_fVolume, record.m_fBuyPrice[0]));

                                    }
                                    if (OnSC_PANKOU != null)
                                    {
                                        string dlsymbol = SC_CODETABLE.GetSymbolCode(GetMarketName(pdl.m_sID.m_wMarket), pdl.m_sID.m_nIndex);

                                        OnSC_PANKOU(this, dlsymbol, Records);
                                    }
                                }

                            }
                            break;
                        default:
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                //StMyFunction.textwrite(string.Format("time:{0} \t���ճ���:{1} \t case is :{2} ", DateTime.Now, ex.Message, ex.Source.ToString()));
            }
            base.WndProc(ref m);
        }
        #region ��������
        public bool Drvloaded = false;

        public void DrvOpen()
        {
            RegistryKey rk = Registry.LocalMachine.OpenSubKey("SOFTWARE\\StockDrv", true);

            string dllpath = (String)rk.GetValue("scdriver"); //"d:\\scengine\\scstock.dll";

            if (!Drvloaded && System.IO.File.Exists(dllpath))
            {
                libraryHandle = LoadLibrary(@dllpath);
                IntPtr procaddr1 = GetProcAddress(libraryHandle, "SCInit");
                LoadDll dyloaddll = (LoadDll)Marshal.GetDelegateForFunctionPointer(procaddr1, typeof(LoadDll));

                SC_InitAsk sca = new SC_InitAsk();			// �����ʼ����
                sca.m_Head.m_nType = SC_INIT;

                sca.m_dwSoftware = SMARTQUANT_ID;

                sca.m_hWnd = this.Handle.ToInt32();
                sca.m_nMsg = WM_USER;


                //Console.WriteLine(Marshal.SizeOf(sca));
                if (dyloaddll(sca, Marshal.SizeOf(sca)) == true)
                //if (dyloaddll(buffer, Marshal.SizeOf(sca)) == true)
                {

                    Drvloaded = true;
                    //Console.WriteLine("�ɹ�����������");
                }
                else
                {
                    Drvloaded = false;
                }
            }
        }

        public void DrvClose()
        {
            if (Drvloaded)
            {

                IntPtr procaddr2 = GetProcAddress(libraryHandle, "SCQuit");
                UnLoadDll dyunloaddll = (UnLoadDll)Marshal.GetDelegateForFunctionPointer(procaddr2, typeof(UnLoadDll));
                dyunloaddll();
                //Console.WriteLine("�ɹ��ر���������");
                Drvloaded = false;
            }
        }

        public void SCAskData(object item, int nsize)
        {
            if (Drvloaded == true)
            {
                IntPtr procadd_askdata = GetProcAddress(libraryHandle, "SCAskData");
                AskData scaskdata = (AskData)Marshal.GetDelegateForFunctionPointer(procadd_askdata, typeof(AskData));
                scaskdata(item, nsize);
            }
        }

        public DateTime m_timeToDateTime(uint mtime)
        {
            DateTime re_time = new DateTime(1970, 1, 1).AddSeconds(mtime).ToLocalTime();
            return re_time;
        }
        public ushort GetMarketCode(string w_market)
        {
            ushort re_marketcode = BitConverter.ToUInt16(System.Text.Encoding.ASCII.GetBytes(w_market.Trim()), 0);
            return re_marketcode;
        }
        public string GetMarketName(ushort w_market)
        {
            string re_marketname = System.Text.Encoding.ASCII.GetString(BitConverter.GetBytes(w_market));
            return re_marketname.Trim();
        }
        /// <summary>
        ///  ��������5Min ���� DateTime תΪSC_KineAsk ��m_Begin and m_End ��ʽ��int�� ����
        /// </summary>
        /// <param name="inputdt">DateTime Ҫ��Сʱ�ͷ��������� :
        ///���ã�    new DateTime(2006, 6, 30, 9, 30, 0)
        /// </param>
        /// <returns></returns>
        public int DatetimeTo5MinAsk(DateTime inputdt)
        {

            TDate tm;
            tm.m_Year = (uint)inputdt.Year;
            tm.m_Month = (uint)inputdt.Month;
            tm.m_Day = (uint)inputdt.Day;
            tm.m_Hour = (uint)inputdt.Hour;
            tm.m_Minute = (uint)inputdt.Minute;
            uint result = (tm.m_Year << (32 - 12)) +
                          (tm.m_Month << (32 - 4 - 12)) +
                          (tm.m_Day << (32 - 4 - 12 - 5)) +
                          (tm.m_Hour << (32 - 4 - 12 - 5 - 5));
            return (int)result;

        }
        public int requestdata(SCDataType Type, string Symbol)
        {
            if (Drvloaded && (MKTDATA.m_lDate > 0))
            {
                //Console.WriteLine(Symbol);
                string[] Symbolsplit = Symbol.Split('.');
                switch (Type)
                {
                    case SCDataType.bi5Minutes:
                        uint m_Year, m_Month, m_Day;
                        m_Year = MKTDATA.m_lDate / 10000;
                        m_Month = MKTDATA.m_lDate % 10000 / 100;
                        m_Day = MKTDATA.m_lDate % 100;

                        DateTime dtBegin = new DateTime(1990, 1, 1, 9, 0, 0);
                        DateTime dtEnd = new DateTime((int)m_Year, (int)m_Month, (int)m_Day, 15, 0, 0);

                        SC_KLineAsk pk1;
                        pk1.m_Head.m_nType = SC_KLINE;
                        pk1.m_Head.m_cStatus = 1;
                        pk1.m_Head.m_lIndex = m_lASkIndex;
                        pk1.m_sID.m_nIndex = (short)(SC_CODETABLE.GetIndex(Symbolsplit[1].Trim(), Symbolsplit[0].Trim()));
                        pk1.m_sID.m_wMarket = GetMarketCode(Symbolsplit[1].Trim());
                        pk1.m_wDataType = KLINE_MIN5DATA;

                        pk1.m_tBegin = DatetimeTo5MinAsk(dtBegin);
                        pk1.m_tEnd = DatetimeTo5MinAsk(dtEnd);

                        SCAskData(pk1, Marshal.SizeOf(typeof(SC_KLineAsk)));
                        break;
                    case SCDataType.biDaily:
                        SC_KLineAsk pk2;
                        pk2.m_Head.m_nType = SC_KLINE;
                        pk2.m_Head.m_cStatus = 1;
                        pk2.m_Head.m_lIndex = m_lASkIndex;
                        pk2.m_sID.m_nIndex = (short)(SC_CODETABLE.GetIndex(Symbolsplit[1].Trim(), Symbolsplit[0].Trim()));
                        pk2.m_sID.m_wMarket = GetMarketCode(Symbolsplit[1].Trim());
                        pk2.m_wDataType = KLINE_DAYDATA;

                        pk2.m_tBegin = 19900101;
                        pk2.m_tEnd = (int)MKTDATA.m_lDate;

                        SCAskData(pk2, Marshal.SizeOf(typeof(SC_KLineAsk)));
                        break;
                    case SCDataType.biTicks:
                        SC_PankouAsk pk3;
                        pk3.m_Head.m_nType = SC_PANKOU;
                        pk3.m_Head.m_cStatus = 1;
                        pk3.m_Head.m_lIndex = m_lASkIndex;
                        pk3.m_sID.m_nIndex = (short)(SC_CODETABLE.GetIndex(Symbolsplit[1].Trim(), Symbolsplit[0].Trim()));
                        pk3.m_sID.m_wMarket = GetMarketCode(Symbolsplit[1].Trim());
                        pk3.m_lDate = MKTDATA.m_lDate;
                        SCAskData(pk3, Marshal.SizeOf(typeof(SC_PankouAsk)));
                        break;
                    default:
                        break;
                }
                m_lASkIndex++;
                return (m_lASkIndex - 1);
            }
            return -1;
        }

        #endregion

        # region �������

        public class CodeTable
        {
            private Dictionary<string, Dictionary<short, StockInfo>> SC_CodeTable = new Dictionary<string, Dictionary<short, StockInfo>>();
            public CodeTable()
            {

            }
            public void addData(string w_market, short n_index, StockInfo stockinfo)
            {
                try
                {
                    w_market = w_market.Trim();


                    lock (SC_CodeTable)
                    {
                        if (w_market != "")
                        {
                            if (!SC_CodeTable.ContainsKey(w_market))
                            {
                                SC_CodeTable.Add(w_market, new Dictionary<short, StockInfo>());
                            }
                            Dictionary<short, StockInfo> sc_codetable = SC_CodeTable[w_market];

                            if (sc_codetable.ContainsKey(n_index))
                            {
                                sc_codetable[n_index] = stockinfo;
                            }
                            else
                            {
                                sc_codetable.Add(n_index, stockinfo);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    //StMyFunction.textwrite(string.Format(" CodeTable AddData error !! Time:{0}   {1}",
                    //                           DateTime.Now, ex.Message));
                }
            }

            public short GetIndex(string w_market, string sccode)
            {
                w_market = w_market.Trim();
                sccode = sccode.Trim();
                short re_index = -1;
                try
                {
                    lock (SC_CodeTable)
                    {
                        if (w_market != "")
                        {
                            if (SC_CodeTable.ContainsKey(w_market))
                            {
                                foreach (short tempkey in SC_CodeTable[w_market].Keys)
                                {
                                    if (SC_CodeTable[w_market][tempkey].m_szLabel.Trim() == sccode)
                                    {
                                        re_index = tempkey;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    //StMyFunction.textwrite(string.Format(" CodeTable GetIndex error !! Time:{0}   {1}",
                    //                         DateTime.Now, ex.Message));

                }
                return re_index;
            }
            
            public StockInfo GetStockInfo(string w_market, short n_index)
            {
                StockInfo re_stockinfo = new StockInfo();
                w_market = w_market.Trim();
                try
                {
                    lock (SC_CodeTable)
                    {
                        if (w_market != "")
                        {
                            if (SC_CodeTable.ContainsKey(w_market))
                            {
                                if (SC_CodeTable[w_market].ContainsKey(n_index))
                                {
                                    re_stockinfo = SC_CodeTable[w_market][n_index];
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    //StMyFunction.textwrite(string.Format(" CodeTable GetStockInfo error !! Time:{0}   {1}",
                    //                          DateTime.Now, ex.Message));
                }
                return re_stockinfo;
            }
            public string GetSymbolName(string SymbolCode)
            {
                string SymbolName = string.Empty;
                try
                {
                    string[] SymbolCodeSplit = SymbolCode.Split('.');
                    string w_market = SymbolCodeSplit[1].Trim();
                    string sccode = SymbolCodeSplit[0].Trim();


                    lock (SC_CodeTable)
                    {
                        if (w_market != "")
                        {
                            if (SC_CodeTable.ContainsKey(w_market))
                            {
                                foreach (short tempkey in SC_CodeTable[w_market].Keys)
                                {
                                    if (SC_CodeTable[w_market][tempkey].m_szLabel.Trim() == sccode)
                                    {
                                        SymbolName = SC_CodeTable[w_market][tempkey].m_szName.Trim();
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    //StMyFunction.textwrite(string.Format(" CodeTable GetSymbolName error !! Time:{0}   {1}",
                    //                          DateTime.Now, ex.Message));
                }
                return SymbolName;
            }
            public string GetSymbolCode(string w_market, short n_index)
            {
                string SymbolCode = string.Empty;
                w_market = w_market.Trim();
                try
                {
                    lock (SC_CodeTable)
                    {
                        if (w_market != "")
                        {
                            if (SC_CodeTable.ContainsKey(w_market))
                            {
                                if (SC_CodeTable[w_market].ContainsKey(n_index))
                                {

                                    SymbolCode = SC_CodeTable[w_market][n_index].m_szLabel;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    //StMyFunction.textwrite(string.Format(" CodeTable GetStockInfo error !! Time:{0}   {1}",
                    //                          DateTime.Now, ex.Message));
                }
                return SymbolCode;
            }
        }
        #endregion
    }

    public class TSCProvider:IProvider ,IMarketDataProvider ,IHistoryProvider ,IInstrumentProvider 
    {
        private IBarFactory factory;
        private int LOTSIZE = 100;

        private bool isConnected = false;
        private List<string> subscribedSymbols = new List<string>();
        private Hashtable tkDnlds = Hashtable.Synchronized(new Hashtable());
        protected SCRTcontrol fTSdrv;
        private Hashtable QuoteCache = Hashtable.Synchronized(new Hashtable());

        public TSCProvider()
        {
            BarFactory = new BarFactory(false);
            fTSdrv = new SCRTcontrol();
            fTSdrv.OnSC_Symbol += new SC_Symbols_EventHandler(fTSdrv_OnSC_Symbol);
            fTSdrv.OnQuote += new SC_NOWDATAEventHandler(fTSdrv_OnQuote);
            fTSdrv.OnSC_PANKOU += new SC_PANKOU_EventHandler(fTSdrv_OnSC_TraceDnld);
            ProviderManager.Add(this);
        }
        void fTSdrv_OnSC_Symbol(SCRTcontrol sender, string Exchange, ArrayList e)
        {
            //throw new Exception("The method or operation is not implemented.");
            if (Exchange == "SZ" || Exchange == "SH")
            {
                foreach (string symbol in e)
                {
                    //Instrument instrument = SmartQuant.Instruments.InstrumentManager.Instruments[symbol];
                    string dm = symbol+"."+Exchange;
                    //Console.WriteLine("{0}  {1}",dm,fTSdrv.SC_CODETABLE.GetSymbolName(dm)   );

                    if (!InstrumentManager.Instruments.Contains(dm))
                    {
                        if (CheckExcluded(symbol, Exchange) == false)
                        {
                            Instrument instrument = new Instrument(dm,Drzwz.SQCommon.GetSecurityType(dm));
                            instrument.SecurityDesc = fTSdrv.SC_CODETABLE.GetSymbolName(dm);
                            instrument.SecurityExchange = Exchange;
                            instrument.Save();
                            Console.WriteLine("{0}�����ӵ�{1}!", dm, Drzwz.SQCommon.GetSecurityType(dm));
                             #region ע�͵��Ĵ���

                            //if (symbol.StartsWith("100") || symbol.StartsWith("110") || symbol.StartsWith("120")
                            //            || symbol.StartsWith("125"))
                            //{
                            //    Instrument instrument = new Instrument(symbol, "CB");
                            //    instrument.Save();
                            //}
                            //else if (symbol.StartsWith("20"))
                            //{
                            //    Instrument instrument = new Instrument(symbol, "REPO");
                            //    instrument.Save();
                            //}
                            //else if (symbol.StartsWith("500") || symbol.StartsWith("51") || symbol.StartsWith("550")
                            //|| symbol.StartsWith("184") || symbol.StartsWith("16"))
                            //{
                            //    Instrument instrument = new Instrument(symbol, "MF");
                            //    instrument.Save();
                            //}
                            //else if (symbol.StartsWith("010"))
                            //{
                            //    Instrument instrument = new Instrument(symbol, "TBOND");
                            //    instrument.Save();
                            //}
                            //else if (symbol.StartsWith("129") || symbol.StartsWith("111"))
                            //{
                            //    Instrument instrument = new Instrument(symbol, "CORP");
                            //    instrument.Save();
                            //}
                            //else if (symbol.StartsWith("39"))
                            //{
                            //    Instrument instrument = new Instrument(symbol, "Index");
                            //    instrument.Save();
                            //}
                            //else
                            //{
                            //    Instrument instrument = new Instrument(symbol, "W");
                            //    instrument.Save();
                            //}
                            #endregion
                        }
                    }
                    
                }
            }
        }
        bool CheckExcluded(string symbol, string mkt)
        {
            if (mkt == "SH")
            {
                if (symbol.StartsWith("90") || symbol.StartsWith("609")
                ||  symbol.StartsWith("7")
                || symbol.StartsWith("09") || symbol.StartsWith("582")
                || symbol.StartsWith("9") || symbol.StartsWith("8000")
                || symbol.StartsWith("181") || symbol.StartsWith("190")
                || symbol.StartsWith("203") || symbol.StartsWith("121")
                || symbol.StartsWith("52") || symbol.StartsWith("81") 
                || symbol.StartsWith("83") || symbol.StartsWith("88"))
                {
                    return true;
                }
            }
            if (mkt == "SZ")
            {
                if (symbol.StartsWith("20") || symbol.StartsWith("131")
                    || symbol.StartsWith("100") || symbol.StartsWith("101")
                    || symbol.StartsWith("131") || symbol.StartsWith("003")
                    || symbol.StartsWith("004") || symbol.StartsWith("4")
                    || symbol.StartsWith("07") || symbol.StartsWith("08")
                    || symbol.StartsWith("119") || symbol.StartsWith("300")
                    || symbol.StartsWith("188") || symbol.StartsWith("36")
                )
                {
                    return true;
                }
            }
            return false;
        }
        void fTSdrv_OnSC_TraceDnld(SCRTcontrol sender, string Symbol, List<RCV_PANKOU_STRUCTEx> e)
        {            
            if (Symbol != null)
            {
                string dm=Symbol;
                MessageBox.Show(dm);
                SCTickHistory his=new SCTickHistory (Symbol ,e);
                if (!tkDnlds.ContainsKey(Symbol))
                {
                    tkDnlds.Add(Symbol, his);
                }
                if (Symbol == "939988")
                {
                    foreach (SCTickHistory his1 in tkDnlds.Values)
                    {
                        //ThreadPool.QueueUserWorkItem(new WaitCallback(SCTraceDnHandler), (object)his1);
                        SCTraceDnHandler((object)his1);
                    }
                    Console.WriteLine("SC tick history download complete!");
                }
                //ThreadPool.QueueUserWorkItem(new WaitCallback(SCTraceDnHandler), (object)his);
            }
        }
        void SCTraceDnHandler(object state)
        {
            SCTickHistory his = (SCTickHistory)state;
            string Symbol = his.Symbol;
            List<RCV_PANKOU_STRUCTEx> e = his.Records;

            Instrument instrument = SmartQuant.Instruments.InstrumentManager.Instruments[Symbol];

            if (instrument != null && e.Count > 0)
            {
                DateTime timestamp = fTSdrv.m_timeToDateTime(e[0].m_time);

                IDataSeries tradeseries = DataManager.GetDataSeries(instrument,"Trade");
                if (tradeseries == null)
                {
                    tradeseries = DataManager.AddDataSeries (instrument,"Trade");
                }
                IDataSeries quoteseries = DataManager.GetDataSeries(instrument, "Quote"); 
                if (quoteseries == null && instrument.SecurityType != "Index")
                {
                    quoteseries = DataManager.AddDataSeries(instrument, "Quote"); 
                }
                IDataSeries mdseries = DataManager.GetDataSeries(instrument, "Depth"); 
                if (mdseries == null && instrument.SecurityType != "Index")
                {
                    mdseries = DataManager.AddDataSeries(instrument, "Depth"); 
                }
                if (mdseries!=null&&mdseries.Count > 0)
                {
                    int firstpos = -1;
                    
                    foreach (RCV_PANKOU_STRUCTEx report in e)
                    {
                        if (report.m_fBuyPrice[0] != 0 || report.m_fSellPrice[0] != 0)
                        {
                            DateTime d1=fTSdrv.m_timeToDateTime(report.m_time); 
                            firstpos = mdseries.IndexOf(d1,SmartQuant.Data. SearchOption.Prev );
                            //DateTime firstpostime = mdseries.DateTimeAt(firstpos);
                            if (firstpos != -1 )
                            {
                                try
                                {
                                    if (d1.CompareTo(mdseries.DateTimeAt(firstpos)) > 0)
                                    {
                                        firstpos += 1;

                                    }
                                    int loop = mdseries.Count;
                                    for (int k = firstpos; k < loop; k++)
                                    {
                                        mdseries.RemoveAt(firstpos);
                                    }
                                }
                                catch
                                {
                                    //Trace.WriteLine(Symbol +" invalid first pos number "+firstpos +" and time "+d1);
                                }
                                
                            }                            
                            break;
                        }
                    }
                    
                    
                }

                //ArrayList tslist = new ArrayList();
                //IDataSeries tstatsseries = DataManager.GetDataSeries(instrument, "TStats");
                //if (tstatsseries == null && instrument.SecurityType == "Stock")
                //{
                //    tstatsseries = DataManager.AddDataSeries(instrument, "TStats");
                //}
                //if (tstatsseries != null)
                //{
                //    FileDataServer fs = (SmartQuant.Instruments.FileDataServer)DataManager.Server;
                //    fs.File.Series[tstatsseries.Name].MaxBlockSize = 5000;

                //    if (tstatsseries.Count > 0)
                //    {
                //        int firstpos = -1;
                //        foreach (RCV_PANKOU_STRUCTEx report in e)
                //        {
                //            if (report.m_fVolume != 0)
                //            {
                //                DateTime d1 = fTSdrv.m_timeToDateTime(report.m_time);
                //                firstpos = tstatsseries.IndexOf(d1, SmartQuant.Data.SearchOption.Prev);
                //                if (firstpos != -1)
                //                {
                //                    if (d1.CompareTo(tstatsseries.DateTimeAt(firstpos)) > 0)
                //                    {
                //                        firstpos += 1;

                //                    }
                //                    int loop = tstatsseries.Count;
                //                    for (int k = firstpos; k < loop; k++)
                //                    {
                //                        tstatsseries.RemoveAt(firstpos);
                //                    }
                //                }
                //                break;
                //            }
                //        }

                //        //for (int k = firstpos+1; k < tstatsseries.Count; k++)
                //        //{
                //        //    tstatsseries.RemoveAt(k);
                //        //}

                //    }
                //}

                //tradeseries.
                if (e[0].m_fNewPrice != 0)
                {
                    double last = (double)Math.Round(e[0].m_fNewPrice, 3);
                    int size = (int)e[0].m_fVolume;
                    Trade open = new Trade(timestamp, last, size);
                    tradeseries.Update(open.DateTime, open);

                    //if (tstatsseries != null)
                    //{
                    //    TStats statsopen = new TStats(timestamp, last, size, (double)e[0].m_fAmount,
                    //        (double)Math.Round(e[0].m_fBuyPrice[0], 3), (double)Math.Round(e[0].m_fSellPrice[0], 3));
                    //    tstatsseries.Update(statsopen.DateTime, statsopen);
                    //}
                }
                if (e[0].m_fBuyPrice[0] != 0 || e[0].m_fSellPrice[0] != 0)
                {
                    if (quoteseries != null)
                    {
                        Quote openquote = new Quote(timestamp, (double)Math.Round(e[0].m_fBuyPrice[0], 3), (int)e[0].m_fBuyVolume[0],
                            (double)Math.Round(e[0].m_fSellPrice[0], 3), (int)e[0].m_fSellVolume[0]);
                        quoteseries.Update(openquote.DateTime, openquote);
                    }

                    ArrayList mdlist = new ArrayList();

                    for (int i = 0; i < 5; i++)
                    {
                        if (e[0].m_fBuyPrice[i] != 0)
                        {
                            SmartQuant.Data.MarketDepth md_bid = new SmartQuant.Data.MarketDepth();
                            md_bid.Source = "SCDN";
                            md_bid.ProviderId = this.Id;
                            md_bid.MarketMaker = "EXCH";
                            md_bid.DateTime = timestamp;
                            md_bid.Side = SmartQuant.Data.MDSide.Bid;
                            md_bid.Price = (double)Math.Round(e[0].m_fBuyPrice[i], 3);
                            md_bid.Size = (int)e[0].m_fBuyVolume[i];
                            md_bid.Position = i;
                            md_bid.Operation = SmartQuant.Data.MDOperation.Insert;
                            mdlist.Add(md_bid);
                        }
                        if (e[0].m_fSellPrice[i] != 0)
                        {
                            SmartQuant.Data.MarketDepth md_ask = new SmartQuant.Data.MarketDepth();
                            md_ask.ProviderId = this.Id;
                            md_ask.Source = "SCDN";
                            md_ask.MarketMaker = "EXCH";
                            md_ask.DateTime = timestamp;
                            md_ask.Side = SmartQuant.Data.MDSide.Ask;
                            md_ask.Price = (double)Math.Round(e[0].m_fSellPrice[i], 3);
                            md_ask.Size = (int)e[0].m_fSellVolume[i];
                            md_ask.Position = i;
                            md_ask.Operation = SmartQuant.Data.MDOperation.Insert;
                            mdlist.Add(md_ask);
                        }
                    }
                    if (mdlist.Count != 0 && mdseries!=null )
                    {
                        foreach (MarketDepth depth in mdlist)
                        {
                            mdseries.Add(depth.DateTime, depth);
                        }
                    }
                }

                for (int i = 1; i < e.Count; i++)
                {
                    RCV_PANKOU_STRUCTEx prvrecord = e[i - 1];
                    RCV_PANKOU_STRUCTEx record = e[i];
                    if (prvrecord.m_time != record.m_time)
                    {
                        timestamp = fTSdrv.m_timeToDateTime(record.m_time);
                        double last = (double)Math.Round(record.m_fNewPrice, 3);
                        double size = (double)Math.Round(record.m_fVolume - prvrecord.m_fVolume, 3);
                        double bid = Math.Round(record.m_fBuyPrice[0], 3);
                        double ask = Math.Round(record.m_fSellPrice[0], 3);
                        int bidsize = (int)record.m_fBuyVolume[0];
                        int asksize = (int)record.m_fSellVolume[0];
                        double prvbid = Math.Round(prvrecord.m_fBuyPrice[0], 3);
                        double prvask = Math.Round(prvrecord.m_fSellPrice[0], 3);
                        int prvbidsize = (int)prvrecord.m_fBuyVolume[0];
                        int prvasksize = (int)prvrecord.m_fSellVolume[0];
                        double amount = (double)(record.m_fAmount - prvrecord.m_fAmount);

                        if (record.m_fVolume > prvrecord.m_fVolume)
                        {
                            if (instrument.SecurityType == "Stock" || instrument.SecurityType == "OPT" || instrument.SecurityType == "ETF" || instrument.SecurityType == "W")
                            {
                                int vonbid = prvask - prvbid != 0 ? (int)Math.Round((prvask * size * LOTSIZE - amount) / (prvask - prvbid)) : (int)Math.Round (size * LOTSIZE / 2);
                                int vonask = (int)Math.Round (size * LOTSIZE - vonbid);

                                /*if (prvask == 0&&prvbid!=0)
                                {
                                    vonbid = size * LOTSIZE;
                                }
                                if (prvbid == 0 && prvask != 0)
                                {
                                    vonask = size * LOTSIZE;
                                }*/

                                if (vonbid >= 1)
                                {
                                    if (vonbid > size * LOTSIZE)//����1
                                    {
                                        //vonbid = size * LOTSIZE;
                                        vonask = 0;
                                        //amntonask = 0;
                                        //Trade trade = new Trade(timestamp, prvbid, vonbid);
                                        //tradeseries.Update(trade.DateTime, trade);

                                    }
                                    //amntonbid = Math.Round(vonbid * prvbid, 1);
                                }
                                else
                                {
                                    vonbid = 0;
                                }
                                if (vonask >= 1)
                                {
                                    if (vonask > size * LOTSIZE)//����1
                                    {
                                        //vonask = size * LOTSIZE;
                                        vonbid = 0;
                                        //amntonbid = 0;
                                        //Trade trade = new Trade(timestamp, prvask, vonask);
                                        //tradeseries.Update(trade.DateTime, trade);
                                    }
                                    //amntonask = Math.Round(vonask * prvask, 1);
                                }
                                else
                                {
                                    vonask = 0;
                                }
                                if (vonbid * vonask != 0)
                                {
                                    if (prvbid * prvask != 0)
                                    {
                                        if (last * 2 > prvbid + prvask)//����������������
                                        {
                                            Trade trade1 = new Trade(timestamp, prvbid, vonbid);
                                            Trade trade2 = new Trade(timestamp.AddMilliseconds(500), last, vonask);
                                            tradeseries.Update(trade1.DateTime, trade1);
                                            tradeseries.Update(trade1.DateTime, trade2);
                                        }
                                        else if (last * 2 < prvbid + prvask)//���������������
                                        {
                                            Trade trade1 = new Trade(timestamp, prvask, vonask);
                                            Trade trade2 = new Trade(timestamp.AddMilliseconds(500), last, vonbid);
                                            tradeseries.Update(trade1.DateTime, trade1);
                                            tradeseries.Update(trade1.DateTime, trade2);
                                        }
                                        else
                                        {
                                            //Trade trade1 = new Trade(timestamp, prvbid, vonbid);
                                            //Trade trade2 = new Trade(timestamp.AddMilliseconds(500), prvask, vonask);
                                            //tradeseries.Update(trade1.DateTime, trade1);
                                            //tradeseries.Update(trade1.DateTime, trade2);
                                            Trade trade = new Trade(timestamp, last, (int)(size * LOTSIZE));
                                            tradeseries.Update(trade.DateTime, trade);
                                        }
                                    }
                                    else
                                    {
                                        Trade trade = new Trade(timestamp, last, (int)(size * LOTSIZE));
                                        tradeseries.Update(trade.DateTime, trade);
                                    }
                                }
                                else
                                {
                                    Trade trade = new Trade(timestamp, last, (int)(size * LOTSIZE));
                                    tradeseries.Update(trade.DateTime, trade);
                                }
                            }
                            else
                            {
                                Trade trade = new Trade(timestamp, last, (int)(size));
                                tradeseries.Update(trade.DateTime, trade);
                            }

                        }
                        //if (record.m_fVolume > prvrecord.m_fVolume)
                        //{
                        //    if (tstatsseries != null)
                        //    {
                        //        TStats stats = new TStats(timestamp, last, size, (double)(record.m_fAmount - prvrecord.m_fAmount),
                        //            prvbid, prvask);
                        //        tstatsseries.Update(timestamp, stats);
                        //    }
                        //}
                        if (prvbid != 0 || prvask != 0)
                        {
                            if (bid != prvbid || bidsize != prvbidsize ||
                                ask != prvask || asksize != prvasksize)
                            {
                                if (bid != 0 || ask != 0)
                                {
                                    if (quoteseries != null)
                                    {
                                        Quote quote = new Quote(timestamp, bid, bidsize, ask, asksize);
                                        quoteseries.Update(quote.DateTime, quote);
                                    }
                                }
                            }
                        }

                        ArrayList mdlist = new ArrayList();
                        if (prvbid != 0 || prvask != 0)
                        {
                            for (int j1 = 0; j1 < 5; j1++)
                            {
                                double lastmdbid = (double)Math.Round(prvrecord.m_fBuyPrice[j1], 3);
                                double mdbid = (double)Math.Round(record.m_fBuyPrice[j1], 3);

                                if (lastmdbid != mdbid || prvrecord.m_fBuyVolume[j1] != record.m_fBuyVolume[j1])
                                {
                                    SmartQuant.Data.MarketDepth md_bid = new SmartQuant.Data.MarketDepth();
                                    md_bid.Source = "SCDN";
                                    md_bid.ProviderId = this.Id;
                                    md_bid.MarketMaker = "EXCH";
                                    md_bid.DateTime = timestamp;
                                    md_bid.Side = SmartQuant.Data.MDSide.Bid;
                                    md_bid.Price = mdbid;
                                    md_bid.Size = (int)record.m_fBuyVolume[j1];
                                    md_bid.Position = j1;
                                    if (lastmdbid == 0)
                                    {
                                        if (j1 == 1 && mdbid == 0 && record.m_fBuyPrice[0] == record.m_fSellPrice[0])
                                        {
                                            md_bid.Operation = SmartQuant.Data.MDOperation.Undefined;
                                        }
                                        else
                                        {
                                            md_bid.Operation = SmartQuant.Data.MDOperation.Insert;
                                        }
                                    }
                                    else
                                    {
                                        if (mdbid == 0)
                                        {
                                            md_bid.Operation = SmartQuant.Data.MDOperation.Delete;
                                        }
                                        else
                                        {
                                            md_bid.Operation = SmartQuant.Data.MDOperation.Update;
                                        }
                                    }
                                    mdlist.Add(md_bid);
                                    if (md_bid.Operation == MDOperation.Delete)
                                    {
                                        break;
                                    }
                                }
                            }
                            for (int j2 = 0; j2 < 5; j2++) 
                            {
                                double lastmdask = (double)Math.Round(prvrecord.m_fSellPrice[j2], 3);
                                double mdask = (double)Math.Round(record.m_fSellPrice[j2], 3);
                                if (lastmdask != mdask || prvrecord.m_fSellVolume[j2] != record.m_fSellVolume[j2])
                                {
                                    SmartQuant.Data.MarketDepth md_ask = new SmartQuant.Data.MarketDepth();
                                    md_ask.ProviderId = this.Id;
                                    md_ask.Source = "SCDN";
                                    md_ask.MarketMaker = "EXCH";
                                    md_ask.DateTime = timestamp;
                                    md_ask.Side = SmartQuant.Data.MDSide.Ask;
                                    md_ask.Price = mdask;
                                    md_ask.Size = (int)record.m_fSellVolume[j2];
                                    md_ask.Position = j2;
                                    if (lastmdask == 0)
                                    {
                                        if (j2 == 1 && mdask == 0 && record.m_fBuyPrice[0] == record.m_fSellPrice[0])
                                        {
                                            md_ask.Operation = SmartQuant.Data.MDOperation.Undefined;
                                        }
                                        else
                                        {
                                            md_ask.Operation = SmartQuant.Data.MDOperation.Insert;
                                        }
                                    }
                                    else
                                    {
                                        if (mdask == 0)
                                        {
                                            md_ask.Operation = SmartQuant.Data.MDOperation.Delete;
                                        }
                                        else
                                        {
                                            md_ask.Operation = SmartQuant.Data.MDOperation.Update;
                                        }
                                    }
                                    mdlist.Add(md_ask);
                                    if (md_ask.Operation == MDOperation.Delete)
                                    {
                                        break;
                                    }
                                }
                            }
                        }
                        if (mdlist.Count != 0 && mdseries!=null)
                        {
                            foreach (MarketDepth depth in mdlist)
                            {
                                mdseries.Add(depth.DateTime, depth);
                            }
                        }
                    }
                }
                Thread.Sleep(5);
            }
        }
        void fTSdrv_OnQuote(SCRTcontrol sender, string Symbol, RCV_NOW_STRUCTEx e)
        {
            if (Symbol != null)
            {
                string dm = Symbol;
                //if (dm.StartsWith("60"))
                //{
                //    dm += ".SH";
                //}
                //else if (dm.StartsWith("00"))
                //{
                //    dm += ".SZ";
                //}
                //else
                //{
                //    Console.WriteLine(dm+" , not  stock.");
                //}
                //EmitError(-1, -1, dm+" quote."); 
                //Console.WriteLine(dm + " in fTSdrv_OnQuote");
                if (subscribedSymbols.Contains(dm))
                {
                    bool isNewTrade = true;
                    bool isNewQuote = true;
                    bool isNewDepth = true;
                    Instrument instrument = SmartQuant.Instruments.InstrumentManager.Instruments[dm];
                    //IDataSeries statseries = instrument.GetDataSeries("TStats");
                    //if (statseries == null&&instrument .SecurityType =="Stock")
                    //{
                    //    statseries=instrument.AddDataSeries("TStats");
                    //}
                    //if (statseries != null)
                    //{
                    //    FileDataServer fs = (SmartQuant.Instruments.FileDataServer)DataManager.Server;
                    //    fs.File.Series[statseries.Name].MaxBlockSize = 5000;
                    //}
                    RCV_NOW_STRUCTEx report = e;

                    DateTime timestamp = fTSdrv.m_timeToDateTime(e.m_time);
                    double  prvamnt=0;
                    double  prvbid=0;
                    double  prvask=0 ;
                    double size = 0;

                    SmartQuant.Data.Trade td = new SmartQuant.Data.Trade();
                    td.DateTime = timestamp;

                    SmartQuant.Data.Quote qt = new SmartQuant.Data.Quote();
                    qt.DateTime = timestamp;

                    SmartQuant.Data.MarketDepth[] md;
                    ArrayList mdlist = new ArrayList();
                    //md.DateTime= fTSdrv.m_timeToDateTime(e.m_time);

                    if (!QuoteCache.ContainsKey(dm))
                    {
                        td.Price = (double)Math.Round(report.m_fNewPrice, 3);
                        td.Size = (int)report.m_fVolume;
                        qt.Bid = (double)Math.Round(report.m_fBuyPrice[0], 3);
                        qt.BidSize = (int)report.m_fBuyVolume[0];
                        qt.Ask = (double)Math.Round(report.m_fSellPrice[0], 3);
                        qt.AskSize = (int)report.m_fSellVolume[0];
                        prvbid=qt.Bid;
                        prvask =qt.Ask ;

                        for (int i = 0; i < 5; i++)
                        {
                            if (report.m_fBuyPrice[i] != 0)
                            {
                                SmartQuant.Data.MarketDepth md_bid = new SmartQuant.Data.MarketDepth();
                                md_bid.Source = "SCRT";
                                md_bid.ProviderId = this.Id;
                                md_bid.MarketMaker = "EXCH";
                                md_bid.DateTime = timestamp;
                                md_bid.Side = SmartQuant.Data.MDSide.Bid;
                                md_bid.Price = (double)Math.Round(report.m_fBuyPrice[i],3);
                                md_bid.Size = (int)report.m_fBuyVolume[i];
                                md_bid.Position = i;
                                md_bid.Operation = SmartQuant.Data.MDOperation.Insert;
                                mdlist.Add(md_bid);
                            }
                            if (report.m_fSellPrice[i] != 0)
                            {
                                SmartQuant.Data.MarketDepth md_ask = new SmartQuant.Data.MarketDepth();
                                md_ask.ProviderId = this.Id;
                                md_ask.Source = "SCRT";
                                md_ask.MarketMaker = "EXCH";
                                md_ask.DateTime = timestamp;
                                md_ask.Side = SmartQuant.Data.MDSide.Ask ;
                                md_ask.Price = (double)Math.Round(report.m_fSellPrice[i],3);
                                md_ask.Size = (int)report.m_fSellVolume[i];
                                md_ask.Position = i;
                                md_ask.Operation = SmartQuant.Data.MDOperation.Insert;
                                mdlist.Add(md_ask);
                            }                            
                        }
                        if (mdlist.Count == 0)
                        {
                            isNewDepth = false;
                        }

                        QuoteCache.Add(dm, e);
                    }
                    else
                    {
                        RCV_NOW_STRUCTEx lastreport = (RCV_NOW_STRUCTEx)QuoteCache[dm];
                        if (lastreport.m_fVolume < report.m_fVolume || (lastreport.m_fVolume == report.m_fVolume && lastreport.m_fNewPrice != report.m_fNewPrice))
                        {
                            td.Price = (double)Math.Round(report.m_fNewPrice, 3);
                            td.Size = (int)(report.m_fVolume - lastreport.m_fVolume);
                            prvamnt =(double)lastreport .m_fAmount;
                            size = (double)Math.Round(report.m_fVolume - lastreport.m_fVolume, 3);
                            //prvbid = (double)lastreport.m_fBuyPrice[0];
                        }
                        else
                        {
                            isNewTrade = false;
                        }
                        if (lastreport.m_fBuyPrice[0] != 0 || lastreport.m_fSellPrice[0] != 0)
                        {
                            prvbid =Math.Round(lastreport.m_fBuyPrice[0], 3);
                            prvask =Math.Round(lastreport.m_fSellPrice[0], 3) ;
                            double bid=Math.Round(report.m_fBuyPrice[0], 3) ;
                            double ask=Math.Round(report.m_fSellPrice[0], 3);
                            int bidsize=(int)report.m_fBuyVolume[0] ;
                            int asksize=(int)report.m_fSellVolume[0];
                            if (prvbid != bid || (int)lastreport.m_fBuyVolume[0] != bidsize
                                ||  prvask!=  ask|| (int)lastreport.m_fSellVolume[0] != asksize)
                            {
                                qt.Bid = bid;
                                qt.BidSize = bidsize ;
                                qt.Ask = ask;
                                qt.AskSize = asksize ;
                                if (bid == 0 && ask == 0)
                                {
                                    isNewQuote = false;
                                }
                                
                            }
                            else
                            {
                                isNewQuote = false;
                            }

                            for (int i1 = 0; i1 < 5; i1++)
                            {
                                double lastmdbid = (double)Math.Round(lastreport.m_fBuyPrice[i1], 3);
                                double mdbid = (double)Math.Round(report.m_fBuyPrice[i1], 3);

                                if (lastmdbid != mdbid || lastreport.m_fBuyVolume[i1] != report.m_fBuyVolume[i1])
                                {
                                    SmartQuant.Data.MarketDepth md_bid = new SmartQuant.Data.MarketDepth();
                                    md_bid.Source = "SCRT";
                                    md_bid.ProviderId = this.Id;
                                    md_bid.MarketMaker = "EXCH";
                                    md_bid.DateTime = timestamp;
                                    md_bid.Side = SmartQuant.Data.MDSide.Bid;
                                    md_bid.Price = mdbid;
                                    md_bid.Size = (int)report.m_fBuyVolume[i1];
                                    md_bid.Position = i1;

                                    if (lastmdbid == 0)
                                    {
                                        if (i1 == 1 && mdbid == 0 && report.m_fBuyPrice[0] == report.m_fSellPrice[0])
                                        {
                                            md_bid.Operation = SmartQuant.Data.MDOperation.Undefined;
                                        }
                                        else
                                        {
                                            md_bid.Operation = SmartQuant.Data.MDOperation.Insert;
                                            //Trace.WriteLine("Bid " + i + " with prvprice of " + lastmdbid + " was inserted for " + Symbol);

                                        }
                                    }
                                    else
                                    {
                                        if (mdbid == 0)
                                        {
                                            md_bid.Operation = SmartQuant.Data.MDOperation.Delete;
                                            //Trace.WriteLine("Bid " + i + " with prvprice of " + lastmdbid + " was removed for " + Symbol);
                                        }
                                        else
                                        {
                                            md_bid.Operation = SmartQuant.Data.MDOperation.Update;
                                        }
                                    }
                                    mdlist.Add(md_bid);
                                    if (md_bid.Operation == SmartQuant.Data.MDOperation.Delete)
                                    {
                                        break;
                                    }
                                }
                            }
                            for (int i2 = 0; i2 < 5; i2++)
                            {
                                double lastmdask = (double)Math.Round(lastreport.m_fSellPrice[i2], 3);
                                double mdask = (double)Math.Round(report.m_fSellPrice[i2], 3);
                                if (lastmdask != mdask || lastreport.m_fSellVolume[i2] != report.m_fSellVolume[i2])
                                {
                                    SmartQuant.Data.MarketDepth md_ask = new SmartQuant.Data.MarketDepth();
                                    md_ask.ProviderId = this.Id;
                                    md_ask.Source = "SCRT";
                                    md_ask.MarketMaker = "EXCH";
                                    md_ask.DateTime = timestamp;
                                    md_ask.Side = SmartQuant.Data.MDSide.Ask;
                                    md_ask.Price = mdask;
                                    md_ask.Size = (int)report.m_fSellVolume[i2];
                                    md_ask.Position = i2;
                                    if (lastmdask == 0)
                                    {
                                        if (i2 == 1 && mdask == 0 && report.m_fBuyPrice[0] == report.m_fSellPrice[0])
                                        {
                                            md_ask.Operation = SmartQuant.Data.MDOperation.Undefined;
                                        }
                                        else
                                        {
                                            md_ask.Operation = SmartQuant.Data.MDOperation.Insert;
                                            //Trace.WriteLine("Ask " + i + " with prvprice of " + lastmdask + " was inserted for " + Symbol);
                                        }
                                    }
                                    else
                                    {
                                        if (mdask == 0)
                                        {
                                            md_ask.Operation = SmartQuant.Data.MDOperation.Delete;
                                            //Trace.WriteLine("Ask " + i + " with prvprice of " + lastmdask + " was removed for " + Symbol);
                                        }
                                        else
                                        {
                                            md_ask.Operation = SmartQuant.Data.MDOperation.Update;
                                        }
                                    }
                                    mdlist.Add(md_ask);
                                    if (md_ask.Operation == SmartQuant.Data.MDOperation.Delete)
                                    {
                                        break;
                                    }

                                }
                            }
                            if (mdlist.Count == 0)
                            {
                                isNewDepth = false;
                            }
                        }
                        else
                        {
                            isNewQuote = false;
                            isNewDepth = false;
                        }

                        QuoteCache[dm] = report;
                    }
                    if (NewTrade != null && isNewTrade)
                    {
                        if (instrument.SecurityType == "Stock" || instrument.SecurityType == "OPT" || instrument.SecurityType == "ETF" || instrument.SecurityType == "W")
                        {
                            int vonbid = prvask - prvbid != 0 ? (int)Math.Round((prvask * size * LOTSIZE - (report .m_fAmount-prvamnt) ) / (prvask - prvbid)) : (int)Math.Round(size * LOTSIZE / 2);
                            int vonask = (int)Math.Round(size * LOTSIZE - vonbid);

                            if (vonbid >= 1)
                            {
                                if (vonbid > size * LOTSIZE)//����1
                                {
                                    vonask = 0;
                                }
                            }
                            else
                            {
                                vonbid = 0;
                            }
                            if (vonask >= 1)
                            {
                                if (vonask > size * LOTSIZE)//����1
                                {
                                    vonbid = 0;
                                }
                            }
                            else
                            {
                                vonask = 0;
                            }
                            if (vonbid * vonask != 0)
                            {
                                if (prvbid * prvask != 0)
                                {
                                    if (td.Price * 2 > prvbid + prvask)//����������������
                                    {
                                        Trade trade1 = new Trade(timestamp, prvbid, vonbid);
                                        Trade trade2 = new Trade(timestamp.AddMilliseconds(500), td.Price, vonask);
                                        TradeEventArgs tdarg1 = new TradeEventArgs(trade1, instrument, this);
                                        TradeEventArgs tdarg2 = new TradeEventArgs(trade2, instrument, this);
                                        NewTrade(this, tdarg1);
                                        NewTrade(this, tdarg2);

                                    }
                                    else if (td.Price * 2 < prvbid + prvask)//���������������
                                    {
                                        Trade trade1 = new Trade(timestamp, prvask, vonask);
                                        Trade trade2 = new Trade(timestamp.AddMilliseconds(500), td.Price, vonbid);
                                        TradeEventArgs tdarg1 = new TradeEventArgs(trade1, instrument, this);
                                        TradeEventArgs tdarg2 = new TradeEventArgs(trade2, instrument, this);
                                        NewTrade(this, tdarg1);
                                        NewTrade(this, tdarg2);
                                    }
                                    else
                                    {
                                        td.Size = (int)Math.Round(size * LOTSIZE);
                                        TradeEventArgs tdarg = new TradeEventArgs(td, instrument, this);
                                        NewTrade(this, tdarg);
                                        //Trade trade = new Trade(timestamp, last, size * LOTSIZE);
                                        //tradeseries.Update(trade.DateTime, trade);
                                    }
                                }
                                else
                                {
                                    td.Size = (int)Math.Round(size * LOTSIZE);
                                    TradeEventArgs tdarg = new TradeEventArgs(td, instrument, this);
                                    NewTrade(this, tdarg);
                                }
                            }
                            else
                            {
                                td.Size = (int)Math.Round(size * LOTSIZE);
                                TradeEventArgs tdarg = new TradeEventArgs(td, instrument, this);
                                NewTrade(this, tdarg);
                            }
                        }
                        else
                        {
                            //Trade trade = new Trade(timestamp, last, size);
                            //tradeseries.Update(trade.DateTime, trade);
                            TradeEventArgs tdarg = new TradeEventArgs(td, instrument, this);
                            NewTrade(this, tdarg);
                        }
                        if (this.factory != null)
                        {
                            td.Size =(int) size;
                            this.factory.OnNewTrade(instrument, td);
                        }
                        
                        //if (instrument.SecurityType == "Stock" && statseries!=null)
                        //{
                        //    TStats stats = new TStats(timestamp, td.Price, td.Size, (double)(report.m_fAmount - prvamnt), prvbid, prvask);
                        //    statseries.Add(timestamp, stats);
                        //}
                    }
                    if (NewQuote != null && isNewQuote && instrument.SecurityType != "Index")
                    {
                        QuoteEventArgs qtarg = new QuoteEventArgs(qt, instrument, this);
                        NewQuote(this, qtarg);
                    }
                    if (NewMarketDepth != null && isNewDepth && instrument.SecurityType != "Index")
                    {
                        md = (SmartQuant.Data.MarketDepth[])mdlist.ToArray(typeof(SmartQuant.Data.MarketDepth));
                        foreach (SmartQuant.Data.MarketDepth depth in md)
                        {
                            try
                            {
                                if (depth != null)
                                {
                                    MarketDepthEventArgs mdarg = new MarketDepthEventArgs(depth, instrument, this);
                                    NewMarketDepth(this, mdarg);
                                }
                            }
                            catch(Exception e1)
                            {
                                MessageBox.Show(dm + e1.Source );
                            }
                        }
                        
                    }
                }
            }
        }

        #region IMarketDataProvider Members

        public IBarFactory BarFactory
        {
            get
            {
                return this.factory;
            }
            set
            {
                if (this.factory != null)
                {
                    this.factory.NewBar -= new BarEventHandler(this.OnNewBar);
                    this.factory.NewBarOpen -= new BarEventHandler(this.OnNewBarOpen);
                    this.factory.NewBarSlice-=new BarSliceEventHandler(this.OnNewBarSlice);
                }
                this.factory = value;
                if (this.factory != null)
                {
                    this.factory.NewBar += new BarEventHandler(this.OnNewBar);
                    this.factory.NewBarOpen += new BarEventHandler(this.OnNewBarOpen);
                    this.factory.NewBarSlice +=new BarSliceEventHandler(this.OnNewBarSlice);
                }
            }
        }

        public event MarketDataSnapshotEventHandler MarketDataSnapshot;

        public event BarEventHandler NewBar;

        public event BarEventHandler NewBarOpen;

        public event BarSliceEventHandler NewBarSlice;

        public event CorporateActionEventHandler NewCorporateAction;

        public event FundamentalEventHandler NewFundamental;

        public event BarEventHandler NewMarketBar;

        public event MarketDataEventHandler NewMarketData;

        public event MarketDataRequestRejectEventHandler MarketDataRequestReject;

        public event MarketDepthEventHandler NewMarketDepth;

        public event QuoteEventHandler NewQuote;

        public event TradeEventHandler NewTrade;

        public void SendMarketDataRequest(FIXMarketDataRequest request)
        {
            // check connection

            if (!IsConnected)
            {

                EmitError(-1, -1, "Not connected.");

                return;

            }
            switch (request.SubscriptionRequestType)
            {

                case DataManager.MARKET_DATA_SUBSCRIBE:

                    for (int i = 0; i < request.NoRelatedSym; i++)
                    {

                        FIXRelatedSymGroup group = request.GetRelatedSymGroup(i);

                        RequestSymbol(group.Symbol);
                        //Console.WriteLine(group.Symbol);
                    }

                    break;

                case DataManager.MARKET_DATA_UNSUBSCRIBE:

                    for (int i = 0; i < request.NoRelatedSym; i++)
                    {

                        FIXRelatedSymGroup group = request.GetRelatedSymGroup(i);

                        UnsubscribeSymbol(group.Symbol);

                    }

                    break;

                default:

                    throw new ArgumentException("Unknown subscription type: " + request.SubscriptionRequestType.ToString());

            }
        }

        #endregion

        #region IProvider Members

        public void Connect(int timeout)
        {
            this.Connect();
            ProviderManager.WaitConnected(this, timeout);
        }

        public void Connect()
        {
            if (!fTSdrv.Drvloaded)
            {
                //CheckSerialization();
                fTSdrv.DrvOpen ();
                isConnected = true;
                
                //if (!(DataManager.Server is FileDataServer))
                //{
                //    DataManager.Server = new FileDataServer();
                //}
            }

            if (Connected != null)

                Connected(this, new EventArgs());
        }

        public event EventHandler Connected;

        public void Disconnect()
        {
            if (fTSdrv.Drvloaded == true)
            {
                fTSdrv.DrvClose();
            }

            isConnected = false;

            if (Disconnected != null)

                Disconnected(this, new EventArgs());
        }

        public event EventHandler Disconnected;

        public event ProviderErrorEventHandler Error;

        public byte Id
        {
            get { return 90; }
        }

        public bool IsConnected
        {
            get { return isConnected; }
        }

        public string Name
        {
            get { return "SCProvider"; }
        }

        public ProviderStatus Status
        {
            get
            {

                if (!IsConnected)

                    return ProviderStatus.Disconnected;

                else

                    return ProviderStatus.Connected;

            }
        }

        public event EventHandler StatusChanged;

        public string Title
        {
            get { return "This is a SC provider."; }
        }

        public string URL
        {
            get { return String.Empty; }
        }

        #endregion
        private void RequestSymbol(string symbol)
        {

            if (!subscribedSymbols.Contains(symbol))

                subscribedSymbols.Add(symbol);

        }
        private void UnsubscribeSymbol(string symbol)
        {

            if (subscribedSymbols.Contains(symbol))

                subscribedSymbols.Remove(symbol);

            //if (subscribedSymbols.Count == 0 )
            //{
            //}

        }
        private void EmitError(int id, int code, string message)
        {

            if (Error != null)

                Error(new ProviderErrorEventArgs(new ProviderError(DateTime.Now, this, id, code, message)));

        }
        private void OnNewBar(object sender, BarEventArgs args)
        {
            if (this.NewBar != null)
            {
                this.NewBar(this, new BarEventArgs(args.Bar, args.Instrument, this));
            }
        }
        private void OnNewBarSlice(object sender, BarSliceEventArgs args)
        {
            if (this.NewBarSlice != null)
            {
                this.NewBarSlice.Invoke(this, new BarSliceEventArgs(args.BarSize, this));
            }
        }
        private void OnNewBarOpen(object sender, BarEventArgs args)
        {
            if (this.NewBarOpen != null)
            {
                this.NewBarOpen(this, new BarEventArgs(args.Bar, args.Instrument, this));
            }
        }

        #region IHistoryProvider Members

        public bool BarSupported
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        public bool DailySupported
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        public Bar[] GetBarHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, int barSize)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public Daily[] GetDailyHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, bool dividendAndSplitAdjusted)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public Quote[] GetQuoteHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public Trade[] GetTradeHistory(IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public bool QuoteSupported
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        public bool TradeSupported
        {
            get { return false              ; }
        }

        #endregion

        #region IMarketDataProvider Members



        #endregion

        #region IInstrumentProvider Members

        public event SecurityDefinitionEventHandler SecurityDefinition;

        public void SendSecurityDefinitionRequest(FIXSecurityDefinitionRequest request)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion

        #region IProvider ��Ա


        public void Shutdown()
        {
            try
            {
                fTSdrv.DrvClose();
            }
            catch
            {
            }
                 
        }

        #endregion
    }
    #region ��������ṹ



    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SCHead
    {
        // �����ͷ
        public ushort m_nType;					// ����/Ӧ�����ͣ�SC_MARKET��SC_IMCONTENT��
        public byte m_cStatus;					// ��ΪӦ���ʱ��m_cStatus=1�ɹ���m_cStatus=0ʧ��
        public int m_lIndex;					// ����Ψһ��������Ҫ��Ϊ0�������ʱ��ֵ������Ӧ�����
        // �ж��Ƿ���������е���ͬ�������ͬ�����ʾ��������������Ӧ��Ӧ���
        // ������ֵΪ0����ʾ����������������ݱ仯
    };



    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct StockInfo
    {					// ֤ȯ
        private const int STKLABEL_LEN = 10;		// �ɺ����ݳ��ȣ�Ϊ������������ͳһ����
        private const int STKNAME_LEN = 32;		// ��������

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STKLABEL_LEN)]
        public string m_szLabel;		// ��Ʊ����,��'\0'��β
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STKNAME_LEN)]
        public string m_szName;			// ��Ʊ����,��'\0'��β
        public short m_nHand;						// ÿ�ֹ���
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SCMarket
    {					//�г�����
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 3)]
        public string scmarketcode;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
        public string m_Name;				//�г�����
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 5)]
        public string m_CShortName;		//���ļ��

        public uint m_lProperty;			//�г����ԣ�δ���壩
        public uint m_lDate;				//�������ڣ�20030114��
        public short m_PeriodCount;			//����ʱ�θ���
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public short[] m_OpenTime;			//����ʱ�� 1,2,3,4,5
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public short[] m_CloseTime;			//����ʱ�� 1,2,3,4,5
        public short m_nCount;				//���г���֤ȯ����
        //public StockInfo  m_Siif;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct StockID
    {					//֤ȯ��ʶ
        public ushort m_wMarket;				//�г�����
        public short m_nIndex;				//�ڸ��г�SCMarket::m_Siff�е�ƫ��
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct RCV_NOW_STRUCTEx
    {
        public StockID m_sID;
        public uint m_time;							// �ɽ�ʱ��

        public float m_fLastClose;					// ����
        public float m_fOpen;						// ��
        public float m_fHigh;						// ���
        public float m_fLow;							// ���
        public float m_fNewPrice;					// ����
        public float m_fVolume;						// �ɽ���
        public float m_fAmount;						// �ɽ���

        public int m_lStroke;						// ����ʵ�ʳɽ�����
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fBuyPrice;					// �����1,2,3,4,5
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fBuyVolume;				// ������1,2,3,4,5
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fSellPrice;				// ������1,2,3,4,5
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fSellVolume;				// ������1,2,3,4,5
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct RCV_PANKOU_STRUCTEx
    {
        public uint m_time;							// UCT
        public float m_fHigh;						// ���
        public float m_fLow;							// ���
        public float m_fNewPrice;					// ����
        public float m_fVolume;						// �ɽ���
        public float m_fAmount;						// �ɽ���
        public int m_lStroke;						// ����ʵ�ʳɽ�����
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fBuyPrice;					// �����1,2,3,4,5
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fBuyVolume;				// ������1,2,3,4,5
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fSellPrice;				// ������1,2,3,4,5
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fSellVolume;				// ������1,2,3,4,5
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct RCV_HISTORY_STRUCTEx
    {
        public uint m_time;				//UCT
        public float m_fOpen;			//����
        public float m_fHigh;			//���
        public float m_fLow;				//���
        public float m_fClose;			//����
        public float m_fVolume;			//��
        public float m_fAmount;			//��
        public ushort m_wAdvance;			//����,��������Ч
        public ushort m_wDecline;			//����,��������Ч
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct RCV_POWER_STRUCTEx
    {
        public uint m_time;				// UCT
        public float m_fGive;			// ÿ����
        public float m_fPei;				// ÿ����
        public float m_fPeiPrice;		// ��ɼ�,���� m_fPei!=0.0f ʱ��Ч
        public float m_fProfit;			// ÿ�ɺ���

    }

    ///////////////////////////////////////////////////////////////////////////////////
    // �����ʼ����
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_InitAsk
    {							// ������ʼ�����󣬵���SCInitʱʹ�ã��޶�Ӧ���ذ�
        public SCHead m_Head;
        public UInt32 m_dwSoftware;		// ����������ʶ������������
        public Int32 m_hWnd;				// �����������ݵĴ��ھ��
        public UInt32 m_nMsg;				// �����������ݵ���Ϣ
    }


    ///////////////////////////////////////////////////////////////////////////////////
    //�������Ӧ���
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_MarketReply
    {		// ������������󼴿��յ������г���Ϣ�仯��ʱ��Ϳ��յ�
        public SCHead m_Head;
        public SCMarket m_Market;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_NowDataReply
    {	// ������������󼴿��յ��������и��£����Զ�����
        public SCHead m_Head;
        public short m_nCount;
        // public RCV_NOW_STRUCTEx m_Now;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_PankouAsk
    {				// ����һ���̿����ݣ���֧�ֵ��죬��ʷ�̿ڽ�ͨ�����ػ��
        public SCHead m_Head;
        public StockID m_sID;
        public uint m_lDate;	// FORMAT: 20010305
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_PankouReply
    {
        public SCHead m_Head;
        public StockID m_sID;
        public int m_lDate;			// FORMAT: 20010305
        public float m_fLastClose;		// ����
        public float m_fOpen;			// ��
        public int m_lCount;
        //public RCV_PANKOU_STRUCTEx  m_Data;
    }


    // ע�⣺
    // 1�����ڷ����������ã�����ֻ���յ����ĳһʱ�ε����ݣ���������ݣ�����ͨ�����ػ�á�
    // 2������K�������������ʾ����ʱ��long�ĸ�ʽΪyyyymmdd��
    // 3������K�����������Ϊ�������ʱ��long�ĸ�ʽ���������TDate�ṹ��ʾ
    //	struct TDate {		// �����ʱ���ʽ
    //		unsigned long m_Minute : 6;
    //		unsigned long m_Hour : 5;
    //		unsigned long m_Day  : 5;
    //		unsigned long m_Month : 4; 
    //		unsigned long m_Year : 12;
    //	};
    // 4������ʱ���ת�У������ṩ��������ʾ�����룬�ɲο���
    // 5����K��Ӧ��������ߺ�����ӵ�ʱ��ͳһΪuint��ʽ���Ѿ��������ںͷ�����Ϣ��
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_KLineAsk
    {
        public SCHead m_Head;
        public StockID m_sID;
        public ushort m_wDataType;		// KLINE_DAYDATA or KLINE_MIN5DATA
        public int m_tBegin;			// ��ʼʱ���λ�ã�0��ʾ�ӵ�һ�����ݿ�ʼ
        public int m_tEnd;				// ����ʱ�����������
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_KLineReply
    {
        public SCHead m_Head;
        public StockID m_sID;
        public ushort m_wDataType;		// KLINE_DAYDATA or KLINE_MIN5DATA
        public int m_lDataCount;		// m_pData����
        //public RCV_HISTORY_STRUCTEx  m_pData;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_CQAsk
    {
        public SCHead m_Head;
        public StockID m_sID;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_CQReply
    {
        public SCHead m_Head;
        public StockID m_sID;
        public short m_nCount;
        //public RCV_POWER_STRUCTEx  m_pData;			// m_head��ʹ��
    }

    //////////////////////////////////////////////////////////////////////////////////
    //////////////  ��Ϣ���׽ӿ�

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SCIMType
    {					// ��Ϣ���࣬���ش������˾���桢���ɵ�����
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 8)]
        public string m_cFlag;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 24)]
        public string m_cTitle;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_IMTypeReply
    {				// ���������Զ�����
        public SCHead m_Head;
        public byte m_cVendor;
        public byte m_cClass;
        public short m_nSize;
        //public SCIMType  m_Type;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SCIMTitle
    {
        public uint m_lID;			// ����ID
        public int m_lChkSum;		// �����ӣ�����Ӧ�����ݵ�Checksum
        public uint m_lDate;			// yyyymmdd
        public uint m_lTime;			// hhmmss
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 8)]
        public string m_cFlag;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 9)]
        public string m_cMainType;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 17)]
        public string m_cSubtype;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
        public string m_cTitle;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 9)]
        public string m_szLabel;	// ��Ʊ����,��'\0'��β
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SCIMTitleID
    {
        public uint m_lID;			// ����ID
        public int m_lChkSum;		// �����ӣ�����Ӧ�����ݵ�Checksum
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_IMTitleAsk
    {				// ����ĳ��ʱ�������Ϣ���ױ���
        public SCHead m_Head;
        public byte m_cClass;
        public StockID m_sID;			//���ڸ�����Ѷ����������F10ʹ��m_sID������������ֻʹ��
        //���е��г������š��ۺ���Ѷ��ʹ������ֶ�
        public int m_lStartDate;	//���š��ۺ���Ѷ������������ֻʹ��m_lStartDate��m_lEndDate��ʹ��
        public int m_lEndDate;		//������Ѷʹ��m_lStartDate��m_lEndDate��
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_IMTitleReply
    {
        public SCHead m_Head;
        public byte m_cVendor;		// Ӧ����г���
        public byte m_cClass;
        public StockID m_sID;				//���ڸ�����Ѷ����������F10��ʹ��m_sID,
        public short m_nSize;			// �������
        //public SCIMTitle  m_IMTitle;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_IMDataAsk
    {					// ��Ϣ������������һ�ο����������������
        public SCHead m_Head;
        //	char			m_cVendor;			// �����û�г��̴���
        public byte m_cClass;
        public StockID m_sID;				//���ڸ�����Ѷ���������ϡ�������Ϣ����ʹ��m_sID,
        public short m_nSize;			// ����ID����
        public int m_lDate;			//���ڣ����š����������桢�ۺ���Ѷ��Ҫ��һ��ֻ����һ������
        //public SCIMTitleID  m_ID;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SCIMData
    {						// ��Ϣ��������
        public SCIMTitle m_IMTitle;
        public uint m_lDataLength;
        //public byte [] m_cData;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_IMDataReply
    {					// ��Ϣ��������Ӧ��һ�οɷ��ض�����������
        public SCHead m_Head;
        public byte m_cVendor;
        public byte m_cClass;
        public StockID m_sID;				//���ڸ�����Ѷ����������F10ʹ��m_sID,
        public int m_lDate;			//�������š��ۺ���Ѷ���ƾ����š�ȯ����Ϣʹ��m_lDate
        public short m_nSize;
        //public SCIMData  m_Data;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct IMTitleEx
    {
        private const int TITLE_LEN = 64;	       // ��Ϣ���ױ��ⳤ��
        public uint m_lOffset;
        public uint m_lDataLength;
        public uint m_time;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = TITLE_LEN)]
        public string m_cCaption;
    }


    #region  ����������������ز���֮�󣬻��Զ��յ���������������������������ָ�����ݡ�
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_Download_detail_Ex
    {							// F10�����������桢���š��ۺ���Ѷ����
        public byte m_cClass;		// ���
        public IMTitleEx m_Title;		// ���⣬ʵ����������m_lCount�������m_cData�ݴ˺���
        public byte m_cData;		// ʵ��λ����m_Title[m_lCount]֮��
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_Download
    {
        // �������ؽӿ�
        public SCHead m_Head;			// m_head�н�m_nType��Ч
        public StockID m_sID;
        public int m_lCount;		// // m_KLine,m_power,m_Trace,m_Title�ĸ���

    }


    #endregion
    public enum TSCInfo
    {
        INFO_VERSION = 1,
        INFO_USERNAME = 2,
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct TInfoHead
    {
        public TSCInfo m_InfoType;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct TRInfoVersion
    {
        public TSCInfo m_InfoType;
        public int m_lVersion;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct TRInfoUsername
    {
        public TSCInfo m_InfoType;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
        public string m_UserName;
    }

    public struct TDate
    {
        public uint m_Minute;
        public uint m_Hour;
        public uint m_Day;
        public uint m_Month;
        public uint m_Year;
    }
    public enum SCDataType
    {
        bi5Minutes = 0,//�����
        biDaily = 1,//����
        biTicks = 2,//�ֱ�
        biData = 3, //��Ȩ
    }
    #endregion
    public delegate void SC_NOWDATAEventHandler(SCRTcontrol sender, string Symbol, RCV_NOW_STRUCTEx e);
    //public delegate void SC_PANKOU_EventHandler(SCRTcontrol sender, int replyNo, List<RCV_PANKOU_STRUCTEx> e);
    public delegate void SC_PANKOU_EventHandler(SCRTcontrol sender, string Symbol, List<RCV_PANKOU_STRUCTEx> e);
    public delegate void SC_KLINE_5MinOrDay_EventHandler(SCRTcontrol sender, int replyNo, List<RCV_HISTORY_STRUCTEx> e);
    public delegate void SC_Symbols_EventHandler(SCRTcontrol sender,string Exchange,ArrayList list);
    public class SCTickHistory
    {
        private string symbol;
        private List<RCV_PANKOU_STRUCTEx> ticks;
        public string Symbol
        {
            get
            {
                return symbol;
            }
        }
        public List<RCV_PANKOU_STRUCTEx> Records
        {
            get
            {
                return ticks;
            }
        }
        public SCTickHistory(string Symbol, List<RCV_PANKOU_STRUCTEx> TickList)
        {
            symbol = Symbol;
            ticks = TickList;
        }
    }
    [Serializable]
    public class TStats : SmartQuant.Data.IDataObject, ISeriesObject, ICloneable
    {
        private int LOTSIZE = 100;
        private double lastprice;
        private int lastsize;
        private double lastamnt;
        private double pbid;
        private double pask;
        private DateTime ttime;
        private byte pID;
        private double vonbid;
        private double vonask;
        private double amntonbid;
        private double amntonask;
        private short flag;
        [View]
        public int VolOnBid
        {
            get
            {
                return (int)vonbid;
            }
            set
            {
                vonbid = value;
            }
        }
        [View]
        public int VolOnAsk
        {
            get
            {
                return (int)vonask;
            }
            set
            {
                vonask = value;
            }
        }
        [View]
        public double AmntOnBid
        {
            get
            {
                return amntonbid;
            }
            set
            {
                amntonbid = value;
            }
        }
        [View]
        public double AmntOnAsk
        {
            get
            {
                return amntonask;
            }
            set
            {
                amntonask = value;
            }
        }
        [View]
        public short TFlag
        {
            get
            {
                return flag;
            }
            set
            {
                flag = value;
            }
        }
        public DateTime DateTime
        {
            get
            {
                return ttime;
            }
            set
            {
                ttime = value;
            }
        }
        public byte ProviderId
        {
            get
            {
                return pID;
            }
            set
            {
                pID = value;
            }
        }

        public TStats(DateTime datetime, double last, int size, double amount, double prvbid, double prvask)
        {
            pID = 0;
            ttime = datetime;
            lastprice = last;
            lastsize = size;
            lastamnt = amount;
            pbid = prvbid;
            pask = prvask;
            vonbid = prvask - prvbid != 0 ? (prvask * size * LOTSIZE - amount) / (prvask - prvbid) : size / 2;
            vonask = size * LOTSIZE - vonbid;

            if (vonbid >= 1)
            {
                if (vonbid > size * LOTSIZE)//����1
                {
                    vonbid = size * LOTSIZE;
                    vonask = 0;
                    amntonask = 0;
                }
                amntonbid = Math.Round(vonbid * prvbid, 1);
            }
            //else if (vonbid < 0)
            //{
            //    vonbid = 0;
            //}
            if (vonask >= 1)
            {
                if (vonask > size * LOTSIZE)//����1
                {
                    vonask = size * LOTSIZE;
                    vonbid = 0;
                    amntonbid = 0;
                }
                amntonask = Math.Round(vonask * prvask, 1);
            }
            //else if (vonask < 0)
            //{
            //    vonask = 0;
            //}

        }
        public TStats(TStats stats)
            : this(stats.ttime, stats.lastprice, stats.lastsize, stats.lastamnt, stats.pbid, stats.pask)
        {
        }
        public TStats()
        {
            ttime = DateTime.MinValue;
            //vonbid = -1;
        }
        public virtual object Clone()
        {
            return new TStats(this);
        }

        public virtual ISeriesObject NewInstance()
        {
            return new TStats();
        }
        public virtual void WriteTo(System.IO.BinaryWriter writer)
        {
            //base.WriteTo(writer);
            writer.Write(ttime.Ticks);
            writer.Write(vonbid);
            writer.Write(vonask);
            writer.Write(amntonbid);
            writer.Write(amntonask);
            writer.Write(flag);
        }
        public virtual void ReadFrom(System.IO.BinaryReader reader)
        {
            //base.ReadFrom(reader);
            ttime = new DateTime(reader.ReadInt64());
            vonbid = reader.ReadInt32();
            vonask = reader.ReadInt32();
            amntonbid = reader.ReadDouble();
            amntonask = reader.ReadDouble();
            flag = reader.ReadInt16();
        }
        public override string ToString()
        {
            return string.Format("{0} price={1} size={2}", this.ttime, this.lastprice, this.lastsize);
        }


    }



 
}
