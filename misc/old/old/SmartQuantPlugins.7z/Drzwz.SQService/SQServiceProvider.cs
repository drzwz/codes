﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Threading;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Drawing.Design;
using System.ServiceModel;
using System.ServiceModel.Description;

using SmartQuant;
using SmartQuant.Data;
using SmartQuant.Series;
using SmartQuant.Providers;
using SmartQuant.Instruments;

namespace Drzwz
{
    public class SQServiceProvider : IProvider, IHistoryProvider
    {

        public SQServiceProvider()
        {
            ProviderManager.Add(this);
            if (this.autoStartup)
                this.Connect();
        }
        #region 提供服务的方法
        private bool autoStartup = false;
        [Category("设置"), Description("true-自动启动；false-不启动。") ]
        public bool AutoStartup
        {
            get { return this.autoStartup; }
            set
            {
                this.autoStartup = value;
            }
        }
        private ServiceHost serviceHost = null;
        private string baseAddressUri = "http://localhost:3009/SQ";
        string pipeaddress = "net.pipe://localhost/SQService";
        [Category("信息")]
        public bool IsStarted
        {
            get
            {
                if (this.serviceHost == null) return false;
                return (this.serviceHost.State == CommunicationState.Opened);
            }
        }
        [Category("信息"), Description("Host状态，点击刷新。")]
        public CommunicationState HostState
        {
            get { return serviceHost.State; }
        }
        [Category("设置"), Description("")]
        public string BaseAddress
        {
            get
            {
                return this.baseAddressUri;
            }
            set
            {
                this.baseAddressUri = value;
            }
        }
        [Category("设置"), Description("")]
        public string PipeAddress
        {
            get
            {
                return this.pipeaddress;
            }
            set
            {
                this.pipeaddress = value;
            }
        }
        public void Restart()
        {
            this.Stop();
            this.Start();
        }

        public void Start()
        {
            try
            {
                //Console.WriteLine("CreateServiceHost...");
                Uri baseAddress = new Uri(this.baseAddressUri);
                serviceHost = new ServiceHost(typeof(SQService), baseAddress);
                NetNamedPipeBinding binding = new NetNamedPipeBinding(NetNamedPipeSecurityMode.None);
                binding.MaxReceivedMessageSize = 6553600;
                serviceHost.AddServiceEndpoint(typeof(ISQService), binding, pipeaddress);
                ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
                smb.HttpGetEnabled = true;
                serviceHost.Description.Behaviors.Add(smb);
                serviceHost.Open();
                if (this.Started != null)
                {
                    this.Started(this, EventArgs.Empty);
                }
            }
            catch (CommunicationException exception)
            {
                serviceHost.Abort();
                if (Trace.IsLevelEnabled(TraceLevel.Error))
                {
                    Trace.WriteLine(exception.ToString());
                }
                if (Environment.UserInteractive)
                {
                    MessageBox.Show(null, "启动SQService时出错：" + Environment.NewLine + Environment.NewLine + "Please check connector's settings like TCP port, network address, etc and try again." + Environment.NewLine + Environment.NewLine + "See log file for details.", "Cannot start service.", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
            }


        }

        public event EventHandler Started;


        public void Stop()
        {
            if (this.IsStarted)
            {
                serviceHost.Close();

                if (this.Stopped != null)
                {
                    this.Stopped(this, EventArgs.Empty);
                }
            }
        }

        public event EventHandler Stopped;

        #endregion

        #region IProvider 成员
        private bool isConnected = false;

        public void Connect(int timeout)
        {
            this.Connect();
            ProviderManager.WaitConnected(this, timeout);
        }
        public void Connect()
        {
            this.Start();
            isConnected = true;
            Console.WriteLine("{0} {1} Connected!",DateTime.Now,this.Name);
            if (Connected != null)
                Connected(this, new EventArgs());
            //Thread th = new Thread(new ThreadStart(this.doWork));
            //th.Start();
        }
        public event EventHandler Connected;
        public void Disconnect()
        {
            try
            {
                this.Stop();
                Console.WriteLine("{0} {1} Disconnected!", DateTime.Now,this.Name);
                isConnected = false;
                if (Disconnected != null)
                    Disconnected(this, new EventArgs());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Disconnect：" + ex.Message);
            }

        }

        public event EventHandler Disconnected;

        public event ProviderErrorEventHandler Error;
        [Category("信息")]
        public byte Id
        {
            get { return 115; }
        }
        [Category("信息")]
        public bool IsConnected
        {
            get { return isConnected; }
        }
        [Category("信息")]
        public string Name
        {
            get { return "SQService"; }
        }
        [Category("信息")]
        public string Title
        {
            get { return "数据服务。"; }
        }
        [Category("信息")]
        public string URL
        {
            get { return String.Empty; }
        }
        public void Shutdown()
        {
            try
            {
                this.Stop();
            }
            catch
            {

            }
        }
        [Category("信息")]
        public ProviderStatus Status
        {
            get
            {
                if (!IsConnected)
                    return ProviderStatus.Disconnected;
                else
                    return ProviderStatus.Connected;
            }
        }

        public event EventHandler StatusChanged;

        #endregion

        #region IHistoryProvider 成员
        [Category("信息")]
        public bool BarSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool DailySupported
        {
            get { return false; }
        }

        public Bar[] GetBarHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, int barSize)
        {
            throw new NotImplementedException();
        }

        public Daily[] GetDailyHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, bool dividendAndSplitAdjusted)
        {
            throw new NotImplementedException();
        }

        public Quote[] GetQuoteHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }

        public Trade[] GetTradeHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }
        [Category("信息")]
        public bool QuoteSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool TradeSupported
        {
            get { return false; }
        }

        #endregion
    }
}
