﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Windows.Forms;

using SmartQuant;
using SmartQuant.Data;
using SmartQuant.Charting;
using SmartQuant.FIX;
using SmartQuant.Instruments;
using SmartQuant.Series;
using SmartQuant.DataCenterLib;

namespace Drzwz.DC
{
    public class DCServiceConnector:IConnector 
    {
        private ConnectorStartupType startupType = ConnectorStartupType.Automatic;
        private ServiceHost serviceHost=null;
        private string baseAddressUri = "http://localhost:3009/DC";
        string  pipeaddress = "net.pipe://localhost/DC/DCService";
        public DCServiceConnector()
        {
            ConnectorManager.Add(this);
        }
        #region IConnector 成员
        [Category("信息")]
        public string Name
        {
            get { return "DCService"; }
        }
        [Category("信息")]
        public string Description
        {
            get { return "提供WCF服务的DC Connector。"; }
        }
        [Category("信息")]
        public bool IsStarted
        {
            get
            {
                if (this.serviceHost == null) return false;
                return (this.serviceHost.State == CommunicationState.Opened ); 
            }
        }
        [Category("信息"), Description("Host状态，点击刷新。")]
        public CommunicationState HostState
        {
            get { return serviceHost.State; }
        }
        [Category("设置"), Description("启动类型：自动/手动"), DefaultValue(0)]
        public ConnectorStartupType StartupType
        {
            get
            {
                return this.startupType;
            }
            set
            {
                this.startupType = value;
            }
        }
        [Category("设置"), Description("")]
        public string BaseAddress
        {
            get
            {
                return this.baseAddressUri;
            }
            set
            {
                this.baseAddressUri = value;
            }
        }
        [Category("设置"), Description("")]
        public string PipeAddress
        {
            get
            {
                return this.pipeaddress;
            }
            set
            {
                this.pipeaddress = value;
            }
        }
        public void Restart()
        {
            this.Stop();
            this.Start();
        }

        public void Start()
        {
                try
                {
                    //Console.WriteLine("CreateServiceHost...");
                    Uri baseAddress = new Uri(this.baseAddressUri);
                    serviceHost = new ServiceHost(typeof(DCService), baseAddress);
                    NetNamedPipeBinding binding = new NetNamedPipeBinding(NetNamedPipeSecurityMode.None);
                    binding.MaxReceivedMessageSize = 6553600;
                    serviceHost.AddServiceEndpoint(typeof(IDCService), binding, pipeaddress);
                    ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
                    smb.HttpGetEnabled = true;
                    serviceHost.Description.Behaviors.Add(smb);
                    serviceHost.Open();
                    if (this.Started != null)
                    {
                        this.Started(this, EventArgs.Empty);
                    }
                }
                catch (CommunicationException exception)
                {
                    serviceHost.Abort();
                    if (Trace.IsLevelEnabled(TraceLevel.Error))
                    {
                        Trace.WriteLine(exception.ToString());
                    }
                    if (Environment.UserInteractive)
                    {
                        MessageBox.Show(null, "启动DCServiceConnector时出错：" + Environment.NewLine + Environment.NewLine + "Please check connector's settings like TCP port, network address, etc and try again." + Environment.NewLine + Environment.NewLine + "See log file for details.", "Cannot start connector.", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }


        }

        public event EventHandler Started;


        public void Stop()
        {
            if (this.IsStarted)
            {
                serviceHost.Close();
                
                if (this.Stopped != null)
                {
                    this.Stopped(this, EventArgs.Empty);
                }
            }
        }

        public event EventHandler Stopped;

        #endregion
    }


}
