﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Windows.Forms;
using System.Runtime.Serialization;

using SmartQuant;
using SmartQuant.Data;
using SmartQuant.Charting;
using SmartQuant.FIX;
using SmartQuant.Instruments;
using SmartQuant.Series;
using SmartQuant.DataCenterLib;

namespace Drzwz.DC
{

    [ServiceContract]
    public interface IDCService
    {
        [OperationContract]
        bool SetSymbol(string symbol, string securityName, string securityType, string securityExchange);//zzz
        [OperationContract]
        bool SetDailyList(string symbol, List<Daily> list);//zzz
        [OperationContract]
        bool SetPriceFactorList(string symbol, List<PriceFactor> list);//zzz
        [OperationContract]
        bool SetBarList(string symbol, List<Bar> list);//zzz
        [OperationContract]
        bool SetQuoteList(string symbol, List<Quote> list);//zzz
        [OperationContract]
        bool SetTradeList(string symbol, List<Trade> list);//zzz


        [OperationContract]
        DataSeriesInfo GetSeriesInfo(string series);//zzz
        [OperationContract]
        List<DataSeriesInfo> GetDataSeriesInfo();
        [OperationContract]
        IDataSeriesEnumerator GetEnumerator(string series, DateTime datetime1, DateTime datetime2);
        [OperationContract]
        ArrayList GetSecurityDefinitionList(string symbol, string securityType, string securityExchange);
        [OperationContract]
        List<string> GetSymbolList(string symbol, string securityType, string securityExchange);//zzz
        [OperationContract]
        SortedList<string, string> GetSecurityNameList(string symbol, string securityType, string securityExchange); //zzz
        [OperationContract]
        SortedList<string, string> GetSecurityTypeList(string symbol, string securityType, string securityExchange); //zzz
        [OperationContract]
        SortedList<DateTime, double> GetPriceFactorList(string symbol);//zzz
        [OperationContract]
        List<Daily> GetDailyList(string symbol, DateTime datetime1, DateTime datetime2);
        [OperationContract]
        List<Daily> GetDailyAdjList(string symbol, DateTime datetime1, DateTime datetime2);//zzz
        [OperationContract]
        List<Bar> GetBarList(string symbol, DateTime datetime1, DateTime datetime2, int barSize);
        [OperationContract]
        List<Quote> GetQuoteList(string symbol, DateTime datetime1, DateTime datetime2);
        [OperationContract]
        List<Trade> GetTradeList(string symbol, DateTime datetime1, DateTime datetime2);

    }
    [ServiceBehavior(MaxItemsInObjectGraph=6553600)]
    public class DCService : IDCService
    {
        public bool SetSymbol(string symbol, string securityName, string securityType, string securityExchange)
        {
            if (InstrumentManager.Instruments[symbol] == null)
            {
                Instrument instrument;
                instrument = new Instrument(symbol, securityType);
                instrument.SecurityDesc = securityName;
                instrument.SecurityExchange = securityExchange;
                instrument.Save();
                //Console.WriteLine( string.Format("添加Symbol:{0}",symbol) );
            }
            return true;
        }
        public bool SetDailyList(string symbol, List<Daily> list)
        {
            Instrument instrument = InstrumentManager.Instruments[symbol];
            if (instrument != null)
            {
                if (list.Count > 0)
                {
                    try
                    {
                        foreach (Daily d in list)
                            instrument.Add(d);
                        //Console.WriteLine(string.Format("添加Daily:{0},{1}", symbol,list.Count));
                    }
                    catch
                    {
                        return false;
                    }
                }

            }
            return true;
        }
        public bool SetPriceFactorList(string symbol, List<PriceFactor> list)
        {
            Instrument instrument = InstrumentManager.Instruments[symbol];
            if (instrument != null)
            {
                if (list.Count > 0)
                {
                    try
                    {
                        IDataSeries ids = instrument.GetDataSeries("PriceFactor");
                        if (ids == null) ids = instrument.AddDataSeries("PriceFactor");
                        foreach (PriceFactor f in list)
                        {
                            if (ids.Count > 0) { if (f.DateTime <= ids.LastDateTime) continue; }
                            ids.Add(f.DateTime, f);
                        }
                        //Console.WriteLine(string.Format("添加PriceFactor:{0},After {1}", symbol, ids.LastDateTime));
                    }
                    catch
                    {
                        return false;
                    }
                }

            }
            return true;
        }
        public bool SetBarList(string symbol, List<Bar> list)
        {
            Instrument instrument = InstrumentManager.Instruments[symbol];
            if (instrument != null)
            {
                if (list.Count > 0)
                {
                    try
                    {
                        foreach (Bar d in list)
                            instrument.Add(d);
                        //Console.WriteLine(string.Format("添加Bar:{0},{1}", symbol, list.Count));
                    }
                    catch
                    {
                        return false;
                    }
                }

            }
            return true;
        }
        public bool SetQuoteList(string symbol, List<Quote> list)
        {
            Instrument instrument = InstrumentManager.Instruments[symbol];
            if (instrument != null)
            {
                if (list.Count > 0)
                {
                    try
                    {
                        foreach (Quote d in list)
                            instrument.Add(d);
                        //Console.WriteLine(string.Format("添加Quote:{0},{1}", symbol, list.Count));
                    }
                    catch
                    {
                        return false;
                    }
                }

            }
            return true;
        }
        public bool SetTradeList(string symbol, List<Trade> list)
        {
            Instrument instrument = InstrumentManager.Instruments[symbol];
            if (instrument != null)
            {
                if (list.Count > 0)
                {
                    try
                    {
                        foreach (Trade d in list)
                            instrument.Add(d);
                        //Console.WriteLine(string.Format("添加Trade:{0},{1}", symbol, list.Count));
                    }
                    catch
                    {
                        return false;
                    }
                }

            }
            return true;
        }
        public DataSeriesInfo GetSeriesInfo(string series)
        {

            DataSeriesInfo info = null;
            IDataSeries s = DataManager.Server.GetDataSeries(series);
            if (s == null)
            {
                //System.Windows.Forms.MessageBox.Show("s==null");
                return null;
            }
            if (s.Count == 0)
            {
                info = new DataSeriesInfo(s.Name, s.Description);
            }
            else
            {
                info = new DataSeriesInfo(s.Name, s.Description, s.Count, s.FirstDateTime, s.LastDateTime);
            }
            return info;
        }
        public IDataSeriesEnumerator GetEnumerator(string series, DateTime datetime1, DateTime datetime2)
        {

            return new DataSeriesEnumerator(series, datetime1, datetime2);
        }
        public List<DataSeriesInfo> GetDataSeriesInfo()
        {

            List<DataSeriesInfo> list = new List<DataSeriesInfo>();
            foreach (IDataSeries series in DataManager.Server.GetDataSeries())
            {
                DataSeriesInfo info = null;
                if (series.Count == 0)
                {
                    info = new DataSeriesInfo(series.Name, series.Description);
                }
                else
                {
                    info = new DataSeriesInfo(series.Name, series.Description, series.Count, series.FirstDateTime, series.LastDateTime);
                }
                list.Add(info);
            }
            return (list);
        }
        public ArrayList GetSecurityDefinitionList(string symbol, string securityType, string securityExchange)
        {

            ArrayList list = new ArrayList();
            foreach (Instrument instrument in InstrumentManager.Instruments)
            {
                if ((((symbol != null) && (instrument.Symbol != symbol)) || ((securityType != null) && (instrument.SecurityType != securityType))) || ((securityExchange != null) && (instrument.SecurityExchange != securityExchange)))
                {
                    continue;
                }
                Hashtable hashtable = new Hashtable();
                foreach (FIXField field in instrument.Fields.Values)
                {
                    hashtable.Add(field.Tag, field.ToInvariantString());
                }
                list.Add(hashtable);
            }
            return list;
        }
        public List<string> GetSymbolList(string symbol, string securityType, string securityExchange)
        {

            List<string> list = new List<string>();
            foreach (Instrument instrument in InstrumentManager.Instruments)
            {
                if ((((symbol != null) && (instrument.Symbol != symbol)) || ((securityType != null) && (instrument.SecurityType != securityType))) || ((securityExchange != null) && (instrument.SecurityExchange != securityExchange)))
                {
                    continue;
                }
                list.Add(instrument.Symbol);
            }
            return list;
        }
        public SortedList<string, string> GetSecurityTypeList(string symbol, string securityType, string securityExchange)
        {

            SortedList<string, string> list = new SortedList<string, string>();
            foreach (Instrument instrument in InstrumentManager.Instruments)
            {
                if ((((symbol != null) && (instrument.Symbol != symbol)) || ((securityType != null) && (instrument.SecurityType != securityType))) || ((securityExchange != null) && (instrument.SecurityExchange != securityExchange)))
                {
                    continue;
                }
                if (!list.ContainsKey(instrument.Symbol)) list.Add(instrument.Symbol, instrument.SecurityType);
            }
            return list;
        }
        public SortedList<string, string> GetSecurityNameList(string symbol, string securityType, string securityExchange)
        {
            SortedList<string, string> list = new SortedList<string, string>();
            foreach (Instrument instrument in InstrumentManager.Instruments)
            {
                if ((((symbol != null) && (instrument.Symbol != symbol)) || ((securityType != null) && (instrument.SecurityType != securityType))) || ((securityExchange != null) && (instrument.SecurityExchange != securityExchange)))
                {
                    continue;
                }
                if (!list.ContainsKey(instrument.Symbol)) list.Add(instrument.Symbol, instrument.SecurityDesc);
            }
            return list;
        }
        public List<Daily> GetDailyList(string symbol, DateTime datetime1, DateTime datetime2)
        {
            //Console.WriteLine("GetDailyList({0},{1},{2})", symbol,datetime1,datetime2);
            List<Daily> list = new List<Daily>();
            //Daily daily = new Daily(new DateTime(2008,2,18),5,8,2,6,100);
            //list.Add(daily);
            Instrument instrument = InstrumentManager.Instruments[symbol];
            if (instrument != null)
            {
                DailySeries dailySeries = instrument.GetDailySeries(datetime1, datetime2);
                if (dailySeries != null)
                {
                    //foreach (Daily daily in dailySeries)
                    //{
                    //    list.Add(daily);
                    //}
                    for (int i = 0; i < dailySeries.Count; i++)
                    {
                        //Console.WriteLine("{0} {1}", dailySeries[i].DateTime, dailySeries[i].Close);
                        list.Add(dailySeries[i]);
                    }
                    //Console.WriteLine("Counts:{0}", dailySeries.Count);
                }
            }
            return (list);
        }
        public SortedList<DateTime, double> GetPriceFactorList(string symbol)
        {

            SortedList<DateTime, double> list = new SortedList<DateTime, double>();
            Instrument instrument = InstrumentManager.Instruments[symbol];
            if (instrument != null)
            {
                IDataSeries series = instrument.GetDataSeries("PriceFactor");
                if (series != null)
                {
                    foreach (PriceFactor bar in series)
                    {
                        if (!list.ContainsKey(bar.DateTime)) list.Add(bar.DateTime, bar.Factor);
                    }
                }
            }
            return list;
        }
        public List<Daily> GetDailyAdjList(string symbol, DateTime datetime1, DateTime datetime2)
        {
            //zzz 获取向前复权Daily
            List<Daily> list = new List<Daily>();
            Instrument instrument = InstrumentManager.Instruments[symbol];
            if (instrument != null)
            {

                DailySeries dailySeries = instrument.GetDailySeries(datetime1, datetime2);
                if (dailySeries != null)
                {
                    SortedList<DateTime, double> factorList = GetPriceFactorList(symbol);
                    if (factorList.Count > 0)
                    {
                        double fqyz = 1.0;//当前复权因子
                        double maxfqyz = 1.0;//最大复权因子
                        int fqyzIndex = 0;
                        maxfqyz = factorList.Values[factorList.Keys.Count - 1];
                        factorList.Add(DateTime.MaxValue, maxfqyz);

                        foreach (Daily daily in dailySeries)
                        {
                            #region 复权计算
                            DateTime date = daily.DateTime;
                            double kp = daily.Open;
                            double zg = daily.High;
                            double zd = daily.Low;
                            double sp = daily.Close;

                            if (date < factorList.Keys[0])
                            {
                                fqyz = 1 / maxfqyz;//前复权因子
                                kp = daily.Open * fqyz;
                                zg = daily.High * fqyz;
                                zd = daily.Low * fqyz;
                                sp = daily.Close * fqyz;
                                fqyzIndex = 0;
                            }
                            else
                            {
                                for (int j = fqyzIndex; j < factorList.Count - 1; j++)
                                {
                                    if (factorList.Keys[j] <= date && date < factorList.Keys[j + 1])
                                    {
                                        fqyz = factorList.Values[j] / maxfqyz; //前复权因子
                                        kp = daily.Open * fqyz;
                                        zg = daily.High * fqyz;
                                        zd = daily.Low * fqyz;
                                        sp = daily.Close * fqyz;
                                        fqyzIndex = j;
                                        break;
                                    }

                                }
                            }

                            daily.Open = kp;
                            daily.High = zg;
                            daily.Low = zd;
                            daily.Close = sp;
                            #endregion
                            list.Add(daily);
                        }
                    }
                    else
                    {
                        foreach (Daily daily in dailySeries)
                        {
                            list.Add(daily);
                        }
                    }
                }
            }
            return (list);
        }
        public List<Bar> GetBarList(string symbol, DateTime datetime1, DateTime datetime2, int barSize)
        {
            List<Bar> list = new List<Bar>();
            Instrument instrument = InstrumentManager.Instruments[symbol];
            if (instrument != null)
            {
                BarSeries series = instrument.GetBarSeries(datetime1, datetime2, BarType.Time, (long)barSize);
                if (series != null)
                {
                    foreach (Bar bar in series)
                    {
                        list.Add(bar);
                    }
                }
            }
            return (list);
        }
        public List<Quote> GetQuoteList(string symbol, DateTime datetime1, DateTime datetime2)
        {
            List<Quote> list = new List<Quote>();
            Instrument instrument = InstrumentManager.Instruments[symbol];
            if (instrument != null)
            {
                QuoteArray quoteArray = instrument.GetQuoteArray(datetime1, datetime2);
                if (quoteArray != null)
                {
                    foreach (Quote quote in quoteArray)
                    {
                        list.Add(quote);
                    }
                }
            }
            return (list);
        }
        public List<Trade> GetTradeList(string symbol, DateTime datetime1, DateTime datetime2)
        {

            List<Trade> list = new List<Trade>();
            Instrument instrument = InstrumentManager.Instruments[symbol];
            if (instrument != null)
            {
                TradeArray tradeArray = instrument.GetTradeArray(datetime1, datetime2);
                if (tradeArray != null)
                {
                    foreach (Trade trade in tradeArray)
                    {
                        list.Add(trade);
                    }
                }
            }
            return (list);
        }

    }
    internal class DataSeriesEnumerator : IDataSeriesEnumerator
    {
        private int currentIndex;
        private IDataSeries dataSeries;
        private int firstIndex;
        private int lastIndex;

        internal DataSeriesEnumerator(string series, DateTime datetime1, DateTime datetime2)
        {
            this.dataSeries = DataManager.Server.GetDataSeries(series);
            if (this.dataSeries != null)
            {
                this.firstIndex = this.dataSeries.IndexOf(datetime1, SearchOption.Next);
                this.lastIndex = this.dataSeries.IndexOf(datetime2, SearchOption.Exact);
                if (this.lastIndex == -1)
                {
                    this.lastIndex = this.dataSeries.IndexOf(datetime2, SearchOption.Prev);
                }
                else
                {
                    this.lastIndex--;
                }
                if (this.firstIndex > this.lastIndex)
                {
                    this.firstIndex = -1;
                    this.lastIndex = -1;
                }
                this.currentIndex = this.firstIndex;
            }
            else
            {
                this.firstIndex = -1;
                this.lastIndex = -1;
                this.currentIndex = -1;
            }
        }

        public SmartQuant.Data.IDataObject[] GetNextObjects(int count)
        {
            ArrayList list = new ArrayList();
            while (count-- > 0)
            {
                if (this.currentIndex > this.lastIndex)
                {
                    break;
                }
                list.Add(this.dataSeries[this.currentIndex]);
                this.currentIndex++;
            }
            return (SmartQuant.Data.IDataObject[])list.ToArray(typeof(SmartQuant.Data.IDataObject));
        }

        public int Count
        {
            get
            {
                if (this.firstIndex != -1)
                {
                    return ((this.lastIndex - this.firstIndex) + 1);
                }
                return 0;
            }
        }
    }

}
