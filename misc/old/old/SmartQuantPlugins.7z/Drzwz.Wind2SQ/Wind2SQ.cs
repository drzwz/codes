﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Threading;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Drawing.Design;
using SmartQuant;
using SmartQuant.Data;
using SmartQuant.Series;
using SmartQuant.Providers;
using SmartQuant.Instruments;

namespace Drzwz
{
    public class Wind2SQ : IProvider, IHistoryProvider
    {

        public Wind2SQ()
        {
            ProviderManager.Add(this);
        }
        #region 导入数据的方法
        private string windPath = @"D:\Wind\Wind.NET.Client\WindNET\";
        private string symbolRegex = @"(\d{6}\.S[HZ])";
        private bool autoImport = true;
        [Category("设置"), Description("Wind.NET安装目录"), DefaultValue(@"D:\Wind\Wind.NET.Client\WindNET\"),
        Editor(typeof(System.Windows.Forms.Design.FolderNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string WindPath
        {
            get { return this.windPath; }
            set
            {
                this.windPath = value.Trim();
            }
        }
        [Category("设置"), Description("要导入数据的代码的正则表达式；若为空则导入WIND数据目录下所有代码的数据。"), DefaultValue(@"(\d{6}\.S[HZ])")]
        public string SymbolRegex
        {
            get { return this.symbolRegex; }
            set
            {
                this.symbolRegex = value.Trim();
            }
        }
        [Category("设置"), Description("true-连接后自动导入；false-连接后不导入，若运行中，则中断导入。"), DefaultValue("")]
        public bool AutoImport
        {
            get { return this.autoImport; }
            set
            {
                this.autoImport = value;
            }
        }
        private void doWork()
        {
            try
            {
                WindData wd = new WindData();
                wd.IncludeZeroVolume = false;//不含停牌数据
                wd.HistoryDataType = 0;//0--原始数据
                List<Daily> lst;
                SortedList<string, string> nameList = wd.GetSecurityNames();
                DailySeries ds; IDataSeries ids;
                Instrument instrument;
                List<string> symbolList;
                symbolList = wd.GetStocklist(this.symbolRegex);//代码REGEX
                int i = 0;
                DateTime dt1, maxDateFqyz;
                //string securitytype;
                StringBuilder sb = new StringBuilder(); sb.AppendLine();
                Console.WriteLine("{0} 开始导入数据...", DateTime.Now);
                int num = 0;
                foreach (string symbol in symbolList)
                {
                    Application.DoEvents();
                    if (!this.autoImport)
                    {
                        Console.WriteLine("{0} 处理了{1}个代码后，用户中断操作(AutoImport被设为False)。", DateTime.Now, num);
                        break;
                    }
                    //securitytype = Drzwz.SQCommon.GetSecurityType(symbol);
                    //Console.WriteLine("{0} 正在读取{1}...", DateTime.Now, symbol);

                    
                    //判断该symbol是否已存在
                    instrument = InstrumentManager.Instruments[symbol];
                    if (instrument == null)
                    {
                        instrument = new Instrument(symbol, "Z");
                        instrument.SecurityExchange = symbol.Substring(symbol.LastIndexOf(".") + 1, symbol.Length - symbol.LastIndexOf(".") - 1); ;
                        if (nameList != null && nameList.Count > 0)
                        {
                            if (nameList.ContainsKey(symbol))
                            {
                                instrument.SecurityDesc = nameList[symbol];
                            }
                        }
                        instrument.Save();
                        sb.Append(symbol + "(新)");
                        //Console.WriteLine("{0} 添加SYMBOL {1}。", DateTime.Now, symbol);
                    }
                    else
                    {
                        sb.Append( symbol+" ");
                    }
                    num++;
                    if (num % 10 == 0) sb.AppendLine();

                    //导入Daily数据
                    //Console.WriteLine("{0} 准备导入{1}的数据。", DateTime.Now, symbol);
                    ds = DataManager.GetDailySeries(instrument);
                    if (ds != null && ds.Count > 0)//Daily 已经存在
                    {
                        dt1 = ds.LastDateTime;
                    }
                    else
                    {
                        dt1 = new DateTime(1901, 1, 1);
                    }
                    if (symbol.EndsWith(".HK") || symbol.EndsWith(".HI"))
                        wd.IncludeZeroVolume = true;
                    else
                        wd.IncludeZeroVolume = false;
                    lst = wd.getDailyList(symbol, dt1, DateTime.Now.AddDays(1));
                    if (lst != null && lst.Count > 0)
                    {
                        Daily daily;
                        foreach (Daily d in lst)
                        {
                            //Console.WriteLine("{0} {1} {2} {3} {4} {5} ",daily.dt, daily.open, daily.high, daily.low, daily.close, daily.volume);
                            daily = new Daily(d.DateTime,d.Open,d.High,d.Low,d.Close,d.Volume,d.OpenInt);
                            instrument.Add(daily);
                            //Console.WriteLine(" debug: {0} {1}",symbol,daily.DateTime.ToString());
                        }
                    }
                }

                Console.WriteLine("{0} 导入完成，共导入{1}个代码。\n {2}", DateTime.Now,num,sb.ToString());
                this.Disconnect();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }



        #endregion

        #region IProvider 成员
        private bool isConnected = false;

        public void Connect(int timeout)
        {
            this.Connect();
            ProviderManager.WaitConnected(this, timeout);
        }
        public void Connect()
        {
            isConnected = true;
            Console.WriteLine("{0} Connected!",DateTime.Now);
            if (Connected != null)
                Connected(this, new EventArgs());
            this.doWork();
            //Thread th = new Thread(new ThreadStart(this.doWork));
            //th.Start();
        }
        public event EventHandler Connected;
        public void Disconnect()
        {
            try
            {
                Console.WriteLine("{0} Disconnected!",DateTime.Now);
                isConnected = false;
                if (Disconnected != null)
                    Disconnected(this, new EventArgs());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Disconnect：" + ex.Message);
            }

        }

        public event EventHandler Disconnected;

        public event ProviderErrorEventHandler Error;
        [Category("信息")]
        public byte Id
        {
            get { return 112; }
        }
        [Category("信息")]
        public bool IsConnected
        {
            get { return isConnected; }
        }
        [Category("信息")]
        public string Name
        {
            get { return "Wind2SQ"; }
        }
        [Category("信息")]
        public string Title
        {
            get { return "Wind2SQ 自动将Wind Daily行情数据导入SQ；会自动添加Instrument。"; }
        }
        [Category("信息")]
        public string URL
        {
            get { return String.Empty; }
        }
        public void Shutdown()
        {
            
        }
        [Category("信息")]
        public ProviderStatus Status
        {
            get
            {
                if (!IsConnected)
                    return ProviderStatus.Disconnected;
                else
                    return ProviderStatus.Connected;
            }
        }

        public event EventHandler StatusChanged;

        #endregion

        #region IHistoryProvider 成员
        [Category("信息")]
        public bool BarSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool DailySupported
        {
            get { return false; }
        }

        public Bar[] GetBarHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, int barSize)
        {
            throw new NotImplementedException();
        }

        public Daily[] GetDailyHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, bool dividendAndSplitAdjusted)
        {
            throw new NotImplementedException();
        }

        public Quote[] GetQuoteHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }

        public Trade[] GetTradeHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }
        [Category("信息")]
        public bool QuoteSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool TradeSupported
        {
            get { return false; }
        }

        #endregion
    }

    #region WIND数据操作类
    public class WindData
{
	public WindData()
	{
	}
	private string windPath = @"D:\Wind\Wind.NET.Client\WindNET\";
	private string WWTPath = @"D:\Windin\WWT\";

	[Category("设置"), Description("Wind安装路径")]
	public string WindPath
	{
		get
		{
			return windPath;
		}
		set
		{
			string t = value.Trim();
			if (t.EndsWith(@"\") == false)  t = t + @"\";
			if (Directory.Exists(t) == false)
				MessageBox.Show("路径" + t + " 不存在!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
			else if (Directory.Exists(t + @"data\") == false || Directory.Exists(t + @"etc\") == false)
				MessageBox.Show("路径" + t + " 不是有效的WIND安装路径", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
			else
				windPath = t;
		}
	}
	private bool includeZeroVolume = false;//包含停牌日数据
	[Category("设置"), Description("是否包含成交量为0的数据：True--包括停牌数据,False--剔除停牌数据")]
	public bool IncludeZeroVolume
	{
		get
		{
			return includeZeroVolume;
		}
		set
		{
			includeZeroVolume = value;
		}
	}
	public enum DataTypeStruct { data原始数据 = 0, data向前复权 = 1, data向后复权 = 2 }
	int historyDataType = 1;
	[Description("历史行情数据类型（0-原始数据，1-向前复权，2-向后复权）"), Category("设置")]
	public DataTypeStruct HistoryDataType
	{
		get
		{
			if (historyDataType == 1)
				return DataTypeStruct.data向前复权;
			else if (historyDataType == 2)
				return DataTypeStruct.data向后复权;
			else
				return DataTypeStruct.data原始数据;

		}
		set
		{
			if (value == DataTypeStruct.data向前复权)
				historyDataType = 1;
			else if (value == DataTypeStruct.data向后复权)
				historyDataType = 2;
			else
				historyDataType = 0;
		}
	}
	
	public List<string> GetStocklist(string symboRegexl)
	{
		List<string> stockList = new List<string>();
		try
		{
			SortedList<string,string> lst;
			lst = this.GetSecurityNames();
			for(int i=0;i<lst.Count;i++)
			{
				if (Regex.IsMatch(lst.Keys[i], symboRegexl ) == true)
				{
					stockList.Add(lst.Keys[i]);	
				
				}
			}
			
			
		}
		catch (Exception ex)
		{
			Console.WriteLine("GetStocklist error {0}", ex.Message);
		}
		return stockList;
	}
	public List<Daily> getDailyList(string symbol,DateTime dt1, DateTime dt2)
	{
		List<Daily> hqList = new List<Daily>();
		try
		{
			int dataType=this.historyDataType;
			string dm = symbol.Trim().ToUpper();
			int iDt1, iDt2;
			DateTime dt1900 = new DateTime(1900, 1, 1);
			DateTime dt2100 = new DateTime(2100, 1, 1);
			if (dt1 > dt1900)
				iDt1 = dt1.Year * 10000 + dt1.Month * 100 + dt1.Day;
			else
				iDt1 = 19000101;
			if (dt2 > dt1900)
				iDt2 = dt2.Year * 10000 + dt2.Month * 100 + dt2.Day;
			else
				iDt2 = 21000101;

			#region x读取原始数据
			if (dataType == 0)
			{
				bool isFundNav = false;
				if (dm.EndsWith("NV.SH") || dm.EndsWith("NV.SZ") || dm.EndsWith(".OF")) isFundNav = true;
				string windFileName = getFullName(windPath, symbol);
				if (!File.Exists(windFileName)) return null;
				FileStream fs = new FileStream(windFileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
				BinaryReader br = new BinaryReader(fs);
				long recordCount;
				if (isFundNav)  
					recordCount = fs.Length / 8;
				else
					recordCount = fs.Length / 28;
				int rq, sl; double kp, zg, zd, sp,je;
				for (long r = 0; r < recordCount; r++)
				{
					if (isFundNav)  
					{
						fs.Position = r * 8;
						rq = br.ReadInt32();if (rq < iDt1 || rq > iDt2) continue;
                        kp = (double)br.ReadSingle(); zg = kp; zd = kp; sp = kp; sl = 0; je = 0;
					}
					else
					{
						fs.Position = r * 28;
						rq = br.ReadInt32(); if (rq < iDt1 || rq > iDt2) continue;
						kp = (double)br.ReadSingle();zg = (double)br.ReadSingle();
						zd = (double)br.ReadSingle();sp = (double)br.ReadSingle();
						je = (double)br.ReadSingle(); sl = (int)br.ReadSingle();
					}
					string rqs = rq.ToString().Trim();
					DateTime date = new DateTime(int.Parse(rqs.Substring(0, 4)), int.Parse(rqs.Substring(4, 2)), int.Parse(rqs.Substring(6, 2)));//日期
					Daily bar = new Daily();
					bar.DateTime = date;bar.Open = kp;bar.High = zg;
                    bar.Low = zd; bar.Close = sp; bar.Volume = sl; bar.OpenInt = (long) Math.Round(je,0);
					if (isFundNav || includeZeroVolume)
						hqList.Add(bar);
					else if(sl>0)
						hqList.Add(bar);
				}
				fs.Close();
				br.Close();
				return hqList;
			}
			#endregion

			#region x读取复权数据
			else
			{
			//读复权因子
			SortedList<DateTime, double> lst;
			double maxfqyz=1.0;//最大复权因子
			double fqyz=1.0;//当前复权因子
			int fqyzIndex = 0;
			string filename = WWTPath +@"etc\hqafhis.dat";
			lst = GetFqyz(filename, dm);
			filename = WWTPath +@"etc\hqafdelt.dat";
			SortedList<DateTime, double> lst2 = GetFqyz(filename, dm);
			if(lst==null) lst=lst2;
			foreach (DateTime dt in lst2.Keys)   if (!lst.ContainsKey(dt)) lst.Add(dt, lst2[dt]);
			if (lst!=null && lst.Count > 0)
			{
				maxfqyz = lst.Values[lst.Count - 1];
				lst.Add(new DateTime(2100, 1, 1), maxfqyz);//增加一个无限大日期,
			}

			bool isFundNav = false;
			if (dm.EndsWith("NV.SH") || dm.EndsWith("NV.SZ") || dm.EndsWith(".OF"))
			{
				isFundNav = true;
			}
			string windFileName = getFullName(windPath, dm);
			if (!File.Exists(windFileName))
			{
				return null;
			}
			FileStream fs = new FileStream(windFileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			BinaryReader br = new BinaryReader(fs);
			long recordCount;
			if (isFundNav)  
				recordCount = fs.Length / 8;
			else
				recordCount = fs.Length / 28; 
			int rq, sl; double kp, zg, zd, sp,je;
			for (long r = 0; r < recordCount; r++)
			{
				if (isFundNav) 
				{
					fs.Position = r * 8;
					rq = br.ReadInt32();if (rq < iDt1 || rq > iDt2) continue;
					kp = (double)br.ReadSingle(); zg = kp; zd = kp; sp = kp; je = kp;
					sl = 0;
				}
				else
				{
					fs.Position = r * 28;
					rq = br.ReadInt32();if (rq < iDt1 || rq > iDt2) continue;
					kp = (double)br.ReadSingle();zg = (double)br.ReadSingle();zd = (double)br.ReadSingle();
					sp = (double)br.ReadSingle();je = (double)br.ReadSingle();sl = (int)br.ReadSingle();

				}
				string rqs = rq.ToString().Trim();
				DateTime date = new DateTime(int.Parse(rqs.Substring(0, 4)), int.Parse(rqs.Substring(4, 2)), int.Parse(rqs.Substring(6, 2)));//日期
				//Console.WriteLine(symbol+" "+rqs);
				//复权处理
				if (lst.Count > 0)
				{
					if (date < lst.Keys[0])
					{
						fqyz = 1; //后复权因子
						if (dataType == 1) //向前复权
						{
							fqyz = 1 / maxfqyz;//前复权因子
						}
						kp = kp * fqyz;
						zg = zg * fqyz;
						zd = zd * fqyz;
						sp = sp * fqyz;
						fqyzIndex = 0;
					}
					else
					{
						for (int j = fqyzIndex; j < lst.Count-1; j++)
						{
							if (lst.Keys [j] <= date && date < lst.Keys[j + 1])
							{
								fqyz = lst.Values[j]; //后复权因子
								if (dataType == 1) //向前复权
								{
									fqyz = lst.Values[j] / maxfqyz; //前复权因子
								}
								kp = kp * fqyz;
								zg = zg * fqyz;
								zd = zd * fqyz;
								sp = sp * fqyz;
								fqyzIndex = j;
								break;
							}

						}
					}
				}

				//复权处理结束
				Daily bar = new Daily();
				bar.DateTime = date;
				bar.Open = kp;
				bar.High = zg;
				bar.Low = zd;
				bar.Close = sp;
				bar.Volume = sl;
                bar.OpenInt = (long)Math.Round(je,0);
				if (isFundNav || includeZeroVolume)
					hqList.Add(bar);
				else if (sl > 0 )
					hqList.Add(bar);
			}
			fs.Close();
			br.Close();
			return hqList;
			}
			#endregion

		}
		catch (Exception ex)
		{
			Console.WriteLine("GetDailyList error: {0}", ex.Message);
			return null;
		}
	}
	public SortedList <DateTime, double > GetFqyz(string filename, string Symbol)
	{
		try
		{
			SortedList<DateTime, double> mylst = new SortedList<DateTime, double>();
			string windFileName =  filename;
			if (File.Exists(windFileName) == false)
			{
				Console.WriteLine("错误:文件不存在");
				return null;
			}
			FileStream fs = new FileStream(windFileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			BinaryReader br = new BinaryReader(fs);
			//string s = "";string ss="";
			fs.Position=18;
			long recordCount = br.ReadUInt32();//第18字节开始的4B保存记录个数,接下来是每个记录,以0x09开头
			for(int record=0;record<recordCount;record++)
			{
				byte flag = br.ReadByte();
				if (flag == '\x09')
				{
					string dm = new string(br.ReadChars(9));//代码
					string rqs = new string(br.ReadChars(8));//日期
					double yz = br.ReadSingle();//复权因子
					fs.Position=fs.Position+1;  //有个00字节
					short notelen = br.ReadInt16(); //备注字符串长度
					fs.Position=fs.Position+notelen;
					//s=System.Text.Encoding.Default.GetString(br.ReadBytes(notelen));//备注字符串
					//s=s.Replace("\x0D","").Replace("\x0A","");
					//ss=dm+","+rq+","+yz.ToString() ;
					//Console.WriteLine(ss);
					if (dm==Symbol)
					{
						DateTime rq =new DateTime(int.Parse(rqs.Substring(0, 4)), int.Parse(rqs.Substring(4, 2)), int.Parse(rqs.Substring(6, 2)));
						if(!mylst.ContainsKey(rq)) mylst.Add(rq,yz);
				
					}
				}
			}
			fs.Close();
			br.Close();	
			
			return mylst;
		}
		catch
		{
			return null;	
		}
	}
	public SortedList <DateTime, double > GetFactorList(string symbol)
	{
		string filename = WWTPath +@"etc\hqafhis.dat";
		SortedList<DateTime, double> lst = GetFqyz(filename, symbol);
		filename =  WWTPath +@"etc\hqafdelt.dat";
		SortedList<DateTime, double> lst2 = GetFqyz(filename, symbol);
		if(lst==null)
		{lst=lst2;
		}
		else
		{
			foreach (DateTime dt in lst2.Keys)   if (!lst.ContainsKey(dt)) lst.Add(dt, lst2[dt]);
		}
		return lst;
	}
	public DateTime GetMaxDateFqyz(string symbol)
	{
		DateTime maxDate=new DateTime(1990,1,1);
		string filename = WWTPath +@"etc\hqafhis.dat";
		SortedList<DateTime, double> lst = GetFqyz(filename, symbol);
		if(lst!=null && lst.Count>0)
			maxDate=lst.Keys[lst.Count-1];
		
		filename = WWTPath +@"etc\hqafdelt.dat";
		lst = GetFqyz(filename, symbol);
		if (lst!=null && lst.Count > 0)
		{
			DateTime maxDate2 = lst.Keys[lst.Count - 1];
			if(maxDate2>maxDate) maxDate=maxDate2;
		}
		
		return maxDate;
	}
	public string getFullName(string windPath, string symbol)
	{
		string windFileName = null;
		string windDayPath = ""; string dm = symbol.Trim().ToUpper();

		if (dm.EndsWith("NV.SH") || dm.EndsWith("NV.SZ") || dm.EndsWith(".OF"))
		{
			windDayPath = windPath + @"DATA\HQ\FUND\DAY\";
		}
		else if (dm.EndsWith(".SH") || dm.EndsWith(".SZ")) windDayPath = windPath + @"DATA\HQ\STOCK\DAY\";
		else if (dm.EndsWith(".OC")) windDayPath = windPath + @"DATA\HQ\OC\DAY\";
		else if (dm.EndsWith("I") || dm.EndsWith(".CS") || dm.EndsWith(".BOC") || dm.EndsWith(".IL") || dm.EndsWith(".RB")) windDayPath = windPath + @"DATA\HQ\INDEX\DAY\";
		else if (dm.EndsWith(".FX")) windDayPath = windPath + @"DATA\HQ\FX\DAY\";
		else if (dm.EndsWith(".HK") || dm.EndsWith(".US")) windDayPath = windPath + @"DATA\HQ\HK\DAY\";
		else windDayPath = windPath + @"DATA\HQ\STOCK\DAY\";

		windFileName = windDayPath + symbol.Trim() + ".DAY";
		//Console.WriteLine(windFileName);
		if (windPath.Trim().Length == 0)
		{
			windFileName = symbol.Trim() + ".Day";
		}
		return windFileName;
	}	
	public string getWindCode(string code)
	{
		string myCode = code.Trim().ToUpper();
		if (Regex.IsMatch(myCode, @"(4[02]\d{4}.SZ)") == true) myCode.Replace(".SZ", ".OC");
		return myCode;
	}
	public string getMyCode(string code)
	{
		string myCode = code.Trim().ToUpper();
		if (myCode.EndsWith(".OC")) myCode = myCode.Replace(".OC", ".SZ");
		return myCode;
	}
    //public string GetSecurityType(string symbol)
    //{
    //    string code = getMyCode(symbol.Trim().ToUpper());
    //    if (Regex.IsMatch(code, @"(000300.SH)|(000017.SH)|(00090\d.SH)|(\d*.GI)|(\d*.HI)") == true)
    //    {
    //        return "Index";//指数
    //    }
    //    if (Regex.IsMatch(code, @"(60[0-8]\d{3}.SH)|(90\d{4}.SH)|(00[01256789]\d{3}.SZ)|(20\d{4}.SZ)|(4\d{5}.SZ)|(\d{4}.HK)") == true)
    //    {
    //        return "Stock";//股票
    //    }
    //    else if (Regex.IsMatch(code, @"(00000\d\.SH)|(00001[0-6]\.SH)") == true)
    //    {
    //        return "Index";
    //    }
    //    else if (Regex.IsMatch(code, @"([012]\d{5}.SH)|(1[0123]\d{4}.SZ)") == true && Regex.IsMatch(code, @"(181\d{3}.SH)") == false && Regex.IsMatch(code, @"(190\d{3}.SH)") == false)
    //    {
    //        return "Bond";//债券，FIX中细分各种债券，这里未区分
    //    }
    //    else if (Regex.IsMatch(code, @"(510\d{3}.SH)|(159\d{3}.SZ)") == true)
    //    {
    //        return "ETF";// ETF
    //    }
    //    else if (Regex.IsMatch(code, @"(5[01]\d{4}.SH)|(184\d{3}.SZ)|(\d{6}.OF)|(\d{6}NV.OF)|(1[56]\d{4}.SZ)") == true)
    //    {
    //        return "Fund"; //封闭及开放基金,LOF
    //    }
    //    else if (Regex.IsMatch(code, @"(58\d{4}.SH)|(03\d{4}.SZ)") == true)
    //    {
    //        return "Warrant";//权证
    //    }
    //    else if (Regex.IsMatch(code, @"(000\d{3}.SH)|(399\d{3}.SZ)|(8[013]\d{4}.SH)") == true)
    //    {
    //        return "Index";
    //    }
    //    return "Z";
    //}
	public string GetSecurityName(string Symbol)
	{
		try
		{  
			string windFileName = windPath + @"ETC\SECBASICS.DAT";
			if (File.Exists(windFileName) == false)
			{
				return "";
			}
			FileStream fs = new FileStream(windFileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			BinaryReader br = new BinaryReader(fs);
			string s = "", code = "", name = "";
			long recordCount = fs.Length / 35;
			for (long r = 0; r < recordCount; r++)
			{
				fs.Position = r * 35;
				s = System.Text.Encoding.Default.GetString(br.ReadBytes(32));
				code = s.Substring(0, s.IndexOf("\0")).ToUpper();
				if (code == Symbol.ToUpper())
				{
					name = s.Substring(12);
					name = name.Substring(0, name.IndexOf("\0"));
					return name;
				}
			}
			fs.Close();
			br.Close();
			return "";
		}
		catch  
		{
			return ""; 
		}
	}
	public SortedList<string,string> GetSecurityNames()
	{
		SortedList<string,string> list = new SortedList<string,string>();
		try
		{  
			string windFileName = windPath + @"ETC\SECBASICS.DAT";
			if (File.Exists(windFileName) == false)
			{
				Console.WriteLine("读取证券简称错误:文件不存在");
				return null;
			}
			FileStream fs = new FileStream(windFileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			BinaryReader br = new BinaryReader(fs);
			string s = "", code = "", name = "";
			long recordCount = fs.Length / 35;
			for (long r = 0; r < recordCount; r++)
			{
				fs.Position = r * 35;
				s = System.Text.Encoding.Default.GetString(br.ReadBytes(32));
				code = s.Substring(0,12).ToUpper().Replace("\0","").Trim();
				if (code.Length>0)
				{
					name = s.Substring(12).Replace("\0","").Trim();
					if(!list.Keys.Contains(code)) list.Add(code,name);
					//Console.WriteLine("{0} ,{1}",code,name);
				}
			}
			fs.Close();
			br.Close();
			return list;
		}
		catch(Exception ex)  
		{
			Console.WriteLine("读取证券简称错误:{0}",ex.Message);
			return null; 
		}
	}

}

//public struct barStruct
//{
//    public DateTime dt; 
//    public double   open;			//开盘价
//    public double   high;			//最高价		
//    public double   low;			//最低价
//    public double   close;			//收盘价
//    public int      volume;	        //成交量
//}
    #endregion
}
