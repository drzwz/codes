﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using SQ2Console.SQ;
using SmartQuant.Data;
using SmartQuant.Series;

namespace SQ2Console
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length < 1)
            {
                //Console.WriteLine("用法：SQ2Console <> <>");
                return;
            }
            try
            {
                Console.Title = "正在读取数据，请不要手工关闭...";
                //string sepChar = ",";
                if (args[0].ToLower() == "getdailylist" && args.Length > 3)
                {

                    SQServiceClient client = new SQServiceClient();
                    string strdt1 = args[2];
                    string strdt2 = args[3];
                    DateTime dt1 = DateTime.Parse(strdt1);
                    DateTime dt2 = DateTime.Parse(strdt2);
                    string roundFormat = "F2";
                    if (args.Length > 4) roundFormat = args[4];//控制价格的小数点位数
                    List<Daily> dailyList = client.GetDailyList(args[1], dt1, dt2);
                    foreach (Daily d in dailyList)
                    {
                        Console.WriteLine("{0},{1},{2},{3},{4},{5},{6},{7}", args[1],
                            d.Date.ToString("yyyy-MM-dd"),
                            d.Open.ToString(roundFormat),
                            d.High.ToString(roundFormat),
                            d.Low.ToString(roundFormat),
                            d.Close.ToString(roundFormat),
                            d.Volume, d.OpenInt);
                    }
                }
                else if (args[0].ToLower() == "getdailyadjlist" && args.Length > 3)
                {

                    SQServiceClient client = new SQServiceClient();
                    string strdt1 = args[2];
                    string strdt2 = args[3];
                    DateTime dt1 = DateTime.Parse(strdt1);
                    DateTime dt2 = DateTime.Parse(strdt2);
                    string roundFormat = "F2";
                    if (args.Length > 4) roundFormat = args[4];//控制价格的小数点位数
                    List<Daily> dailyList = client.GetDailyAdjList(args[1], dt1, dt2);
                    foreach (Daily d in dailyList)
                    {
                        Console.WriteLine("{0},{1},{2},{3},{4},{5},{6},{7}", args[1],
                            d.Date.ToString("yyyy-MM-dd"),
                            d.Open.ToString(roundFormat),
                            d.High.ToString(roundFormat),
                            d.Low.ToString(roundFormat),
                            d.Close.ToString(roundFormat),
                            d.Volume, d.OpenInt);
                    }
                }
                else if (args[0].ToLower() == "getbarlist" && args.Length > 4)
                {

                    SQServiceClient client = new SQServiceClient();
                    string strdt1 = args[2];
                    string strdt2 = args[3];
                    DateTime dt1 = DateTime.Parse(strdt1);
                    DateTime dt2 = DateTime.Parse(strdt2);
                    string roundFormat = "F2";
                    if (args.Length > 5) roundFormat = args[5];//控制价格的小数点位数
                    List<Bar> list = client.GetBarList(args[1], dt1, dt2, int.Parse(args[4]));
                    foreach (Bar b in list)
                    {
                        Console.WriteLine("{0},{1},{2},{3},{4},{5},{6},{7}", args[1],
                            b.DateTime.ToString("yyyy-MM-dd hh:mm:ss"),
                            b.Open.ToString(roundFormat),
                            b.High.ToString(roundFormat),
                            b.Low.ToString(roundFormat),
                            b.Close.ToString(roundFormat),
                            b.Volume, b.OpenInt);
                    }
                }
                else if (args[0].ToLower() == "getquotelist" && args.Length > 3)
                {

                    SQServiceClient client = new SQServiceClient();
                    string strdt1 = args[2];
                    string strdt2 = args[3];
                    DateTime dt1 = DateTime.Parse(strdt1);
                    DateTime dt2 = DateTime.Parse(strdt2);
                    string roundFormat = "F2";
                    if (args.Length > 4) roundFormat = args[4];//控制价格的小数点位数
                    List<Quote> list = client.GetQuoteList(args[1], dt1, dt2);
                    foreach (Quote b in list)
                    {
                        Console.WriteLine("{0},{1},{2},{3},{4},{5}", args[1],
                            b.DateTime.ToString("yyyy-MM-dd hh:mm:ss"),
                            b.Bid.ToString(roundFormat),
                            b.BidSize.ToString(),
                            b.Ask.ToString(roundFormat),
                            b.AskSize.ToString() );
                    }
                }
                else if (args[0].ToLower() == "gettradelist" && args.Length > 3)
                {

                    SQServiceClient client = new SQServiceClient();
                    string strdt1 = args[2];
                    string strdt2 = args[3];
                    DateTime dt1 = DateTime.Parse(strdt1);
                    DateTime dt2 = DateTime.Parse(strdt2);
                    string roundFormat = "F2";
                    if (args.Length > 4) roundFormat = args[4];//控制价格的小数点位数
                    List<Trade> list = client.GetTradeList(args[1], dt1, dt2 );
                    foreach (Trade b in list)
                    {
                        Console.WriteLine("{0},{1},{2},{3}", args[1],
                            b.DateTime.ToString("yyyy-MM-dd hh:mm:ss"),
                            b.Price.ToString(roundFormat),
                            b.Size.ToString() );
                    }
                }
                else if (args[0].ToLower() == "getpricefactorlist" && args.Length > 1)
                {

                    SQServiceClient client = new SQServiceClient();
                    string roundFormat = "F6";
                    if (args.Length > 2) roundFormat = args[2];//控制价格的小数点位数
                    SortedList<DateTime,double> list = client.GetPriceFactorList(args[1]);
                    foreach (DateTime dt in list.Keys)
                    {
                        Console.WriteLine("{0},{1},{2}", args[1],
                            dt.ToString("yyyy-MM-dd hh:mm:ss"),
                            list[dt].ToString(roundFormat)  );
                    }
                }
                else if (args[0].ToLower() == "getsymbollist" && args.Length > 0)
                {

                    SQServiceClient client = new SQServiceClient();
                    List<string> list = client.GetSymbolList(null,null,null);
                    foreach (string s in list)
                    {
                        Console.WriteLine("{0}", s );
                    }
                }
                else if (args[0].ToLower() == "getsecuritynamelist" && args.Length > 0)
                {

                    SQServiceClient client = new SQServiceClient();
                    SortedList<string,string> list = client.GetSecurityNameList(null, null, null);
                    foreach (string s in list.Keys)
                    {
                        Console.WriteLine("{0},{1} ", s ,list[s]);
                    }
                }
            }
            catch (Exception ex)
            {
                StreamWriter sw = new StreamWriter(@".\LOG.txt",true);
                sw.WriteLine("{0} 错误：{1}" ,DateTime.Now, ex.Message);
                sw.Close();
            }
        }
    }
}
