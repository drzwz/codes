﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.IO;

namespace Drzwz
{
    public delegate void SC_NOWDATAEventHandler(SCRTcontrol sender, string Symbol, RCV_NOW_STRUCTEx e);
    public delegate void SC_PANKUO_EventHandler(SCRTcontrol sender, int replyNo, List<RCV_PANKOU_STRUCTEx> e);
    public delegate void SC_KLINE_5MinOrDay_EventHandler(SCRTcontrol sender, int replyNo, string symbol, List<RCV_HISTORY_STRUCTEx> e);//zzz
    //public delegate void SC_Symbols_EventHandler(SCRTcontrol sender, string Exchange, ArrayList list);//zzz

    public partial class SCRTcontrol : UserControl
    {
        public event SC_NOWDATAEventHandler OnQuote;
        public event SC_PANKUO_EventHandler OnSC_PANKUO;//补tick;
        public event SC_KLINE_5MinOrDay_EventHandler OnSC_KLINE;
        //public event SC_Symbols_EventHandler OnSC_Symbol;

        static int m_lASkIndex = 1;
        //   static  int wldcounter = 0;

        public SCRTcontrol()
        {
            InitializeComponent();

        }

        #region 调用数畅函数
        private const int WM_USER = 0x0400 + 101;
        internal delegate bool LoadDll([MarshalAs(UnmanagedType.AsAny)] Object o, int nSize);
        internal delegate void AskData([MarshalAs(UnmanagedType.AsAny)] Object o, int nSize);
        internal delegate bool SCGetInfoEx([MarshalAs(UnmanagedType.AsAny)] Object o, [MarshalAs(UnmanagedType.AsAny)] Object o1);
        internal delegate void UnLoadDll();
        [DllImport("kernel32.dll")]
        internal static extern IntPtr LoadLibrary(String dllname);
        [DllImport("kernel32.dll")]
        internal static extern IntPtr GetProcAddress(IntPtr hModule, String procname);


        private IntPtr libraryHandle;
        private bool Drvloaded = false;
        public CodeTable SC_CODETABLE = new CodeTable();
        private SCMarket MKTDATA;
        #endregion
        #region 数畅行情结构变量


        // 数畅接口

        // 更新日期：20060228
        // 更新内容：
        // 1. tagSCPankou里面的时间改为uint类型。
        //    SC_PankouReply里面的个数short m_nCount改为long m_lCount
        // 2. SC_KLineAsk和SC_KLineReply有所调整
        // 3. 扩充市场定义，三板、外汇、期货、台湾市场，使用SCMarket返回的m_wMarket值即可。
        // 4. 大部分数据类型的的#define值有更改，重新编译即可
        // 5. SC_Downdload中的m_nCount改为m_lCount，类型改为long. 
        //    结构名称从'SC_Downdload'改为'SC_Download'
        // 6. SH_MARKET_EX、SZ_MARKET_EX等的定义已删除，直接用SCMarket里面的m_wMarket即可。
        // 7. 初始化函数名改为SCInit
        // 8. 示范代码更加详细，请参考我们的例子，SCDemo


        private const int SC_INIT = 0x2001;	// SCInit调用

        private const int SC_CLEAR_PREVREQ = 0x2101;	// 撤销前面的所有请求，建议在发请求（或组合请求）之前调用
        private const int SC_MARKET = 0x2131;	// 请求指定市场的信息，无需请求，有变化就会自动发送

        private const int SC_NOWDATA = 0x2201;

        private const int SC_PANKOU = 0x2301;	// 请求盘口数据，对应：uint m_time，建议使用这个。

        private const int SC_IMTYPELIST = 0x2401;	// 请求信息地雷信息分类表
        private const int SC_IMTITLE = 0x2402;	// 请求信息地雷标题列表
        private const int SC_IMCONTENT = 0x2403;	// 请求信息地雷数据(f10, 交易所公告、实时和历史的个股信息等)

        private const int SC_KLINE = 0x2501;	// 请求K线数据（日线）

        private const int SC_CQ = 0x2601;	// 请求除权数据

        private const int SC_DL_KLINE = 0x2701;	// K线数据下载
        private const int SC_DL_CQ = 0x2702;	// 除权数据下载
        private const int SC_DL_XX = 0x2703;	// 信息下载，如F10、交易所公告、新闻等
        private const int SC_DL_TRACE = 0x2704;	// 明细数据，旧的，新版已不用
        private const int SC_DL_5MIN = 0x2705;	// 5分钟K线下载

        //define for SC_KLineAsk::m_wDataType
        private const int KLINE_DAYDATA = 0;		//日线
        private const int KLINE_MIN5DATA = 1;		//5分钟线
        //信息地雷类型属性的定义
        private const int CLASS_JYSXX = 0;	// 交易所公告
        private const int CLASS_STKINFO = 1;	// 历史信息地雷
        private const int CLASS_NEWS = 2;	// 新闻
        private const int CLASS_STOCKBASE = 3;	// F10
        private const int CLASS_MKTINFO = 4;	// 综合资讯
        // 数畅公司分配的软件标识wealth-lab 0x25875298
        private const int Wealth_Lab_ID = 0x25875298;
        #endregion

        #region ZZZ添加的方法等
        //zzz
        public System.Collections.Generic.List<string> Symbols = new System.Collections.Generic.List<string>();
        public System.Collections.Generic.SortedList<string, DateTime> MarketDate = new SortedList<string, DateTime>();
        public DateTime GetMarketDate(string mkt)
        {
            if (this.MarketDate.ContainsKey(mkt)) return this.MarketDate[mkt];
            else return DateTime.Now;//xxxxxxxxxxx
        }

        private System.Drawing.Icon DrawIcon(string IconMessage)
        {
            IntPtr hIcon = new IntPtr();//zzz
            Icon oIcon = null;

            int dimension = 16;
            try
            {

                Bitmap bm = new Bitmap(dimension, dimension);
                Graphics g = Graphics.FromImage((Image)bm);
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                Font oFont = new Font("Arial", 9, FontStyle.Regular, GraphicsUnit.Pixel);
                g.FillRectangle(Brushes.Transparent, new Rectangle(0, 0, bm.Width, bm.Height));
                g.FillEllipse(Brushes.LightCyan, 0, 0, dimension, dimension);
                g.DrawString(IconMessage, oFont, new SolidBrush(System.Drawing.Color.Red), 0, 3);
                hIcon = bm.GetHicon();
                oIcon = Icon.FromHandle(hIcon);
                oFont.Dispose();
                g.Dispose();
                bm.Dispose();


            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
            }

            // Ensure that older versions of the framework GDI+
            // release these resources.
            //GDIPlus.CleanUp.DestroyIcon(hIcon);
            return oIcon;

        }

        #endregion

        protected override void WndProc(ref Message m)
        {
            try
            {
                int i, offset, stockrecsize;
                // short nIndex;
                //ushort wMarket;
                //SCMarket pscm;


                if (m.Msg == WM_USER)
                {
                    // Console.WriteLine("开始接收。。。");
                    SCHead pHead = (SCHead)m.GetLParam(typeof(SCHead));
                    switch (pHead.m_nType)
                    {
                        case SC_MARKET:
                            {
                                SC_MarketReply psc = (SC_MarketReply)m.GetLParam(typeof(SC_MarketReply));
                                //Console.WriteLine("接收市场数据...");
                                offset = Marshal.SizeOf(typeof(SC_MarketReply));
                                stockrecsize = Marshal.SizeOf(typeof(StockInfo));
                                MKTDATA = psc.m_Market;

                                for (i = 0; i < psc.m_Market.m_nCount; i++)
                                {
                                    StockInfo record = (StockInfo)Marshal.PtrToStructure
                                       (new IntPtr(m.LParam.ToInt32() + stockrecsize * i +
                                       Marshal.SizeOf(typeof(SC_MarketReply))), typeof(StockInfo));

                                    SC_CODETABLE.addData(psc.m_Market.scmarketcode, (short)i, record);
                                    string dm = record.m_szLabel.Trim() + "." + psc.m_Market.scmarketcode.Trim().ToUpper();
                                    if (!Symbols.Contains(dm)) Symbols.Add(dm);//zzz
                                }
                                if (!MarketDate.ContainsKey(psc.m_Market.scmarketcode))
                                    MarketDate.Add(psc.m_Market.scmarketcode, DateTime.ParseExact(psc.m_Market.m_lDate.ToString(), "yyyyMMdd", null)); ;
                                //Console.WriteLine(string.Format("市场{0},日期{1},证券数{2},开市{3},收市{4},时段数{5}",
                                //    psc.m_Market.scmarketcode, DateTime.ParseExact(psc.m_Market.m_lDate.ToString(), "yyyyMMdd", null), psc.m_Market.m_nCount,
                                //    psc.m_Market.m_OpenTime[0], psc.m_Market.m_CloseTime[0], psc.m_Market.m_PeriodCount));

                            }
                            break;
                        case SC_NOWDATA:
                            {
                                try
                                {
                                    SC_NowDataReply pnr = (SC_NowDataReply)m.GetLParam(typeof(SC_NowDataReply));
                                    //Console.WriteLine("正在接收 SC_nowdata");
                                    if (pnr.m_nCount > 0)
                                    {
                                        offset = Marshal.SizeOf(typeof(SC_NowDataReply));
                                        stockrecsize = Marshal.SizeOf(typeof(RCV_NOW_STRUCTEx));

                                        for (i = 0; i < pnr.m_nCount; i++)
                                        {
                                            RCV_NOW_STRUCTEx record = (RCV_NOW_STRUCTEx)Marshal.PtrToStructure(
                                                new IntPtr(m.LParam.ToInt32() + offset + stockrecsize * i), typeof(RCV_NOW_STRUCTEx));
                                            string wmarket = GetMarketName(record.m_sID.m_wMarket);

                                            string Symbol = SC_CODETABLE.GetSymbolCode(wmarket, record.m_sID.m_nIndex) + "." + wmarket.Trim();

                                            //Console.WriteLine("{0}\t {1} \t{2}\t {3}\t{4} \t{5}\t{6}",record.m_sID.m_wMarket, record.m_sID.m_nIndex,
                                            //stock.m_szLabel ,stock .m_szName , record.m_fNewPrice , record.m_fVolume,record.m_lStroke);
                                            if (OnQuote != null)
                                            {
                                                OnQuote(this, Symbol, record);
                                            }
                                        }

                                    }
                                }
                                catch (Exception ex)
                                {
                                    StMyFunction.textwrite(string.Format
                                        ("time:{0} \t  SC_NOW 出错:{1} \t {2} case is :{3}  ", DateTime.Now, ex.Message, ex.InnerException, ex.Source.ToString()));
                                }
                            }

                            break;
                        case SC_KLINE:
                            {
                                SC_KLineReply pk = (SC_KLineReply)m.GetLParam(typeof(SC_KLineReply));
                                offset = Marshal.SizeOf(typeof(SC_KLineReply));
                                stockrecsize = Marshal.SizeOf(typeof(RCV_HISTORY_STRUCTEx));


                                // StockInfo stockinfo = SC_CODETABLE.GetStockInfo(GetMarketName(pk.m_sID.m_wMarket), pk.m_sID.m_nIndex);
                                //Console.WriteLine("{0}\t {1} \t ", stockinfo.m_szLabel, stockinfo.m_szName);
                                List<RCV_HISTORY_STRUCTEx> Records = new List<RCV_HISTORY_STRUCTEx>();
                                switch (pk.m_wDataType)
                                {
                                    case KLINE_DAYDATA:
                                        //    Console.WriteLine("日线");


                                        for (i = 0; i < pk.m_lDataCount; ++i)
                                        {
                                            RCV_HISTORY_STRUCTEx record = (RCV_HISTORY_STRUCTEx)Marshal.PtrToStructure
                                                  (new IntPtr(m.LParam.ToInt32() + stockrecsize * i +
                                                  offset), typeof(RCV_HISTORY_STRUCTEx));
                                            //DateTime mtime = new DateTime(1970, 1, 1).AddSeconds(record.m_time).ToLocalTime();
                                            //Console.WriteLine("{0}\t {1}\t {2}\t ", mtime, record.m_fClose, record.m_fVolume);
                                            Records.Add(record);

                                        }
                                        if (OnSC_KLINE != null)
                                        {
                                            string wmarket1 = GetMarketName(pk.m_sID.m_wMarket);
                                            string symbol1 = SC_CODETABLE.GetSymbolCode(wmarket1, pk.m_sID.m_nIndex) + "." + wmarket1.Trim();
                                            OnSC_KLINE(this, pk.m_Head.m_lIndex, symbol1, Records);
                                        }

                                        break;
                                    case KLINE_MIN5DATA:
                                        //      Console.WriteLine("5Min :共有{0}  个记录", pk.m_lDataCount);


                                        for (i = 0; i < pk.m_lDataCount; ++i)
                                        {
                                            RCV_HISTORY_STRUCTEx record = (RCV_HISTORY_STRUCTEx)Marshal.PtrToStructure
                                                 (new IntPtr(m.LParam.ToInt32() + stockrecsize * i +
                                                 offset), typeof(RCV_HISTORY_STRUCTEx));

                                            //Console.WriteLine("{0}\t {1}\t {2}\t ", m_timeToDateTime(record.m_time), record.m_fClose, record.m_fVolume);
                                            Records.Add(record);
                                        }
                                        if (OnSC_KLINE != null)
                                        {
                                            string wmarket = GetMarketName(pk.m_sID.m_wMarket);
                                            string symbol = SC_CODETABLE.GetSymbolCode(wmarket, pk.m_sID.m_nIndex) + "." + wmarket.Trim();
                                            OnSC_KLINE(this, pk.m_Head.m_lIndex, symbol, Records);
                                        }

                                        break;
                                }
                            }

                            break;
                        case SC_PANKOU:
                            {
                                //StMyFunction .textwrite(string .Format ("time:{0} 正在接收盘口数据....",DateTime .Now ));
                                SC_PankouReply pp = (SC_PankouReply)m.GetLParam(typeof(SC_PankouReply));
                                offset = Marshal.SizeOf(typeof(SC_PankouReply));
                                stockrecsize = Marshal.SizeOf(typeof(RCV_PANKOU_STRUCTEx));

                                //StockInfo stockinfo = SC_CODETABLE.GetStockInfo(GetMarketName(pp.m_sID.m_wMarket), pp.m_sID.m_nIndex);
                                //StMyFunction.textwrite(string.Format("{0}\t {1} \t reccount:{2} ", 
                                //                       stockinfo.m_szLabel, stockinfo.m_szName, pp, pp.m_lCount));
                                if (pp.m_lCount > 0)
                                {
                                    List<RCV_PANKOU_STRUCTEx> Records = new List<RCV_PANKOU_STRUCTEx>();
                                    for (i = 0; i < pp.m_lCount; ++i)
                                    {
                                        RCV_PANKOU_STRUCTEx record = (RCV_PANKOU_STRUCTEx)Marshal.PtrToStructure
                                                      (new IntPtr(m.LParam.ToInt32() + stockrecsize * i +
                                                      offset), typeof(RCV_PANKOU_STRUCTEx));

                                        //StMyFunction.textwrite(string.Format("{0}\t {1}\t {2}\t {3} \t", m_timeToDateTime(record.m_time), record.m_fNewPrice, record.m_fVolume, record.m_lStroke));
                                        if (record.m_fNewPrice > 0)   //最新价为零不增加list
                                        {
                                            Records.Add(record);
                                        }
                                    }
                                    //StMyFunction.textwrite(string.Format("fished !! count:{0} lindex:{1}", Records.Count, pp.m_Head.m_lIndex));
                                    if (OnSC_PANKUO != null)
                                    {
                                        OnSC_PANKUO(this, pp.m_Head.m_lIndex, Records);
                                    }
                                }
                            }
                            break;
                        case SC_CQ:

                            Console.WriteLine("SC_CQ");
                            break;
                        case SC_IMTYPELIST:
                            {
                                SC_IMTypeReply pt = (SC_IMTypeReply)m.GetLParam(typeof(SC_IMTypeReply));
                                Console.WriteLine("SC_IMTypeReply");
                            }
                            break;
                        case SC_IMTITLE:
                            SC_IMTitleReply ptr = (SC_IMTitleReply)m.GetLParam(typeof(SC_IMTitleReply));
                            Console.WriteLine("SC_IMTitleReply");
                            break;
                        case SC_IMCONTENT:
                            {
                                Console.WriteLine("SC_imcontent");
                            }
                            break;
                        case SC_DL_KLINE:		// 日k线下载
                            {
                                SC_Download pdl = (SC_Download)m.GetLParam(typeof(SC_Download));
                                offset = Marshal.SizeOf(typeof(SC_Download));
                                stockrecsize = Marshal.SizeOf(typeof(RCV_HISTORY_STRUCTEx));
                                //Console.WriteLine("收到下载日线数据:"+pdl.m_lCount);
                                for (i = 0; i < pdl.m_lCount; i++)
                                {
                                    RCV_HISTORY_STRUCTEx record = (RCV_HISTORY_STRUCTEx)Marshal.PtrToStructure
                                       (new IntPtr(m.LParam.ToInt32() + stockrecsize * i +
                                       offset), typeof(RCV_HISTORY_STRUCTEx));

                                    //Console.WriteLine(string.Format("{0} \t {1} \t {2} \t   \r\n",
                                    //    m_timeToDateTime(record.m_time), record.m_fClose, record.m_fVolume));
                                }
                            }
                            break;
                        case SC_DL_5MIN:		// 五分钟k线下载
                            {
                                SC_Download pdl = (SC_Download)m.GetLParam(typeof(SC_Download));
                                offset = Marshal.SizeOf(typeof(SC_Download));
                                stockrecsize = Marshal.SizeOf(typeof(RCV_HISTORY_STRUCTEx));
                                //Console.WriteLine(string.Format("收到下载五分钟数据 {0} ", pdl.m_lCount));
                                for (i = 0; i < pdl.m_lCount; i++)
                                {
                                    RCV_HISTORY_STRUCTEx record = (RCV_HISTORY_STRUCTEx)Marshal.PtrToStructure
                                       (new IntPtr(m.LParam.ToInt32() + stockrecsize * i +
                                      offset), typeof(RCV_HISTORY_STRUCTEx));

                                    //Console.WriteLine(string.Format("{0} \t {1} \t {2} \t   \r\n",
                                    //    m_timeToDateTime(record.m_time), record.m_fClose, record.m_fVolume));
                                }
                            }
                            break;
                        case SC_DL_CQ:			// 除权数据下载
                            {
                                SC_Download pdl = (SC_Download)m.GetLParam(typeof(SC_Download));
                                offset = Marshal.SizeOf(typeof(SC_Download));
                                stockrecsize = Marshal.SizeOf(typeof(RCV_POWER_STRUCTEx));
                                Console.WriteLine("收到下载除权数据 ");
                                for (i = 0; i < pdl.m_lCount; i++)
                                {
                                    RCV_POWER_STRUCTEx record = (RCV_POWER_STRUCTEx)Marshal.PtrToStructure
                                       (new IntPtr(m.LParam.ToInt32() + stockrecsize * i +
                                      offset), typeof(RCV_POWER_STRUCTEx));

                                    Console.WriteLine(string.Format("{0} \t {1} \t {2} \t   \r\n",
                                        m_timeToDateTime(record.m_time), record.m_fGive, record.m_fPei));
                                }

                            }
                            break;
                        case SC_DL_XX:			// 资讯数据下载：交易所公告、信息地雷、新闻、综合等
                            {
                                /*//SC_Download *pdl = (SC_Download *)lParam;
                                switch ( pdl->m_cClass ) {
                                case CLASS_JYSXX:
                                    sprintf(strText, "收到下载交易所公告 %d 个", pdl->m_lCount);
                                    break;
                                case CLASS_STKINFO:
                                    sprintf(strText, "收到下载历史信息地雷 %d 个", pdl->m_lCount);
                                    break;
                                case CLASS_NEWS:
                                    sprintf(strText, "收到下载新闻 %d 个", pdl->m_lCount);
                                    break;
                                case CLASS_STOCKBASE:
                                    sprintf(strText, "收到下载F10 %d 个", pdl->m_lCount);
                                    break;
                                case CLASS_MKTINFO:
                                    sprintf(strText, "收到下载综合资讯 %d 个", pdl->m_lCount);
				                  
                             
                                 break;
                                default:
                                    break;
                                }
                                SetDlgItemText(IDC_DOWN_LOAD, strText);
                            }
                                 *     */
                                Console.WriteLine("SC_DLXX");
                            }
                            break;
                        case SC_DL_TRACE:		// 分笔明细下载
                            {
                                SC_Download pdl = (SC_Download)m.GetLParam(typeof(SC_Download));
                                offset = Marshal.SizeOf(typeof(SC_Download));
                                stockrecsize = Marshal.SizeOf(typeof(RCV_PANKOU_STRUCTEx));
                                Console.WriteLine("收到下载分笔数据 " + pdl.m_lCount.ToString());

                                for (i = 0; i < pdl.m_lCount; i++)
                                {
                                    RCV_PANKOU_STRUCTEx record = (RCV_PANKOU_STRUCTEx)Marshal.PtrToStructure
                                       (new IntPtr(m.LParam.ToInt32() + stockrecsize * i + offset), typeof(RCV_PANKOU_STRUCTEx));

                                    Console.WriteLine(string.Format("{0} \t {1} \t {2} \t  {3} \r\n",
                                      m_timeToDateTime(record.m_time), record.m_fNewPrice, record.m_fVolume, record.m_fBuyPrice[0]));

                                }

                            }
                            break;
                        default:
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                StMyFunction.textwrite(string.Format("time:{0} \t接收出错:{1} \t case is :{2} ", DateTime.Now, ex.Message, ex.Source.ToString()));
            }
            base.WndProc(ref m);
        }
        #region 公用属性
        public void DrvOpen()
        {

            string dllpath = @getScPath() + @"\scstock.dll";

            if (!Drvloaded && File.Exists(dllpath))
            {


                libraryHandle = LoadLibrary(@dllpath);
                IntPtr procaddr1 = GetProcAddress(libraryHandle, "SCInit");
                LoadDll dyloaddll = (LoadDll)Marshal.GetDelegateForFunctionPointer(procaddr1, typeof(LoadDll));



                SC_InitAsk sca = new SC_InitAsk();			// 引擎初始化包
                sca.m_Head.m_nType = SC_INIT;

                sca.m_dwSoftware = Wealth_Lab_ID;

                sca.m_hWnd = this.Handle.ToInt32();
                sca.m_nMsg = WM_USER;


                //Console.WriteLine(Marshal.SizeOf(sca));
                if (dyloaddll(sca, Marshal.SizeOf(sca)) == true)
                //if (dyloaddll(buffer, Marshal.SizeOf(sca)) == true)
                {

                    Drvloaded = true;
                    Console.WriteLine("{0} 成功打开数畅。",DateTime.Now);
                    //toolStripMenuItem_Open.Enabled = false;
                    //toolStripMenuItem_Close.Enabled = true;

                }
                else
                {
                    Drvloaded = false;
                    //toolStripMenuItem_Close.Enabled = false;
                    //toolStripMenuItem_Open.Enabled = true;
                }
            }
        }

        public void DrvClose()
        {
            if (Drvloaded)
            {

                IntPtr procaddr2 = GetProcAddress(libraryHandle, "SCQuit");
                UnLoadDll dyunloaddll = (UnLoadDll)Marshal.GetDelegateForFunctionPointer(procaddr2, typeof(UnLoadDll));
                dyunloaddll();
                Console.WriteLine("{0} 成功关闭数畅。",DateTime.Now);
                Drvloaded = false;
                //toolStripMenuItem_Close.Enabled = false;
                //toolStripMenuItem_Open.Enabled = true;

            }
        }

        public void SCAskData(object item, int nsize)
        {
            if (Drvloaded == true)
            {
                IntPtr procadd_askdata = GetProcAddress(libraryHandle, "SCAskData");
                AskData scaskdata = (AskData)Marshal.GetDelegateForFunctionPointer(procadd_askdata, typeof(AskData));
                scaskdata(item, nsize);
            }
        }

        public DateTime m_timeToDateTime(uint mtime)
        {
            DateTime re_time = new DateTime(1970, 1, 1).AddSeconds(mtime).ToLocalTime();
            return re_time;
        }
        public ushort GetMarketCode(string w_market)
        {
            ushort re_marketcode = BitConverter.ToUInt16(System.Text.Encoding.ASCII.GetBytes(w_market.Trim()), 0);
            return re_marketcode;
        }
        public string GetMarketName(ushort w_market)
        {
            string re_marketname = System.Text.Encoding.ASCII.GetString(BitConverter.GetBytes(w_market));
            return re_marketname.Trim();
        }
        /// <summary>
        ///  数畅请求5Min 数据 DateTime 转为SC_KineAsk 的m_Begin and m_End 格式（int） 函数
        /// </summary>
        /// <param name="inputdt">DateTime 要有小时和分钟数据如 :
        ///调用：    new DateTime(2006, 6, 30, 9, 30, 0)
        /// </param>
        /// <returns></returns>
        public int DatetimeTo5MinAsk(DateTime inputdt)
        {

            TDate tm;
            tm.m_Year = (uint)inputdt.Year;
            tm.m_Month = (uint)inputdt.Month;
            tm.m_Day = (uint)inputdt.Day;
            tm.m_Hour = (uint)inputdt.Hour;
            tm.m_Minute = (uint)inputdt.Minute;
            uint result = (tm.m_Year << (32 - 12)) +
                          (tm.m_Month << (32 - 4 - 12)) +
                          (tm.m_Day << (32 - 4 - 12 - 5)) +
                          (tm.m_Hour << (32 - 4 - 12 - 5 - 5));
            return (int)result;

        }
        //zzz
        /// <summary>
        ///  请求各类数据.
        /// </summary>
        /// <param name="Type">数据类型 SCDataType</param>
        /// <param name="symbol">证券代码</param>
        /// <param name="dateTime1">开始时间，可以是DateTime.MinValue</param>
        /// <param name="dateTime2">结束时间，可以是DateTime.MaxValue</param>
        /// <returns></returns>
        public int requestdata(SCDataType Type, string symbol, DateTime dateTime1, DateTime dateTime2)
        {
            if (Drvloaded && (MKTDATA.m_lDate > 0))
            {
                DateTime dt1 = dateTime1;
                DateTime dt2 = dateTime2;
                string[] Symbolsplit = symbol.Split('.');
                switch (Type)
                {
                    case SCDataType.bi5Minutes:
                        uint m_Year, m_Month, m_Day;
                        m_Year = MKTDATA.m_lDate / 10000;
                        m_Month = MKTDATA.m_lDate % 10000 / 100;
                        m_Day = MKTDATA.m_lDate % 100;

                        if (dateTime1 == DateTime.MinValue) { dt1 = new DateTime(1990, 1, 1, 9, 0, 0); }//zzz
                        if (dateTime2 == DateTime.MaxValue) { dt2 = new DateTime((int)m_Year, (int)m_Month, (int)m_Day, 15, 0, 0); }//zzz
                        //DateTime dtBegin = dt1;//zzz
                        //DateTime dtEnd = dt2;//zzz

                        SC_KLineAsk pk1;
                        pk1.m_Head.m_nType = SC_KLINE;
                        pk1.m_Head.m_cStatus = 1;
                        pk1.m_Head.m_lIndex = m_lASkIndex;
                        pk1.m_sID.m_nIndex = (short)(SC_CODETABLE.GetIndex(Symbolsplit[1].Trim(), Symbolsplit[0].Trim()));
                        pk1.m_sID.m_wMarket = GetMarketCode(Symbolsplit[1].Trim());
                        pk1.m_wDataType = KLINE_MIN5DATA;

                        pk1.m_tBegin = DatetimeTo5MinAsk(dt1);
                        pk1.m_tEnd = DatetimeTo5MinAsk(dt2);

                        SCAskData(pk1, Marshal.SizeOf(typeof(SC_KLineAsk)));
                        break;
                    case SCDataType.biDaily:
                        SC_KLineAsk pk2;
                        pk2.m_Head.m_nType = SC_KLINE;
                        pk2.m_Head.m_cStatus = 1;
                        pk2.m_Head.m_lIndex = m_lASkIndex;
                        pk2.m_sID.m_nIndex = (short)(SC_CODETABLE.GetIndex(Symbolsplit[1].Trim(), Symbolsplit[0].Trim()));
                        pk2.m_sID.m_wMarket = GetMarketCode(Symbolsplit[1].Trim());
                        pk2.m_wDataType = KLINE_DAYDATA;
                        //zzz
                        if (dateTime1 == DateTime.MinValue)
                        {
                            pk2.m_tBegin = 19900101;
                        }
                        else
                        {
                            pk2.m_tBegin = dt1.Year * 10000 + dt1.Month * 100 + dt1.Day;//zzz
                        }
                        if (dt2 == DateTime.MaxValue)
                        {
                            pk2.m_tEnd = (int)MKTDATA.m_lDate;
                        }
                        else
                        {
                            pk2.m_tEnd = dt2.Year * 10000 + dt2.Month * 100 + dt2.Day;//zzz  (int)MKTDATA.m_lDate
                        }

                        SCAskData(pk2, Marshal.SizeOf(typeof(SC_KLineAsk)));
                        break;
                    case SCDataType.biTicks:
                        SC_PankouAsk pk3;
                        pk3.m_Head.m_nType = SC_PANKOU;
                        pk3.m_Head.m_cStatus = 1;
                        pk3.m_Head.m_lIndex = m_lASkIndex;
                        pk3.m_sID.m_nIndex = (short)(SC_CODETABLE.GetIndex(Symbolsplit[1].Trim(), Symbolsplit[0].Trim()));
                        pk3.m_sID.m_wMarket = GetMarketCode(Symbolsplit[1].Trim());
                        pk3.m_lDate = MKTDATA.m_lDate;
                        SCAskData(pk3, Marshal.SizeOf(typeof(SC_PankouAsk)));
                        break;
                    default:
                        break;
                }
                m_lASkIndex++;
                return (m_lASkIndex - 1);
            }
            return -1;
        }

        public int requestdata(SCDataType Type, string Symbol)
        {
            if (Drvloaded && (MKTDATA.m_lDate > 0))
            {
                string[] Symbolsplit = Symbol.Split('.');
                switch (Type)
                {
                    case SCDataType.bi5Minutes:
                        uint m_Year, m_Month, m_Day;
                        m_Year = MKTDATA.m_lDate / 10000;
                        m_Month = MKTDATA.m_lDate % 10000 / 100;
                        m_Day = MKTDATA.m_lDate % 100;

                        DateTime dtBegin = new DateTime(1990, 1, 1, 9, 0, 0);
                        DateTime dtEnd = new DateTime((int)m_Year, (int)m_Month, (int)m_Day, 15, 0, 0);

                        SC_KLineAsk pk1;
                        pk1.m_Head.m_nType = SC_KLINE;
                        pk1.m_Head.m_cStatus = 1;
                        pk1.m_Head.m_lIndex = m_lASkIndex;
                        pk1.m_sID.m_nIndex = (short)(SC_CODETABLE.GetIndex(Symbolsplit[1].Trim(), Symbolsplit[0].Trim()));
                        pk1.m_sID.m_wMarket = GetMarketCode(Symbolsplit[1].Trim());
                        pk1.m_wDataType = KLINE_MIN5DATA;

                        pk1.m_tBegin = DatetimeTo5MinAsk(dtBegin);
                        pk1.m_tEnd = DatetimeTo5MinAsk(dtEnd);

                        SCAskData(pk1, Marshal.SizeOf(typeof(SC_KLineAsk)));
                        break;
                    case SCDataType.biDaily:
                        SC_KLineAsk pk2;
                        pk2.m_Head.m_nType = SC_KLINE;
                        pk2.m_Head.m_cStatus = 1;
                        pk2.m_Head.m_lIndex = m_lASkIndex;
                        pk2.m_sID.m_nIndex = (short)(SC_CODETABLE.GetIndex(Symbolsplit[1].Trim(), Symbolsplit[0].Trim()));
                        pk2.m_sID.m_wMarket = GetMarketCode(Symbolsplit[1].Trim());
                        pk2.m_wDataType = KLINE_DAYDATA;

                        pk2.m_tBegin = 19900101;
                        pk2.m_tEnd = (int)MKTDATA.m_lDate;

                        SCAskData(pk2, Marshal.SizeOf(typeof(SC_KLineAsk)));
                        break;
                    case SCDataType.biTicks:
                        SC_PankouAsk pk3;
                        pk3.m_Head.m_nType = SC_PANKOU;
                        pk3.m_Head.m_cStatus = 1;
                        pk3.m_Head.m_lIndex = m_lASkIndex;
                        pk3.m_sID.m_nIndex = (short)(SC_CODETABLE.GetIndex(Symbolsplit[1].Trim(), Symbolsplit[0].Trim()));
                        pk3.m_sID.m_wMarket = GetMarketCode(Symbolsplit[1].Trim());
                        pk3.m_lDate = MKTDATA.m_lDate;
                        SCAskData(pk3, Marshal.SizeOf(typeof(SC_PankouAsk)));
                        break;
                    default:
                        break;
                }
                m_lASkIndex++;
                return (m_lASkIndex - 1);
            }
            return -1;
        }




        #endregion

        # region 代码表类

        public class CodeTable
        {
            private Dictionary<string, Dictionary<short, StockInfo>> SC_CodeTable = new Dictionary<string, Dictionary<short, StockInfo>>();
            public CodeTable()
            {

            }
            public void addData(string w_market, short n_index, StockInfo stockinfo)
            {
                try
                {
                    w_market = w_market.Trim();


                    lock (SC_CodeTable)
                    {
                        if (w_market != "")
                        {
                            if (!SC_CodeTable.ContainsKey(w_market))
                            {
                                SC_CodeTable.Add(w_market, new Dictionary<short, StockInfo>());
                            }
                            Dictionary<short, StockInfo> sc_codetable = SC_CodeTable[w_market];

                            if (sc_codetable.ContainsKey(n_index))
                            {
                                sc_codetable[n_index] = stockinfo;
                            }
                            else
                            {
                                sc_codetable.Add(n_index, stockinfo);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    StMyFunction.textwrite(string.Format(" CodeTable AddData error !! Time:{0}   {1}",
                                               DateTime.Now, ex.Message));
                }
            }

            public short GetIndex(string w_market, string sccode)
            {
                w_market = w_market.Trim();
                sccode = sccode.Trim();
                short re_index = -1;
                try
                {
                    lock (SC_CodeTable)
                    {
                        if (w_market != "")
                        {
                            if (SC_CodeTable.ContainsKey(w_market))
                            {
                                foreach (short tempkey in SC_CodeTable[w_market].Keys)
                                {
                                    if (SC_CodeTable[w_market][tempkey].m_szLabel.Trim() == sccode)
                                    {
                                        re_index = tempkey;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    StMyFunction.textwrite(string.Format(" CodeTable GetIndex error !! Time:{0}   {1}",
                                             DateTime.Now, ex.Message));

                }
                return re_index;
            }
            /*
            public StockInfo GetStockInfo(string w_market, short n_index)
            {
                StockInfo re_stockinfo = new StockInfo();
                w_market = w_market.Trim();
                try
                {
                    lock (SC_CodeTable)
                    {
                        if (w_market != "")
                        {
                            if (SC_CodeTable.ContainsKey(w_market))
                            {
                                if (SC_CodeTable[w_market].ContainsKey(n_index))
                                {
                                    re_stockinfo = SC_CodeTable[w_market][n_index];
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    StMyFunction.textwrite(string.Format(" CodeTable GetStockInfo error !! Time:{0}   {1}",
                                              DateTime.Now, ex.Message));
                }
                return re_stockinfo;
            }*/
            public string GetSymbolName(string SymbolCode)
            {
                string SymbolName = string.Empty;
                try
                {
                    string[] SymbolCodeSplit = SymbolCode.Split('.');
                    string w_market = SymbolCodeSplit[1].Trim();
                    string sccode = SymbolCodeSplit[0].Trim();


                    lock (SC_CodeTable)
                    {
                        if (w_market != "")
                        {
                            if (SC_CodeTable.ContainsKey(w_market))
                            {
                                foreach (short tempkey in SC_CodeTable[w_market].Keys)
                                {
                                    if (SC_CodeTable[w_market][tempkey].m_szLabel.Trim() == sccode)
                                    {
                                        SymbolName = SC_CodeTable[w_market][tempkey].m_szName.Trim();
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    StMyFunction.textwrite(string.Format(" CodeTable GetSymbolName error !! Time:{0}   {1}",
                                              DateTime.Now, ex.Message));
                }
                return SymbolName;
            }
            public string GetSymbolCode(string w_market, short n_index)
            {
                string SymbolCode = string.Empty;
                w_market = w_market.Trim();
                try
                {
                    lock (SC_CodeTable)
                    {
                        if (w_market != "")
                        {
                            if (SC_CodeTable.ContainsKey(w_market))
                            {
                                if (SC_CodeTable[w_market].ContainsKey(n_index))
                                {

                                    SymbolCode = SC_CodeTable[w_market][n_index].m_szLabel;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    StMyFunction.textwrite(string.Format(" CodeTable GetStockInfo error !! Time:{0}   {1}",
                                              DateTime.Now, ex.Message));
                }
                return SymbolCode;
            }
        }
        #endregion



        //private void toolStripMenuItem_Open_Click(object sender, EventArgs e)
        //{
        //    this.DrvOpen();
        //}

        //private void toolStripMenuItem_Close_Click(object sender, EventArgs e)
        //{
        //    this.DrvClose();
        //}
        private string getScPath()
        {
            string scpath = string.Empty;
            RegistryKey rk = Registry.LocalMachine.OpenSubKey("SOFTWARE\\SZGWT", true);
            if (rk != null)
            {
                scpath = (String)rk.GetValue("SCPath");
            }
            return scpath;
        }






    }

    #region common
    public class common
    {
    }

    #region 数畅行情结构



    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SCHead
    {
        // 请求包头
        public ushort m_nType;					// 请求/应答类型，SC_MARKET、SC_IMCONTENT等
        public byte m_cStatus;					// 当为应答包时，m_cStatus=1成功，m_cStatus=0失败
        public int m_lIndex;					// 包的唯一索引。不要设为0，请求的时候赋值，并在应答包中
        // 判断是否与请求包中的相同，如果不同，则表示不是这个请求包对应的应答包
        // 如果这个值为0，表示不是请求引起的数据变化
    };



    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct StockInfo
    {					// 证券
        private const int STKLABEL_LEN = 10;		// 股号数据长度，为交易所发布的统一代码
        private const int STKNAME_LEN = 32;		// 股名长度

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STKLABEL_LEN)]
        public string m_szLabel;		// 股票代码,以'\0'结尾
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STKNAME_LEN)]
        public string m_szName;			// 股票名称,以'\0'结尾
        public short m_nHand;						// 每手股数
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SCMarket
    {					//市场内容
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 3)]
        public string scmarketcode;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
        public string m_Name;				//市场名称
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 5)]
        public string m_CShortName;		//中文简称

        public uint m_lProperty;			//市场属性（未定义）
        public uint m_lDate;				//数据日期（20030114）
        public short m_PeriodCount;			//交易时段个数
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public short[] m_OpenTime;			//开市时间 1,2,3,4,5
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public short[] m_CloseTime;			//收市时间 1,2,3,4,5
        public short m_nCount;				//该市场的证券个数
        //public StockInfo  m_Siif;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct StockID
    {					//证券标识
        public ushort m_wMarket;				//市场代码
        public short m_nIndex;				//在该市场SCMarket::m_Siff中的偏移
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct RCV_NOW_STRUCTEx
    {
        public StockID m_sID;
        public uint m_time;							// 成交时间

        public float m_fLastClose;					// 昨收
        public float m_fOpen;						// 今开
        public float m_fHigh;						// 最高
        public float m_fLow;							// 最低
        public float m_fNewPrice;					// 最新
        public float m_fVolume;						// 成交量
        public float m_fAmount;						// 成交额

        public int m_lStroke;						// 本次实际成交笔数
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fBuyPrice;					// 申买价1,2,3,4,5
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fBuyVolume;				// 申买量1,2,3,4,5
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fSellPrice;				// 申卖价1,2,3,4,5
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fSellVolume;				// 申卖量1,2,3,4,5
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct RCV_PANKOU_STRUCTEx
    {
        public uint m_time;							// UCT
        public float m_fHigh;						// 最高
        public float m_fLow;							// 最低
        public float m_fNewPrice;					// 最新
        public float m_fVolume;						// 成交量
        public float m_fAmount;						// 成交额
        public int m_lStroke;						// 本次实际成交笔数
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fBuyPrice;					// 申买价1,2,3,4,5
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fBuyVolume;				// 申买量1,2,3,4,5
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fSellPrice;				// 申卖价1,2,3,4,5
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public float[] m_fSellVolume;				// 申卖量1,2,3,4,5
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct RCV_HISTORY_STRUCTEx
    {
        public uint m_time;				//UCT
        public float m_fOpen;			//开盘
        public float m_fHigh;			//最高
        public float m_fLow;				//最低
        public float m_fClose;			//收盘
        public float m_fVolume;			//量
        public float m_fAmount;			//额
        public ushort m_wAdvance;			//涨数,仅大盘有效
        public ushort m_wDecline;			//跌数,仅大盘有效
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct RCV_POWER_STRUCTEx
    {
        public uint m_time;				// UCT
        public float m_fGive;			// 每股送
        public float m_fPei;				// 每股配
        public float m_fPeiPrice;		// 配股价,仅当 m_fPei!=0.0f 时有效
        public float m_fProfit;			// 每股红利

    }

    ///////////////////////////////////////////////////////////////////////////////////
    // 引擎初始化包
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_InitAsk
    {							// 发出初始化请求，调用SCInit时使用，无对应返回包
        public SCHead m_Head;
        public UInt32 m_dwSoftware;		// 分析软件标识，由数畅分配
        public Int32 m_hWnd;				// 用来接收数据的窗口句柄
        public UInt32 m_nMsg;				// 用来接收数据的消息
    }


    ///////////////////////////////////////////////////////////////////////////////////
    //请求包和应答包
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_MarketReply
    {		// 这个包无需请求即可收到，在市场信息变化的时候就可收到
        public SCHead m_Head;
        public SCMarket m_Market;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_NowDataReply
    {	// 这个包无需请求即可收到。数据有更新，会自动发送
        public SCHead m_Head;
        public short m_nCount;
        // public RCV_NOW_STRUCTEx m_Now;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_PankouAsk
    {				// 请求一天盘口数据，现支持当天，历史盘口将通过下载获得
        public SCHead m_Head;
        public StockID m_sID;
        public uint m_lDate;	// FORMAT: 20010305
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_PankouReply
    {
        public SCHead m_Head;
        public StockID m_sID;
        public int m_lDate;			// FORMAT: 20010305
        public float m_fLastClose;		// 昨收
        public float m_fOpen;			// 今开
        public int m_lCount;
        //public RCV_PANKOU_STRUCTEx  m_Data;
    }


    // 注意：
    // 1、由于服务器的设置，可能只能收到最近某一时段的数据，更多的数据，可以通过下载获得。
    // 2、对于K线请求包，当表示日线时，long的格式为yyyymmdd，
    // 3、对于K线请求包，当为五分钟线时，long的格式如下面这个TDate结构所示
    //	struct TDate {		// 五分钟时间格式
    //		unsigned long m_Minute : 6;
    //		unsigned long m_Hour : 5;
    //		unsigned long m_Day  : 5;
    //		unsigned long m_Month : 4; 
    //		unsigned long m_Year : 12;
    //	};
    // 4、关于时间的转行，我们提供例子中有示范代码，可参考。
    // 5、对K线应答包，日线和五分钟的时间统一为uint格式，已经包含日期和分钟信息。
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_KLineAsk
    {
        public SCHead m_Head;
        public StockID m_sID;
        public ushort m_wDataType;		// KLINE_DAYDATA or KLINE_MIN5DATA
        public int m_tBegin;			// 开始时间或位置，0表示从第一个数据开始
        public int m_tEnd;				// 结束时间或请求数量
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_KLineReply
    {
        public SCHead m_Head;
        public StockID m_sID;
        public ushort m_wDataType;		// KLINE_DAYDATA or KLINE_MIN5DATA
        public int m_lDataCount;		// m_pData数量
        //public RCV_HISTORY_STRUCTEx  m_pData;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_CQAsk
    {
        public SCHead m_Head;
        public StockID m_sID;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_CQReply
    {
        public SCHead m_Head;
        public StockID m_sID;
        public short m_nCount;
        //public RCV_POWER_STRUCTEx  m_pData;			// m_head不使用
    }

    //////////////////////////////////////////////////////////////////////////////////
    //////////////  信息地雷接口

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SCIMType
    {					// 信息分类，如重大事项、公司公告、个股点评等
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 8)]
        public string m_cFlag;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 24)]
        public string m_cTitle;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_IMTypeReply
    {				// 无需请求，自动返回
        public SCHead m_Head;
        public byte m_cVendor;
        public byte m_cClass;
        public short m_nSize;
        //public SCIMType  m_Type;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SCIMTitle
    {
        public uint m_lID;			// 标题ID
        public int m_lChkSum;		// 新增加，所对应的内容的Checksum
        public uint m_lDate;			// yyyymmdd
        public uint m_lTime;			// hhmmss
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 8)]
        public string m_cFlag;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 9)]
        public string m_cMainType;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 17)]
        public string m_cSubtype;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
        public string m_cTitle;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 9)]
        public string m_szLabel;	// 股票代码,以'\0'结尾
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SCIMTitleID
    {
        public uint m_lID;			// 标题ID
        public int m_lChkSum;		// 新增加，所对应的内容的Checksum
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_IMTitleAsk
    {				// 请求某个时间段内信息地雷标题
        public SCHead m_Head;
        public byte m_cClass;
        public StockID m_sID;			//对于个股资讯、基本资料F10使用m_sID，交易所公告只使用
        //其中的市场，新闻、综合资讯不使用这个字段
        public int m_lStartDate;	//新闻、综合资讯、交易所公告只使用m_lStartDate，m_lEndDate不使用
        public int m_lEndDate;		//个股资讯使用m_lStartDate，m_lEndDate；
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_IMTitleReply
    {
        public SCHead m_Head;
        public byte m_cVendor;		// 应答包有厂商
        public byte m_cClass;
        public StockID m_sID;				//对于个股资讯、基本资料F10、使用m_sID,
        public short m_nSize;			// 标题个数
        //public SCIMTitle  m_IMTitle;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_IMDataAsk
    {					// 信息地理内容请求，一次可请求多个标题的内容
        public SCHead m_Head;
        //	char			m_cVendor;			// 请求包没有厂商代码
        public byte m_cClass;
        public StockID m_sID;				//对于个股资讯、基本资料、个股信息地雷使用m_sID,
        public short m_nSize;			// 标题ID个数
        public int m_lDate;			//日期，新闻、交易所公告、综合资讯需要，一次只能设一个日期
        //public SCIMTitleID  m_ID;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SCIMData
    {						// 信息地理内容
        public SCIMTitle m_IMTitle;
        public uint m_lDataLength;
        //public byte [] m_cData;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_IMDataReply
    {					// 信息地雷内容应答，一次可返回多个标题和内容
        public SCHead m_Head;
        public byte m_cVendor;
        public byte m_cClass;
        public StockID m_sID;				//对于个股资讯、基本资料F10使用m_sID,
        public int m_lDate;			//对于新闻、综合资讯、财经新闻、券商信息使用m_lDate
        public short m_nSize;
        //public SCIMData  m_Data;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct IMTitleEx
    {
        private const int TITLE_LEN = 64;	       // 信息地雷标题长度
        public uint m_lOffset;
        public uint m_lDataLength;
        public uint m_time;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = TITLE_LEN)]
        public string m_cCaption;
    }


    #region  在引擎里面进行下载操作之后，会自动收到这个包，里面包含了下载下来的指定数据。
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_Download_detail_Ex
    {							// F10、交易所公告、新闻、综合资讯下载
        public byte m_cClass;		// 类别
        public IMTitleEx m_Title;		// 标题，实际条数等于m_lCount，下面的m_cData据此后推
        public byte m_cData;		// 实际位置在m_Title[m_lCount]之后
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct SC_Download
    {
        // 数据下载接口
        public SCHead m_Head;			// m_head中仅m_nType有效
        public StockID m_sID;
        public int m_lCount;		// // m_KLine,m_power,m_Trace,m_Title的个数

    }


    #endregion
    public enum TSCInfo
    {
        INFO_VERSION = 1,
        INFO_USERNAME = 2,
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct TInfoHead
    {
        public TSCInfo m_InfoType;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct TRInfoVersion
    {
        public TSCInfo m_InfoType;
        public int m_lVersion;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct TRInfoUsername
    {
        public TSCInfo m_InfoType;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
        public string m_UserName;
    }

    public struct TDate
    {
        public uint m_Minute;
        public uint m_Hour;
        public uint m_Day;
        public uint m_Month;
        public uint m_Year;
    }
    public enum SCDataType
    {
        bi5Minutes = 0,//五分钟
        biDaily = 1,//日线
        biTicks = 2,//分笔
        biData = 3, //除权
    }
    #endregion
    public struct WLDTBar_STRUCT               //WLD K线结构
    {

        public float fOpen;			//开盘价
        public float fHigh;			//最高价		
        public float fLow;				//最低价
        public float fClose;			//收盘价
        public int fVolume;	       //成交量

        public float fBid;             //买价
        public float fAsk;             //卖价
    }
    #endregion

    #region stMyfunction
    public static class StMyFunction
    {

        public static SortedList<DateTime, WLDTBar_STRUCT> tick2min(SortedList<DateTime, WLDTBar_STRUCT> tickbars, int interval, bool isnetvol)
        {
            SortedList<DateTime, WLDTBar_STRUCT> Tbars = new SortedList<DateTime, WLDTBar_STRUCT>();
            List<WLDTBar_STRUCT> templist = new List<WLDTBar_STRUCT>();
            DateTime comparetime;
            try
            {
                if (tickbars.Count > 0)
                {

                    DateTime temptime = tickbars.Keys[0];
                    comparetime = comparetime_for_min(temptime, interval);

                    //当前时间与比较值之差是否在interval 内
                    for (int i = 0; i < tickbars.Count; i++)
                    {
                        DateTime bargain_time = (DateTime)tickbars.Keys[i];
                        TimeSpan compareinterval = bargain_time - comparetime;

                        if ((compareinterval.TotalMinutes) < interval)
                        {
                            templist.Add(tickbars.Values[i]);
                            if (i == tickbars.Count - 1)
                            {
                                DateTime Tbars_time = new DateTime(comparetime.Year, comparetime.Month, comparetime.Day, comparetime.Hour, comparetime.Minute, 0);

                                if (Tbars.ContainsKey(Tbars_time))
                                {   //如果已存在时间点数据，就覆盖
                                    Tbars[Tbars_time] = change_tick_to_minute(templist, isnetvol);
                                }
                                else
                                {
                                    Tbars.Add(Tbars_time, change_tick_to_minute(templist, isnetvol));
                                }
                                templist.Clear();
                            }
                        }
                        else
                        {
                            DateTime Tbars_time = new DateTime(comparetime.Year, comparetime.Month, comparetime.Day, comparetime.Hour, comparetime.Minute, 0);
                            if (Tbars.ContainsKey(Tbars_time))
                            {
                                Tbars[Tbars_time] = change_tick_to_minute(templist, isnetvol);
                            }
                            else
                            {
                                Tbars.Add(Tbars_time, change_tick_to_minute(templist, isnetvol));
                            }
                            //确定下一个比较值
                            comparetime = comparetime_for_min(bargain_time, interval);
                            templist.Clear();
                            templist.Add(tickbars.Values[i]);

                        }
                    }

                }
            }
            catch (Exception ex)
            {
                StMyFunction.textwrite(string.Format("time:{0} \t tick2min error! {1}", DateTime.Now, ex.Message));
            }
            return Tbars;
        }

        //找出当前某时间段内开盘价、最高价、最低价、收盘价、累计成交量
        public static WLDTBar_STRUCT change_tick_to_minute(List<WLDTBar_STRUCT> data, bool isnetvol)
        {
            List<WLDTBar_STRUCT> templist = data;
            WLDTBar_STRUCT data_min = new WLDTBar_STRUCT();
            try
            {
                if (templist.Count > 0)
                {
                    float Xhigh = 0;
                    float Xlow = 0;
                    int amountvol = 0;
                    for (int i = 0; i < templist.Count; i++)
                    {
                        WLDTBar_STRUCT tempdata = templist[i];
                        if (i == 0)
                        {
                            data_min.fOpen = tempdata.fOpen;
                            Xhigh = tempdata.fClose;
                            Xlow = tempdata.fClose;
                        }
                        else
                        {
                            if (tempdata.fClose > Xhigh)
                            {
                                Xhigh = tempdata.fClose;
                            }
                            if (tempdata.fClose < Xlow)
                            {
                                Xlow = tempdata.fClose;
                            }

                        }
                        //累计成交量
                        amountvol += (int)tempdata.fVolume;
                        if (i == (templist.Count - 1))
                        {
                            data_min.fClose = tempdata.fClose;
                            data_min.fBid = tempdata.fBid;
                            data_min.fAsk = tempdata.fBid;
                            if (isnetvol)
                            {
                                data_min.fVolume = amountvol;
                            }
                            else
                            {
                                data_min.fVolume = (int)tempdata.fVolume;
                            }
                        }
                    }
                    data_min.fHigh = Xhigh;
                    data_min.fLow = Xlow;



                }
            }
            catch (Exception ex)
            {
                StMyFunction.textwrite(string.Format("time:{0} \t change_tick_to_minute error! {1}", DateTime.Now, ex.Message));
            }
            return data_min;
        }

        ////实时数据累计成交量转真实成交量
        public static SortedList<DateTime, WLDTBar_STRUCT> vol_to_netvol(SortedList<DateTime, WLDTBar_STRUCT> data)
        {
            int prevol = 0;
            DateTime predt = new DateTime(1970, 1, 1); ;
            SortedList<DateTime, WLDTBar_STRUCT> templist = data;
            try
            {
                if (templist != null)
                {

                    for (int i = 0; i < templist.Count; i++)
                    {
                        WLDTBar_STRUCT oldbars = templist.Values[i];
                        WLDTBar_STRUCT newbars = new WLDTBar_STRUCT();

                        newbars.fOpen = oldbars.fOpen;
                        newbars.fHigh = oldbars.fHigh;
                        newbars.fLow = oldbars.fLow;
                        newbars.fClose = oldbars.fClose;
                        newbars.fBid = 0;
                        newbars.fAsk = 0;
                        //判断是否为同一日数据
                        if (templist.Keys[i].Date > predt.Date)
                        {
                            newbars.fVolume = oldbars.fVolume;
                        }
                        else
                        {
                            newbars.fVolume = oldbars.fVolume - prevol;
                        }

                        prevol = oldbars.fVolume;
                        predt = templist.Keys[i];
                        templist[templist.Keys[i]] = newbars;

                    }

                }
            }
            catch (Exception ex)
            {
                StMyFunction.textwrite(string.Format("time:{0} \t vol_to_netvol error! {1}", DateTime.Now, ex.Message));
            }
            return templist;
        }

        public static DateTime comparetime_for_min(DateTime inputtime, int interval)
        {
            DateTime comparetime = new DateTime(); ;
            DateTime temptime = inputtime;
            //确定比较值
            try
            {
                if (((temptime.Minute) % interval) == 0)
                {
                    comparetime = new DateTime(temptime.Year, temptime.Month, temptime.Day, temptime.Hour, temptime.Minute, 0);
                }
                else
                {//判定是否属于0-interval 
                    if (temptime.Minute < interval)
                    {   //如是比较值为yy:MM:HH:0:0
                        comparetime = new DateTime(temptime.Year, temptime.Month, temptime.Day, temptime.Hour, 0, 0);
                    }
                    else
                    {
                        int tempint = (temptime.Minute) % interval;
                        comparetime = new DateTime(temptime.Year, temptime.Month, temptime.Day, temptime.Hour, temptime.Minute - tempint, 0);
                    }
                }
            }
            catch (Exception ex)
            {
                StMyFunction.textwrite(string.Format("time:{0} \t vcomparetime_for_min error! {1}", DateTime.Now, ex.Message));
            }
            return comparetime;
        }



        public static void textwrite(string ErrText)
        {

            string FileName = Directory.GetCurrentDirectory() + "//SCAdapterLog.txt";

            Stream fstream = new FileStream(FileName, FileMode.OpenOrCreate);
            StreamWriter sw = new StreamWriter(fstream, Encoding.GetEncoding("GB2312"));

            sw.BaseStream.Seek(1, SeekOrigin.End);
            sw.WriteLine(ErrText);
            sw.Close();
            fstream.Close();
        }

        public static void WriteLog(string text)
        {

            string FileName = Directory.GetCurrentDirectory() + "\\FinToolsLog.txt";
            Stream fstream = new FileStream(FileName, FileMode.OpenOrCreate);
            StreamWriter sw = new StreamWriter(fstream, Encoding.GetEncoding("GB2312"));
            sw.BaseStream.Seek(1, SeekOrigin.End);
            sw.WriteLine("{0} - {1}", DateTime.Now, text);
            sw.Close();
            fstream.Close();
        }

    }
    #endregion

    #region SCRTSingleton

    public static class SCRTSingleton
    {
        static readonly SCRTcontrol scdrv = new SCRTcontrol();

        public static SCRTcontrol MyDrv
        {
            get
            {
                return scdrv;
            }
        }
        public static void close()
        {
            scdrv.DrvClose();
        }

    }
    #endregion
}
