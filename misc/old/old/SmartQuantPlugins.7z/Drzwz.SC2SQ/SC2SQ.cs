﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Threading;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Drawing.Design;
using SmartQuant;
using SmartQuant.Data;
using SmartQuant.Series;
using SmartQuant.Providers;
using SmartQuant.Instruments;
//using Drzwz.Schedule;

namespace Drzwz
{
    public class SC2SQ:IProvider ,IHistoryProvider 
    {

        public SC2SQ()
        {
            ProviderManager.Add(this);
        }
        #region 导入数据的方法
        private int askNo = 0;
        private bool sckline_runing = false;
        private bool bClosed = true;
        private bool bOpen = false;
        private List<int> askNoList = new List<int>();
        private string symbolRegex=string.Empty;
        private bool autoImport = true;

        [Category("设置"),Description("要导入数据的代码的正则表达式；若为空则导入默认的代码。"),DefaultValue("")]
        public string SymbolRegex
        {
            get { return this.symbolRegex; }
            set
            {
                this.symbolRegex = value.Trim();
            }
        }
        [Category("设置"), Description("true-连接后自动导入；false-连接后不导入，若运行中，则中断导入。"), DefaultValue("")]
        public bool AutoImport
        {
            get { return this.autoImport; }
            set
            {
                this.autoImport = value;
            }
        }
        private void doWork()
        {
            try
            {
                SCRTSingleton.MyDrv.DrvOpen();
                if (this.askNoList.Count > 0) this.askNoList.Clear();
                Console.WriteLine("{0} 开始导入复权数据和日线数据...",DateTime.Now);
                List<string> symbolList = new List<string>();
                DailySeries ds; 
                IDataSeries ids;
                string mkt = "";
                symbolList = SCRTSingleton.MyDrv.Symbols;
                int num = 0;
                bool regexIsNotEmpty = (this.symbolRegex!=string.Empty);
                foreach (string symbol in symbolList)
                {
                    Application.DoEvents();
                    if (!this.autoImport)
                    {
                        Console.WriteLine("{0} 处理了{1}个代码后，用户中断操作(AutoImport被设为False)。", DateTime.Now, num);
                        break;
                    }
                    if (regexIsNotEmpty)
                    {
                        if (!Regex.IsMatch(symbol, this.symbolRegex)) 
                            continue;
                    }
                    num++;
                    string securitytype = Drzwz.SQCommon.GetSecurityType(symbol);
                    if (";;Stock;Fund;ETF;Warrant;Index;".IndexOf(securitytype) > 0)
                    {
                        //bw.ReportProgress(1, symbol);//这里只报状态，不报百分比
                        //>>>>>>>>>>>>>>>> 导入PriceFactor
                        
                        DateTime startRequestDateTime = DateTime.MinValue;
                        //判断该代码是否已存在
                        mkt = symbol.Substring(symbol.LastIndexOf(".") + 1, symbol.Length - symbol.LastIndexOf(".") - 1);
                        Instrument instrument = InstrumentManager.Instruments[symbol];
                        if ( instrument== null)
                        {
                            instrument = new Instrument(symbol, securitytype);
                            instrument.SecurityDesc = SCRTSingleton.MyDrv.SC_CODETABLE.GetSymbolName(symbol);
                            instrument.SecurityExchange = mkt;
                            instrument.Save();
                        }
                        //是否有复权因子数据
                        SortedList<DateTime, double> factorList = new SortedList<DateTime, double>();
                        factorList = this.GetFactorList(symbol);
                        if (factorList.Count > 0)
                        {
                            //判断该代码对应的PriceFactor是否已存在
                            ids = instrument.GetDataSeries("PriceFactor");
                            if (ids == null)
                            {
                                ids = instrument.AddDataSeries("PriceFactor");
                            }
                            else
                            {
                                if (ids.Count > 0)
                                    startRequestDateTime = ids.LastDateTime.AddDays(1);
                            }
                            //
                            for (int i = 0; i < factorList.Count; i++)
                            {
                                PriceFactor pf = new PriceFactor();
                                pf.DateTime = factorList.Keys[i];
                                pf.Factor = factorList.Values[i];
                                if (pf.DateTime >= startRequestDateTime)
                                {
                                    ids.Add(pf.DateTime, pf);
                                }
                            }
                        }
                        //>>>>>>>>>>>>>>>>>>>>导入Daily
                        ds = instrument.GetDailySeries();
                        startRequestDateTime = DateTime.MinValue;
                        if (ds != null)
                        {
                            if (ds.Count > 0)
                                startRequestDateTime = ds.LastDateTime.AddDays(1);
                        }
                        //请求数据
                        if (startRequestDateTime <= SCRTSingleton.MyDrv.GetMarketDate(mkt))
                        {
                            //Console.WriteLine("startRequestDateTime={0} MarketDate={1}", startRequestDateTime, SCRTSingleton.MyDrv.GetMarketDate(mkt));
                            //Console.WriteLine("DoWork: {0}",askNo);
                            if (sckline_runing == false)
                            {
                                //Console.WriteLine("DoWork askNo>-1: {0}", askNo);
                                SCRTSingleton.MyDrv.OnSC_KLINE += new SC_KLINE_5MinOrDay_EventHandler(ProcessOnReply5MinOrDay);
                                bOpen = true;
                                sckline_runing = true;
                                
                            }
                            askNo = SCRTSingleton.MyDrv.requestdata(SCDataType.biDaily, symbol, startRequestDateTime, DateTime.MaxValue);
                            if (askNo > -1)
                            {

                                askNoList.Add(askNo);
                            }
                        }
                    }
                }
                Console.WriteLine(string.Format("{0} 共处理了{1}个代码。",DateTime.Now, num));
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message );
            }

        }
 
        private void ProcessOnReply5MinOrDay(SCRTcontrol sender, int replyNo, string mySymbol, List<RCV_HISTORY_STRUCTEx> e)
        {
            try
            {
                 if (askNoList.Contains(replyNo))
                {
                    askNoList.Remove(replyNo);
                    Instrument instrument = InstrumentManager.Instruments[mySymbol];
                    if (instrument != null)
                    {
                        //Console.WriteLine("ProcessOnReply5MinOrDay: {0} ", e.Count);
                        Daily daily; DateTime dt;
                        foreach (RCV_HISTORY_STRUCTEx record in e)
                        {
                            daily = new Daily();
                            dt =SCRTSingleton.MyDrv.m_timeToDateTime(record.m_time);
                            daily.DateTime = dt;
                            daily.Open = (double)record.m_fOpen;
                            daily.High = (double)record.m_fHigh;
                            daily.Low = (double)record.m_fLow;
                            daily.Close = (double)record.m_fClose;
                            daily.Volume = (long)record.m_fVolume;
                            instrument.Add(daily);
                        }
                    }
                    else
                    {
                        Console.WriteLine("不存在{0}instrument，无法添加Daily。", mySymbol);
                    }
                    
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message + "--ProcessOnreply5minorday");
            }
        }

        private string WWTPath = @"D:\Windin\WWT\";
        [Category("设置"),Description("万点终端的安装文件夹。"),
        Editor(typeof(System.Windows.Forms.Design.FolderNameEditor),typeof(System.Drawing.Design.UITypeEditor))]
        public string WindinPath
        {
            get { return this.WWTPath; }
            set 
            {
                this.WWTPath = value; 
            }
        }
        public SortedList<DateTime, double> GetFqyz(string filename, string Symbol)
        {
            try
            {
                SortedList<DateTime, double> mylst = new SortedList<DateTime, double>();
                string windFileName = filename;
                if (File.Exists(windFileName) == false)
                {
                    Console.WriteLine("错误:文件不存在");
                    return null;
                }
                FileStream fs = new FileStream(windFileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                BinaryReader br = new BinaryReader(fs);
                //string s = "";string ss="";
                fs.Position = 18;
                long recordCount = br.ReadUInt32();//第18字节开始的4B保存记录个数,接下来是每个记录,以0x09开头
                for (int record = 0; record < recordCount; record++)
                {
                    byte flag = br.ReadByte();
                    if (flag == '\x09')
                    {
                        string dm = new string(br.ReadChars(9));//代码
                        string rqs = new string(br.ReadChars(8));//日期
                        double yz = br.ReadSingle();//复权因子
                        fs.Position = fs.Position + 1;  //有个00字节
                        short notelen = br.ReadInt16(); //备注字符串长度
                        fs.Position = fs.Position + notelen;
                        //s=System.Text.Encoding.Default.GetString(br.ReadBytes(notelen));//备注字符串
                        //s=s.Replace("\x0D","").Replace("\x0A","");
                        //ss=dm+","+rq+","+yz.ToString() ;
                        //Console.WriteLine(ss);
                        if (dm == Symbol)
                        {
                            DateTime rq = new DateTime(int.Parse(rqs.Substring(0, 4)), int.Parse(rqs.Substring(4, 2)), int.Parse(rqs.Substring(6, 2)));
                            if (!mylst.ContainsKey(rq)) mylst.Add(rq, Math.Round(yz, 6));

                        }
                    }
                }
                fs.Close();
                br.Close();

                return mylst;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "--GetFqyz");
                return null;
            }
        }
        public SortedList<DateTime, double> GetFactorList(string symbol)
        {
            if (!WWTPath.EndsWith(@"\")) WWTPath = WWTPath + @"\";
            string filename = WWTPath + @"etc\hqafhis.dat";
            SortedList<DateTime, double> lst = GetFqyz(filename, symbol);
            filename = WWTPath + @"etc\hqafdelt.dat";
            SortedList<DateTime, double> lst2 = GetFqyz(filename, symbol);
            if (lst == null)
            {
                lst = lst2;
            }
            else
            {
                foreach (DateTime dt in lst2.Keys) if (!lst.ContainsKey(dt)) lst.Add(dt, lst2[dt]);
            }
            return lst;
        }

        #endregion

        #region IProvider 成员
        private bool isConnected = false;

        public void Connect(int timeout)
        {
            this.Connect();
            ProviderManager.WaitConnected(this, timeout);
        }
        public void Connect()
        {
            isConnected = true;
            if (Connected != null)
                Connected(this, new EventArgs());
            this.doWork();
            //Thread th = new Thread(new ThreadStart(this.doWork));
            //th.Start();
      }
        public event EventHandler Connected;
        public void Disconnect()
        {
            try
            {
                if (sckline_runing == true)
                {
                    SCRTSingleton.MyDrv.OnSC_KLINE -= new SC_KLINE_5MinOrDay_EventHandler(ProcessOnReply5MinOrDay);
                    sckline_runing = false;
                }
                SCRTSingleton.MyDrv.DrvClose();
                isConnected = false;
                if (Disconnected != null)
                    Disconnected(this, new EventArgs());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Disconnect：" + ex.Message);
            }
            
        }
        
        public event EventHandler Disconnected;

        public event ProviderErrorEventHandler Error;
        [Category("信息")]
        public byte Id
        {
            get { return 138; }
        }
        [Category("信息")]
        public bool IsConnected
        {
            get { return isConnected;  }
        }
        [Category("信息")]
        public string Name
        {
            get { return "SC2SQ"; }
        }
        [Category("信息")]
        public string Title
        {
            get { return "SC2SQ 自动将SC数据导入SQ。"; }
        }
        [Category("信息")]
        public string URL
        {
            get { return String.Empty; }
        }
        public void Shutdown()
        {
            try
            {
                SCRTSingleton.MyDrv.DrvClose();
            }
            catch
            {
            }
        }
        [Category("信息")]
        public ProviderStatus Status
        {
            get
            {
                if (!IsConnected)
                    return ProviderStatus.Disconnected;
                else
                    return ProviderStatus.Connected;
            }
        }

        public event EventHandler StatusChanged;

        #endregion

        #region IHistoryProvider 成员
        [Category("信息")]
        public bool BarSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool DailySupported
        {
            get { return false; }
        }

        public Bar[] GetBarHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, int barSize)
        {
            throw new NotImplementedException();
        }

        public Daily[] GetDailyHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, bool dividendAndSplitAdjusted)
        {
            throw new NotImplementedException();
        }

        public Quote[] GetQuoteHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }

        public Trade[] GetTradeHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }
        [Category("信息")]
        public bool QuoteSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool TradeSupported
        {
            get { return false; }
        }

        #endregion
    }
}
