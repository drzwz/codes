﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Threading;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Drawing.Design;
using SmartQuant;
using SmartQuant.Data;
using SmartQuant.Series;
using SmartQuant.Providers;
using SmartQuant.Instruments;

namespace Drzwz
{
    public class CSV2SQ : IProvider, IHistoryProvider
    {

        public CSV2SQ()
        {
            ProviderManager.Add(this);
        }
        #region 导入数据的方法
        private bool autoImport = true;
        [Category("设置"), Description("true-连接后自动导入；false-连接后不导入，若运行中，则中断导入。"), DefaultValue("")]
        public bool AutoImport
        {
            get { return this.autoImport; }
            set
            {
                this.autoImport = value;
            }
        }
        private string symbolRegex = @"((60\d{4}\.SH)|(0000\d\d\.SH)|(00\d{4}\.SZ)|(399\d{3}\.SZ)|(\w*\.(SQ|DQ|ZQ|CI)))";
        [Category("设置"), Description("要导入数据的代码的正则表达式；若为空则导入CSV文件中所有代码的数据。")]
        public string SymbolRegex
        {
            get { return this.symbolRegex; }
            set
            {
                this.symbolRegex = value.Trim();
            }
        }

        string dmFile = @"D:\FinData\Txt\dm.csv";
        [Category("设置"), Description("dm.csv"), DefaultValue(@"D:\FinData\Txt\dm.csv"),
        Editor(typeof(System.Windows.Forms.Design.FileNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string DmFileName
        {
            get { return this.dmFile; }
            set
            {
                this.dmFile = value.Trim();
            }
        }
        string dmFile2 = @"D:\FinData\Txt\qhdm.csv";
        [Category("设置"), Description("可以用于读取另一个代码文件，一般为qhdm.csv"), DefaultValue(@"D:\FinData\Txt\qhdm.csv"),
        Editor(typeof(System.Windows.Forms.Design.FileNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string DmFileName2
        {
            get { return this.dmFile2; }
            set
            {
                this.dmFile2 = value.Trim();
            }
        }

        string fqFile = @"D:\FinData\Txt\fq.csv";
        [Category("设置"), Description("fq.csv"), DefaultValue(@"D:\FinData\Txt\fq.csv"),
        Editor(typeof(System.Windows.Forms.Design.FileNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string FqFileName
        {
            get { return this.fqFile; }
            set
            {
                this.fqFile = value.Trim();
            }
        }
        private string hqMultiPath = @"D:\FinData\Txt\";
        [Category("设置"), Description("CSV's path"), DefaultValue(@"D:\FinData\Txt\"),
        Editor(typeof(System.Windows.Forms.Design.FolderNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string HqMultiPath
        {
            get { return this.hqMultiPath; }
            set
            {
                string t = value;
                if (t != "")
                {
                    if (!t.EndsWith(@"\")) t += @"\";
                    this.hqMultiPath = t;
                }
            }
        }
        string hqMultiPrefix = @"hq_";
        [Category("设置"), Description("行情CSV文件名称的前缀，一般为hq_；若为空，则不导入"),DefaultValue(@"hq_")]
        public string HqMultiPrefix
        {
            get { return this.hqMultiPrefix; }
            set
            {
                this.hqMultiPrefix = value.Trim();
            }
        }
        int hqMultiStartDt = 20080428;
        [Category("设置"), Description("要导入的起始日期(包括该日期)")]
        public int HqMultiStartDt
        {
            get { return this.hqMultiStartDt; }
            set
            {
                int t = value;
                if(t>19900101 && t<20300101)
                    this.hqMultiStartDt = t;
            }
        }

        string hqSingleFile = @"d:\findata\txt\qhhq.csv";
        [Category("设置"), Description("读取单个文件，如qhhq.csv"), DefaultValue(@"d:\findata\txt\qhhq.csv"),
        Editor(typeof(System.Windows.Forms.Design.FileNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string HqSingleFile
        {
            get { return this.hqSingleFile; }
            set
            {
                this.hqSingleFile = value.Trim();
            }
        }
        private void doWork()
        {
            try
            {
                
                StringBuilder sb = new StringBuilder();
                #region dmfile
                if (this.dmFile.Trim()!="")
                {
                    Console.WriteLine("{0} 开始导入代码数据...", DateTime.Now);
                    if (File.Exists(this.dmFile))
                    {
                        Instrument instrument;
                        StreamReader sr = new StreamReader(this.dmFile, Encoding.Default);
                        for (string line = sr.ReadLine(); line != null; line = sr.ReadLine())
                        {
                            Application.DoEvents();
                            if (!this.autoImport)
                            {
                                Console.WriteLine("{0} 用户中断操作(AutoImport被设为False)。 ", DateTime.Now ); break;
                            }
                            string[] s = line.Split(',');
                            if (Regex.IsMatch(s[0], this.symbolRegex))
                            {
                                instrument = InstrumentManager.Instruments[s[0]];
                                if (instrument == null)
                                {
                                    instrument = new Instrument(s[0], "Z");
                                    instrument.SecurityExchange = s[0].Substring(s[0].LastIndexOf(".") + 1, s[0].Length - s[0].LastIndexOf(".") - 1); ;
                                    char[] c;
                                    instrument.SecurityDesc = s[1];
                                    instrument.Save();
                                    //sb.AppendLine(string.Format("{0} 添加instrument: {1}。", DateTime.Now, s[0]));
                                }
                            }
                        }
                        sr.Close();
                    }
                    else
                    {
                        Console.WriteLine("   {0}不存在.", this.dmFile);
                    }
                }

                #endregion
                #region dmfile2
                if (this.dmFile2.Trim() != "")
                {
                    Console.WriteLine("{0} 开始导入{1}代码数据...", DateTime.Now,this.dmFile2);
                    if (File.Exists(this.dmFile2))
                    {
                        Instrument instrument;
                        StreamReader sr = new StreamReader(this.dmFile2, Encoding.Default);
                        for (string line = sr.ReadLine(); line != null; line = sr.ReadLine())
                        {
                            Application.DoEvents();
                            if (!this.autoImport)
                            {
                                Console.WriteLine("{0} 用户中断操作(AutoImport被设为False)。 ", DateTime.Now); break;
                            }
                            string[] s = line.Split(',');
                            if (Regex.IsMatch(s[0], this.symbolRegex))
                            {
                                instrument = InstrumentManager.Instruments[s[0]];
                                if (instrument == null)
                                {
                                    instrument = new Instrument(s[0], "Z");
                                    if(s[0].LastIndexOf(".")>0)
                                        instrument.SecurityExchange = s[0].Substring(s[0].LastIndexOf(".") + 1, s[0].Length - s[0].LastIndexOf(".") - 1); ;
                                    instrument.SecurityDesc = s[1];
                                    instrument.Save();
                                    //sb.AppendLine(string.Format("{0} 添加instrument: {1}。", DateTime.Now, s[0]));
                                }
                            }
                        }
                        sr.Close();
                    }
                    else
                    {
                        Console.WriteLine("   {0}不存在.", this.dmFile2);
                    }
                }

                #endregion
                #region fqfile
                if (this.fqFile.Trim() != "" )
                {
                    Console.WriteLine("{0} 开始导入复权因子数据...", DateTime.Now);
                    if (File.Exists(this.fqFile))
                    {
                        IDataSeries ds; DateTime dt; PriceFactor pf;
                        StreamReader sr = new StreamReader(this.fqFile, Encoding.Default);
                        for (string line = sr.ReadLine(); line != null; line = sr.ReadLine())
                        {
                            Application.DoEvents();
                            if (!this.autoImport)
                            {
                                Console.WriteLine("{0} 用户中断操作(AutoImport被设为False)。", DateTime.Now ); break;
                            }
                            string[] s = line.Split(',');
                            if (Regex.IsMatch(s[0], this.symbolRegex))
                            {
                                string strDS = s[0].Trim() + ".PriceFactor";
                                ds = DataManager.Server.GetDataSeries(strDS);
                                if (ds == null)
                                {
                                    ds = DataManager.Server.AddDataSeries(strDS);
                                }
                                dt = DateTime.Parse(s[1]);
                                if (ds.Contains(dt)==false)
                                {
                                    pf = new PriceFactor(dt, Math.Round(float.Parse(s[2]), 6));
                                    ds.Add(dt, pf);
                                    //sb.AppendLine(string.Format("{0} 添加PriceFactor: {1} {2} 。", DateTime.Now, s[0], s[1]));
                                }
                            }
                        }
                        sr.Close();
                    }
                    else
                    {
                        Console.WriteLine("    {0}不存在.", this.fqFile);
                    }
                }
                #endregion
                #region hqPath
                if (this.hqMultiPrefix.Trim() != "")
                {
                    string[] files=Directory.GetFiles(this.hqMultiPath, this.hqMultiPrefix.Trim() + "????????.csv", System.IO.SearchOption.TopDirectoryOnly);
                    foreach (string f in files)
                    {
                        string ff = f.Substring(this.hqMultiPath.Length + this.hqMultiPrefix.Length, 8);
                        if (Regex.IsMatch(ff, @"(\d{8})") )
                        {
                            if ( (int.Parse(ff )) >= this.hqMultiStartDt)
                            {
                                CSV2Daily(f);
                                //Console.WriteLine(f);
                            }
                        }
                    }
                }
                #endregion
                #region hqfile
                if (this.hqSingleFile.Trim() != "")
                {
                    CSV2Daily(this.hqSingleFile);
                }
                #endregion

                Console.WriteLine("{0} 导入完成.", DateTime.Now);
                //Console.WriteLine(sb.ToString());
                this.Disconnect();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        private void CSV2Daily(string csvfile)
        {
            try
            {
                if (File.Exists(csvfile))
                {
                    IDataSeries ds; DateTime dt; Daily daily;
                    StreamReader sr = new StreamReader(csvfile, Encoding.Default);
                    Console.WriteLine("{0} 开始导入{1}的行情数据...", DateTime.Now, csvfile);
                    for (string line = sr.ReadLine(); line != null; line = sr.ReadLine())
                    {
                        Application.DoEvents();
                        if (!this.autoImport)
                        {
                            Console.WriteLine("{0} 用户中断操作(AutoImport被设为False)。", DateTime.Now); break;
                        }
                        string[] s = line.Split(',');
                        if (Regex.IsMatch(s[0], this.symbolRegex))
                        {
                            string strDS = s[0].Trim() + ".Daily";
                            ds = DataManager.Server.GetDataSeries(strDS);
                            if (ds == null)
                            {
                                ds = DataManager.Server.AddDataSeries(strDS);
                            }
                            dt = DateTime.Parse(s[1]);
                            if (ds.Contains(dt) == false)
                            {
                                daily = new Daily(dt, double.Parse(s[2]), double.Parse(s[3]), double.Parse(s[4]), double.Parse(s[5]), long.Parse(s[6]), long.Parse(s[7]));
                                ds.Add(dt, daily);
                                //Console.WriteLine(string.Format("{0} 添加daily: {1} {2} 。", DateTime.Now, s[0], s[1]));
                            }
                        }
                    }
                    sr.Close();
                }
                else
                {
                    Console.WriteLine("    {0}不存在.", csvfile);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("CSV2Daily Err:{0}", ex.Message);
            }
        }


        #endregion

        #region IProvider 成员
        private bool isConnected = false;

        public void Connect(int timeout)
        {
            this.Connect();
            ProviderManager.WaitConnected(this, timeout);
        }
        public void Connect()
        {
            isConnected = true;
            Console.WriteLine("{0} Connected!",DateTime.Now);
            if (Connected != null)
                Connected(this, new EventArgs());
            this.doWork();
            //Thread th = new Thread(new ThreadStart(this.doWork));
            //th.Start();
        }
        public event EventHandler Connected;
        public void Disconnect()
        {
            try
            {
                Console.WriteLine("{0} Disconnected!",DateTime.Now);
                isConnected = false;
                if (Disconnected != null)
                    Disconnected(this, new EventArgs());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Disconnect：" + ex.Message);
            }

        }

        public event EventHandler Disconnected;

        public event ProviderErrorEventHandler Error;
        [Category("信息")]
        public byte Id
        {
            get { return 116; }
        }
        [Category("信息")]
        public bool IsConnected
        {
            get { return isConnected; }
        }
        [Category("信息")]
        public string Name
        {
            get { return "CSV2SQ"; }
        }
        [Category("信息")]
        public string Title
        {
            get { return "CSV2SQ 自动将hq_*.csv,dm.csv导入SQ。"; }
        }
        [Category("信息")]
        public string URL
        {
            get { return String.Empty; }
        }
        public void Shutdown()
        {
            
        }
        [Category("信息")]
        public ProviderStatus Status
        {
            get
            {
                if (!IsConnected)
                    return ProviderStatus.Disconnected;
                else
                    return ProviderStatus.Connected;
            }
        }

        public event EventHandler StatusChanged;

        #endregion

        #region IHistoryProvider 成员
        [Category("信息")]
        public bool BarSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool DailySupported
        {
            get { return false; }
        }

        public Bar[] GetBarHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, int barSize)
        {
            throw new NotImplementedException();
        }

        public Daily[] GetDailyHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, bool dividendAndSplitAdjusted)
        {
            throw new NotImplementedException();
        }

        public Quote[] GetQuoteHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }

        public Trade[] GetTradeHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }
        [Category("信息")]
        public bool QuoteSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool TradeSupported
        {
            get { return false; }
        }

        #endregion
    }

}
