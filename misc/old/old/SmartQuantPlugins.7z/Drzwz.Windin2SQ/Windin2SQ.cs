﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Threading;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Drawing.Design;
using SmartQuant;
using SmartQuant.Data;
using SmartQuant.Series;
using SmartQuant.Providers;
using SmartQuant.Instruments;

namespace Drzwz
{
    public class Windin2SQ : IProvider, IHistoryProvider
    {

        public Windin2SQ()
        {
            ProviderManager.Add(this);
        }
        #region 导入数据的方法
        private string symbolRegex = string.Empty;
        private bool autoImport = true;
        [Category("设置"), Description("要导入数据的代码的正则表达式；\n若为空则导入现有所有Instruments的复权数据。"), DefaultValue("")]
        public string SymbolRegex
        {
            get { return this.symbolRegex; }
            set
            {
                this.symbolRegex = value.Trim();
            }
        }
        [Category("设置"), Description("true-连接后自动导入；false-连接后不导入，若运行中，则中断导入。"), DefaultValue("")]
        public bool AutoImport
        {
            get { return this.autoImport; }
            set
            {
                this.autoImport = value;
            }
        }
        private void doWork()
        {
            try
            {
                
                bool regexIsNotEmpty = (this.symbolRegex != string.Empty);
                string dm, jc, mkt,symbol, securitytype;
                //DailySeries ds;
                IDataSeries ids;
                StringBuilder sb = new StringBuilder(); sb.AppendLine();
                Console.WriteLine("{0} 开始导入Windin复权因子数据...", DateTime.Now);
                int num = 0;
                foreach(Instrument inst in InstrumentManager.Instruments) //
                {
                    Application.DoEvents();
                    if (!this.autoImport)
                    {
                        Console.WriteLine("{0} 处理了{1}个代码后，用户中断操作(AutoImport被设为False)。", DateTime.Now, num);
                        break;
                    }
                    symbol = inst.Symbol;
                    mkt = symbol.Substring(symbol.LastIndexOf(".") + 1, symbol.Length - symbol.LastIndexOf(".") - 1);
                    securitytype =  Drzwz.SQCommon.GetSecurityType(symbol);
                    //Console.WriteLine("{0} 正在读取{1}...", DateTime.Now, symbol);

                    //如果与SymbolRegex不匹配，则不导入，文件指针往后移动recordCounts*32个字节
                    if (regexIsNotEmpty)
                    {
                        if (!Regex.IsMatch(symbol, this.symbolRegex))
                        {
                            //Console.WriteLine("{0} {1}与SymbolRegex不匹配。不导入。", DateTime.Now, symbol);
                            continue;
                        }
                    }
                    sb.Append( symbol+" ");
                    num++;
                    if (num % 10 == 0) sb.AppendLine();
                    //导入数据
                    //DateTime dt ;
                    //Daily daily;
                    //ds = instrument.GetDailySeries();
                    //Console.WriteLine("{0} 准备导入{1}的数据。", DateTime.Now, symbol);
                    //是否有复权因子数据
                    DateTime startRequestDateTime = DateTime.MinValue;
                    SortedList<DateTime, double> factorList = new SortedList<DateTime, double>();
                    factorList = this.GetFactorList(symbol);
                    if (factorList.Count > 0)
                    {
                        //判断该代码对应的PriceFactor是否已存在
                        ids = inst.GetDataSeries("PriceFactor");
                        if (ids == null)
                        {
                            ids = inst.AddDataSeries("PriceFactor");
                        }
                        else
                        {
                            if (ids.Count > 0)
                                startRequestDateTime = ids.LastDateTime.AddDays(1);
                        }
                        //
                        for (int i = 0; i < factorList.Count; i++)
                        {
                            if (factorList.Keys[i] >= startRequestDateTime)
                            {
                                PriceFactor pf = new PriceFactor();
                                pf.DateTime = factorList.Keys[i];
                                pf.Factor = factorList.Values[i];
                                ids.Add(pf.DateTime, pf);
                            }
                        }
                    }
                }

                Console.WriteLine("{0} 导入完成，共导入{1}个代码的数据。\n {2}", DateTime.Now,num,sb.ToString());
                this.Disconnect();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        //public string GetSecurityType(string symbol)
        //{
        //    string code = symbol.Trim().ToUpper();
        //    if (Regex.IsMatch(code, @"(\d{6}\.S[HZ])"))
        //    {
        //        if (Regex.IsMatch(code, @"(000300.SH)|(000017.SH)|(00090\d.SH)") == true)
        //        {
        //            return "Index";//指数
        //        }
        //        //if (Regex.IsMatch(code, @"(60[0-8]\d{3}.SH)|(90\d{4}.SH)|(00[01256789]\d{3}.SZ)|(20\d{4}.SZ)") == true)
        //        if (Regex.IsMatch(code, @"(60[0-8]\d{3}.SH)|(00[01256789]\d{3}.SZ)") == true)
        //        {
        //            return "Stock";//股票
        //        }
        //        else if (Regex.IsMatch(code, @"(00000\d\.SH)|(00001[0-6]\.SH)") == true)
        //        {
        //            return "Index";
        //        }
        //        else if (Regex.IsMatch(code, @"([012]\d{5}.SH)|(1[0123]\d{4}.SZ)") == true && Regex.IsMatch(code, @"(181\d{3}.SH)") == false && Regex.IsMatch(code, @"(190\d{3}.SH)") == false)
        //        {
        //            return "Bond";//债券，FIX中细分各种债券，这里未区分
        //        }
        //        else if (Regex.IsMatch(code, @"(510\d{3}.SH)|(159\d{3}.SZ)") == true)
        //        {
        //            return "ETF";// ETF
        //        }
        //        else if (Regex.IsMatch(code, @"(5[01]\d{4}.SH)|(184\d{3}.SZ)|(\d{6}.OF)|(\d{6}NV.OF)|(1[56]\d{4}.SZ)") == true)
        //        {
        //            return "Fund"; //封闭及开放基金,LOF
        //        }
        //        else if (Regex.IsMatch(code, @"(58\d{4}.SH)|(03\d{4}.SZ)") == true)
        //        {
        //            return "Warrant";//权证
        //        }
        //        else if (Regex.IsMatch(code, @"(000\d{3}.SH)|(399\d{3}.SZ)|(8[013]\d{4}.SH)") == true)
        //        {
        //            return "Index";
        //        }
        //        return "Z";
        //    }
        //    else
        //    {
        //        return "Futures";
        //    }
        //    return "Z";
        //}

        private string WWTPath = @"D:\Windin\WWT\";
        [Category("设置"), Description("万点终端的安装文件夹。"),
        Editor(typeof(System.Windows.Forms.Design.FolderNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string WindinPath
        {
            get { return this.WWTPath; }
            set
            {
                this.WWTPath = value;
            }
        }
        public SortedList<DateTime, double> GetFqyz(string filename, string Symbol)
        {
            try
            {
                SortedList<DateTime, double> mylst = new SortedList<DateTime, double>();
                string windFileName = filename;
                if (File.Exists(windFileName) == false)
                {
                    Console.WriteLine("错误:文件不存在");
                    return null;
                }
                FileStream fs = new FileStream(windFileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                BinaryReader br = new BinaryReader(fs);
                //string s = "";string ss="";
                fs.Position = 18;
                long recordCount = br.ReadUInt32();//第18字节开始的4B保存记录个数,接下来是每个记录,以0x09开头
                for (int record = 0; record < recordCount; record++)
                {
                    byte flag = br.ReadByte();
                    if (flag == '\x09')
                    {
                        string dm = new string(br.ReadChars(9));//代码
                        string rqs = new string(br.ReadChars(8));//日期
                        double yz = br.ReadSingle();//复权因子
                        fs.Position = fs.Position + 1;  //有个00字节
                        short notelen = br.ReadInt16(); //备注字符串长度
                        fs.Position = fs.Position + notelen;
                        //s=System.Text.Encoding.Default.GetString(br.ReadBytes(notelen));//备注字符串
                        //s=s.Replace("\x0D","").Replace("\x0A","");
                        //ss=dm+","+rq+","+yz.ToString() ;
                        //Console.WriteLine(ss);
                        if (dm == Symbol)
                        {
                            DateTime rq = new DateTime(int.Parse(rqs.Substring(0, 4)), int.Parse(rqs.Substring(4, 2)), int.Parse(rqs.Substring(6, 2)));
                            if (!mylst.ContainsKey(rq)) mylst.Add(rq, Math.Round(yz, 6));

                        }
                    }
                }
                fs.Close();
                br.Close();

                return mylst;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "--GetFqyz");
                return null;
            }
        }
        public SortedList<DateTime, double> GetFactorList(string symbol)
        {
            if (!WWTPath.EndsWith(@"\")) WWTPath = WWTPath + @"\";
            string filename = WWTPath + @"etc\hqafhis.dat";
            SortedList<DateTime, double> lst = GetFqyz(filename, symbol);
            filename = WWTPath + @"etc\hqafdelt.dat";
            if (File.Exists(filename) == false)
            {
                return lst;
            }
            SortedList<DateTime, double> lst2 = GetFqyz(filename, symbol);
            if (lst == null)
            {
                lst = lst2;
            }
            else
            {
                foreach (DateTime dt in lst2.Keys) if (!lst.ContainsKey(dt)) lst.Add(dt, lst2[dt]);
            }
            return lst;
        }

        #endregion

        #region IProvider 成员
        private bool isConnected = false;

        public void Connect(int timeout)
        {
            this.Connect();
            ProviderManager.WaitConnected(this, timeout);
        }
        public void Connect()
        {
            isConnected = true;
            Console.WriteLine("{0} Connected!",DateTime.Now);
            if (Connected != null)
                Connected(this, new EventArgs());
            this.doWork();
            //Thread th = new Thread(new ThreadStart(this.doWork));
            //th.Start();
        }
        public event EventHandler Connected;
        public void Disconnect()
        {
            try
            {
                Console.WriteLine("{0} Disconnected!",DateTime.Now);
                isConnected = false;
                if (Disconnected != null)
                    Disconnected(this, new EventArgs());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Disconnect：" + ex.Message);
            }

        }

        public event EventHandler Disconnected;

        public event ProviderErrorEventHandler Error;
        [Category("信息")]
        public byte Id
        {
            get { return 111; }
        }
        [Category("信息")]
        public bool IsConnected
        {
            get { return isConnected; }
        }
        [Category("信息")]
        public string Name
        {
            get { return "Windin2SQ"; }
        }
        [Category("信息")]
        public string Title
        {
            get { return "Windin2SQ 自动将Windin复权因子数据导入SQ。"; }
        }
        [Category("信息")]
        public string URL
        {
            get { return String.Empty; }
        }
        public void Shutdown()
        {
            
        }
        [Category("信息")]
        public ProviderStatus Status
        {
            get
            {
                if (!IsConnected)
                    return ProviderStatus.Disconnected;
                else
                    return ProviderStatus.Connected;
            }
        }

        public event EventHandler StatusChanged;

        #endregion

        #region IHistoryProvider 成员
        [Category("信息")]
        public bool BarSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool DailySupported
        {
            get { return false; }
        }

        public Bar[] GetBarHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, int barSize)
        {
            throw new NotImplementedException();
        }

        public Daily[] GetDailyHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2, bool dividendAndSplitAdjusted)
        {
            throw new NotImplementedException();
        }

        public Quote[] GetQuoteHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }

        public Trade[] GetTradeHistory(SmartQuant.FIX.IFIXInstrument instrument, DateTime datetime1, DateTime datetime2)
        {
            throw new NotImplementedException();
        }
        [Category("信息")]
        public bool QuoteSupported
        {
            get { return false; }
        }
        [Category("信息")]
        public bool TradeSupported
        {
            get { return false; }
        }

        #endregion
    }
}
