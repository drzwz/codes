﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace Drzwz
{
    public class SQCommon
    {
        /// <summary>
        /// 获取证券类型字符串
        /// </summary>
        /// <param name="symbol">证券代码（格式xxxxxx.MK）</param>
        /// <returns>证券类型字符串</returns>
        public static string GetSecurityType(string symbol)
        {
            string code = symbol.Trim().ToUpper();
            if (Regex.IsMatch(code, @"(\d{6}\.S[HZ])"))
            {
                if (Regex.IsMatch(code, @"(000300.SH)|(00001\d\.SH)|(00090\d\.SH)") == true)
                {
                    return "Index";//指数
                }
                //if (Regex.IsMatch(code, @"(60[0-8]\d{3}.SH)|(90\d{4}.SH)|(00[01256789]\d{3}.SZ)|(20\d{4}.SZ)") == true)
                if (Regex.IsMatch(code, @"(60[0-8]\d{3}\.SH)|(00[01256789]\d{3}\.SZ)") == true)
                {
                    return "Stock";//股票
                }
                else if (Regex.IsMatch(code, @"(00000\d\.SH)|(00001[0-6]\.SH)") == true)
                {
                    return "Index";
                }
                else if (Regex.IsMatch(code, @"([012]\d{5}\.SH)|(1[0123]\d{4}\.SZ)") == true && Regex.IsMatch(code, @"(181\d{3}\.SH)") == false && Regex.IsMatch(code, @"(190\d{3}\.SH)") == false)
                {
                    return "Bond";//债券，FIX中细分各种债券，这里未区分
                }
                else if (Regex.IsMatch(code, @"(510\d{3}\.SH)|(159\d{3}\.SZ)") == true)
                {
                    return "ETF";// ETF
                }
                else if (Regex.IsMatch(code, @"(5[01]\d{4}\.SH)|(184\d{3}\.SZ)|(\d{6}\.OF)|(\d{6}NV.OF)|(1[56]\d{4}\.SZ)") == true)
                {
                    return "Fund"; //封闭及开放基金,LOF
                }
                else if (Regex.IsMatch(code, @"(58\d{4}\.SH)|(03\d{4}\.SZ)") == true)
                {
                    return "Warrant";//权证
                }
                else if (Regex.IsMatch(code, @"(000\d{3}\.SH)|(399\d{3}\.SZ)|(8[013]\d{4}\.SH)") == true)
                {
                    return "Index";
                }
                return "Z";
            }
            else
            {
                return "Z";
            }
            //return "Z";
        }

    }
}
