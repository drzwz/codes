using System;
using System.Collections.Generic;
using System.Text;
using SmartQuant;
using SmartQuant.Data;

namespace SmartQuant.Data
{
    [Serializable]
    public class DailyA : IDataObject, ISeriesObject, ICloneable
    {
        private DateTime dateTime;
        private double factor;
        private byte providerId;

        public DailyA(DateTime datetime, double factor)
        {
            this.providerId = 0;
            this.dateTime = datetime;
            this.factor = factor;
        }
        public DailyA(DailyA pricefactor)
            : this(pricefactor.dateTime, pricefactor.factor)
        {

        }
        public DailyA()
            : this(DateTime.MinValue, 0)
        {

        }

        public override string ToString()
        {
            return string.Format("{0} , Factor = {1}", this.dateTime, this.factor);
        }

        [View]
        public double Factor
        {
            get
            {
                return this.factor;
            }
            set
            {
                this.factor = value;
            }
        }


        #region IDataObject ��Ա

        public DateTime DateTime
        {
            get
            {
                return this.dateTime;
            }
            set
            {
                this.dateTime = value;
            }
        }

        public byte ProviderId
        {
            get
            {
                return this.providerId;
            }
            set
            {
                this.providerId = value;
            }
        }

        #endregion

        #region ISeriesObject ��Ա


        public ISeriesObject NewInstance()
        {
            return new DailyA();
        }

        public void ReadFrom(System.IO.BinaryReader reader)
        {
            byte num = reader.ReadByte();
            this.dateTime = new System.DateTime(reader.ReadInt64());
            //this.factor = reader.ReadDouble();
            this.factor = this.dateTime.Day;
            this.providerId = reader.ReadByte();
            return;

        }

        public void WriteTo(System.IO.BinaryWriter writer)
        {
            writer.Write((byte)2);
            writer.Write(this.dateTime.Ticks);
            //writer.Write(this.factor);
            writer.Write(this.providerId);
        }

        #endregion

        #region ICloneable ��Ա

        public object Clone()
        {
            return new DailyA(this);
        }

        #endregion
    }
}
