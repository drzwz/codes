using System;
using System.Collections.Generic;
using System.Text;
using SmartQuant;
using SmartQuant.Instruments;

namespace SmartQuant.Data
{
    public class FqBar
    {
        SortedList<DateTime, double> factorList = new SortedList<DateTime, double>();
        double maxfqyz = 1.0F;//���Ȩ����
        double curr_fqyz = 1.0F;//��ǰ��Ȩ����
        int fqyzIndex = 0;
        public FqBar(string symbol)
        {
            Instrument instrument = InstrumentManager.Instruments[symbol];
            if (instrument != null)
            {
                IDataSeries series = instrument.GetDataSeries("PriceFactor");
                if (series != null)
                {
                    foreach (PriceFactor factor in series)
                    {
                        if (!factorList.ContainsKey(factor.DateTime)) factorList.Add(factor.DateTime, factor.Factor);
                    }
                }
            }
            if (factorList.Count > 0)
            {
                maxfqyz = factorList.Values[factorList.Count - 1];
                factorList.Add(new DateTime(2100, 1, 1), 1);//����һ�����޴�����,
            }
        }
        public Bar GetFqBar(Bar bar)
        {

            if (factorList.Count > 0)
            {
                if (bar.DateTime < factorList.Keys[0])
                {
                    curr_fqyz = 1 / maxfqyz;//ǰ��Ȩ����
                    fqyzIndex = 0;
                }
                else
                {
                    for (int j = fqyzIndex; j < factorList.Count - 1; j++)
                    {
                        if (factorList.Keys[j] <= bar.DateTime && bar.DateTime < factorList.Keys[j + 1])
                        {
                            curr_fqyz = factorList.Values[j] / maxfqyz; //ǰ��Ȩ����
                            fqyzIndex = j;
                            break;
                        }

                    }
                }
                //��Ȩ
                bar.Open = bar.Open * curr_fqyz;
                bar.High = bar.High * curr_fqyz;
                bar.Low = bar.Low * curr_fqyz;
                bar.Close = bar.Close * curr_fqyz;
                //bar.Volume = (int)(bar.Volume * curr_fqyz);

            }
            //��Ȩ��������
            return bar;
        }
    }
}
